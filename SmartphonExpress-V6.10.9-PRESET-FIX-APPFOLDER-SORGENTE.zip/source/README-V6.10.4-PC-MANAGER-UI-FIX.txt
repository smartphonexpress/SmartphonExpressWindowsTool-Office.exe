SmartphonExpress Windows Tool v6.10.4 - PC MANAGER UI FIX
Corretta la voce mancante nell'interfaccia.
La funzione si trova nel gruppo Utility, rete e licenze.
Resta facoltativa, esclusa da Seleziona tutti e con conferma prima dell'avvio.
Nessuna modifica al comportamento dell'installazione della 6.10.3.
Compilazione Release win-x64 riuscita. EXE incluso in PORTABLE-EXE.
