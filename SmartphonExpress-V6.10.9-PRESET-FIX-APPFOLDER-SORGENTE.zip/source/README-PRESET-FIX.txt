SmartphonExpress Windows Tool V6.10.9 - correzione preset

CAUSA
Nella versione ricevuta SelectIntelligentPreset selezionava solo quattro
voci Prestazioni, piu due/tre voci nel profilo avanzato. I pulsanti erano
collegati correttamente: era stata ridotta la lista delle opzioni comuni.

CORREZIONE
Consigliato e Prestazioni condividono ora una lista esplicita di 33 voci.
AppFolder sul Desktop e incluso SEMPRE in entrambi i preset, anche dopo
Deseleziona o dopo modifiche manuali. Deseleziona continua a togliere tutto.
Prestazioni aggiunge gestione avvio e ottimizzazione disco; aggiunge anche
il piano Prestazioni elevate solo in assenza di batteria. Stato batteria
sconosciuto: piano escluso. Totale: 35 voci con batteria, 36 senza batteria.
Il cambio profilo aggiorna tutte le checkbox, senza eseguire operazioni.
La finestra informativa Prestazioni e sostituita da un messaggio nel log.

La lista comune comprende configurazione desktop/Explorer/taskbar,
Outlook, NumLock, Consumer Features, privacy/telemetria, Delivery
Optimization, pulizia temporanei, metadata dispositivi, app in background,
Edge, menu contestuale, funzioni AI visibili, Blocco note, pin Start,
Chrome, Firefox, 7-Zip, VLC, Office LTSC 2024, download preconfigurato,
stato licenze Windows/Office, AppFolder, Storage Sense, grafica ridotta
e tre controlli prestazioni. Elenco esatto: GetPresetSelection in Program.cs.

Le note storiche sono state usate per ricostruire la selezione: lo ZIP
non contiene il codice precedente alla V6.10.9. Non viene dichiarata
un'identita completa con un vecchio preset non disponibile.
Restano manuali disattivazioni di protezioni, servizi avanzati, ibernazione,
rimozioni AppX/Widgets, DNS, riparazioni, upgrade, riavvio BIOS e altre
operazioni non presenti nella lista esplicita. Le funzioni restano disponibili.
Office LTSC 2024 resta il default documentato; Microsoft 365 e un'alternativa
manuale. L'installazione Office puo sostituire installazioni esistenti,
come gia previsto dalla funzione originale; la selezione non la esegue.

PRESERVAZIONE
Nessuna modifica alle implementazioni dei tweak, WinHubX, AppFolder,
installazioni/diagnostica Office o ripristino grafica/piano energia.
La versione del progetto resta 6.10.9; questo pacchetto e identificato
come PRESET-FIX. Le vecchie note descrivono versioni precedenti; per la
selezione attuale fa fede questo file.

VERIFICA
.NET SDK 8.0.427 su Windows: compilazione Release riuscita.
Test automatico WinForms incluso in ../verification:
  dotnet run --project ../verification/PresetChecks.csproj -c Release
Il test istanzia il form senza mostrarlo, invoca i gestori reali dei pulsanti
e sostituisce le azioni con contatori: non applica tweak al computer.
Controlla le 74 associazioni checkbox, selezioni esatte, cambio profilo,
click ripetuti, Deseleziona, AppFolder, batteria, alternative Office/DNS
e assenza di esecuzione di azioni. Verifica anche checkbox riordinate.
Non sono stati eseguiti installazioni Office, tweak di sistema o benchmark.

COMPILAZIONE
Dalla cartella source: dotnet build -c Release
Per produrre l'eseguibile portatile usare BUILD-EXE.cmd o
  dotnet publish -c Release -r win-x64 --self-contained true
