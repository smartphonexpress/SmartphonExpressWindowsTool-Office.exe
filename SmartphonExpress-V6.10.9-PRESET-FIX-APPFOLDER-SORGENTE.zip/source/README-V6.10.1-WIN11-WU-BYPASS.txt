SmartphonExpress Windows Tool v6.10.1

NOVITA': Patch Windows Update per Windows 11 non supportato

- Funzione separata dall'upgrade tramite ISO già presente in v6.10.0.
- Pensata per PC con Windows 11 già installato sui quali un FEATURE UPDATE proposto/scaricato da Windows Update viene bloccato dai requisiti hardware.
- Verifica che il sistema corrente sia Windows 11 e mostra build, TPM e Secure Boot.
- Rileva la cache C:\$WINDOWS.~BT\Sources quando già presente.
- Imposta AllowUpgradesWithUnsupportedTPMOrCPU e applica un bypass temporaneo del SetupHost del feature update.
- NON disabilita DisableWUfBSafeguards / Safeguard Hold Microsoft.
- NON sostituisce DLL e NON cancella SoftwareDistribution o la cache dell'aggiornamento.
- La stessa voce rimuove la patch se risulta già attiva.
- Programma una rimozione automatica al successivo accesso dopo il tentativo di upgrade.
- Dopo l'applicazione può aprire direttamente Windows Update per usare Riprova/Installa.
- Esclusa da Seleziona tutti e dal preset Prestazioni.

NOTA
Il bypass hardware per Dynamic Update/Windows Update è un metodo community-based e non rende il PC ufficialmente supportato da Microsoft. La logica è stata mantenuta temporanea proprio per evitare interferenze con aggiornamenti ordinari.

Riferimento tecnico del meccanismo di bypass:
AveYo / MediaCreationTool.bat - Skip_TPM_Check_on_Dynamic_Update.cmd (MIT License)
https://github.com/AveYo/MediaCreationTool.bat

Microsoft documenta separatamente Dynamic Update, i log di compatibilità di Windows Setup e /Compat IgnoreWarning; quest'ultimo da solo non equivale a un bypass dei requisiti hardware.
