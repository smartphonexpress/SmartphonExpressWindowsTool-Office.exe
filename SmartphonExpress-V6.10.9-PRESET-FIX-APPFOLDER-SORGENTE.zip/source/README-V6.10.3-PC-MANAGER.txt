SmartphonExpress Windows Tool v6.10.3 - PC MANAGER FACOLTATIVO

Nuova voce: Installa Microsoft PC Manager (facoltativo).
Esclusa da Seleziona tutti; richiede selezione manuale e conferma.
Controlla il pacchetto già installato per l'account corrente.
Richiede winget (Programma di installazione app di Microsoft).
Salva il GeoId corrente, imposta USA (244), avvia:
winget install --id 9PM860492SZD --exact --source msstore
Ripristina e verifica il GeoId originale nel blocco finally, anche su errore.
La finestra PowerShell mostra avanzamento e richieste dello Store.
Non chiudere forzatamente la finestra o il PC durante l'installazione:
il ripristino non può essere garantito in caso di interruzione forzata.
Report finale con codici di uscita ed eventuale comando di ripristino manuale.

Compilazione Release win-x64 .NET 8 riuscita; sintassi PowerShell verificata.
EXE portatile in PORTABLE-EXE. Installazione reale da provare sul PC dell'utente.
Restano incluse la correzione compile fix 6.10.2 e le altre funzioni.
