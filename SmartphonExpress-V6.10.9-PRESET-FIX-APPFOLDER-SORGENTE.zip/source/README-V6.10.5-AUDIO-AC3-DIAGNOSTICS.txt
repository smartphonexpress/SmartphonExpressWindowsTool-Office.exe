SmartphonExpress Windows Tool v6.10.5

Aggiunta diagnostica sola lettura: Audio Windows / problema AC-3.
- Rileva versione/build/UBR.
- Segnala il problema noto AC-3 sulle famiglie 26100/26200/26300 dalla revisione .9550.
- Controlla Audiosrv, AudioEndpointBuilder e dispositivi Win32_SoundDevice.
- Non modifica driver, codec, servizi o aggiornamenti.
- Mantiene tutte le funzioni della v6.10.4.
