V6.10.7 - revisione conservativa delle ottimizzazioni (sorgente)
- Rimosse modifiche automatiche ai servizi CscService e StorSvc.
- Rimosso StartupDelayInMSec=0 dai preset.
- Rimossa la disattivazione globale PowerThrottlingOff=1.
- Report: verifica valore registro distinta da prestazioni misurate.
- Office: un segnale di licenza non valida non viene piu' presentato come certezza di disattivazione; richiede verifica account.
NOTA: non compilato ne' collaudato su Windows in questo ambiente.
La diagnosi Office richiede test con Microsoft 365, Office LTSC e licenze miste.
