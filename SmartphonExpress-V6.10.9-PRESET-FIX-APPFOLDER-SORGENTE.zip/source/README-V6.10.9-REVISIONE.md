# SmartphonExpress Windows Tool V6.10.9 — revisione sorgente

## Modifiche applicate
- Preset **Consigliato** ora basato su una lista esplicita di diagnostiche e impostazioni grafiche conservative; non seleziona più automaticamente operazioni di installazione, rimozione, disattivazione delle protezioni, privacy o servizi.
- Preset **Prestazioni** aggiunge ottimizzazione unità, gestione avvio e piano energetico High Performance soltanto se non viene rilevata una batteria. Il piano resta un'opzione che richiede attenzione a consumi e temperature.
- RAM fisica rilevata tramite GlobalMemoryStatusEx; rilevamento batteria tramite Windows Forms. Il rilevamento non garantisce che un dispositivo sia sempre collegato alla rete elettrica.
- Backup dei valori originali delle sei impostazioni grafiche in ProgramData, con ripristino dei valori originali anche tra sessioni; i valori preesistenti non sono più sostituiti con default fissi.
- Backup persistente del GUID del piano energetico prima della modifica; ripristino anche dopo riavvio del Tool.
- Se più prodotti Office restituiscono stati discordanti, il risultato viene mostrato come **LICENZE MISTE / VERIFICARE PRODOTTO** invece di dichiarare genericamente Office attivato.
- Versione sorgente aggiornata a 6.10.9.

## Limiti e avvertenze
- Questa è una **revisione del codice**, non un EXE compilato. Nell'ambiente disponibile manca .NET SDK e non è stato possibile eseguire build o test su Windows.
- La diagnostica Office può ancora non determinare lo stato di alcune licenze Microsoft 365; nessuna modifica a script di attivazione o licenze.
- Le funzioni avanzate **selezionate manualmente** conservano il comportamento originale e richiedono verifica caso per caso.
- Il preset Prestazioni non garantisce accelerazioni misurabili; non sono stati eseguiti benchmark.
- Non è stata effettuata una trasposizione indiscriminata dei tweak WinHubX, inclusi Dynamic Tick e disattivazioni di sicurezza.

## Compilazione su Windows
Aprire la cartella sorgente in Windows con .NET 8 SDK installato ed eseguire `dotnet publish -c Release -r win-x64 --self-contained true` oppure utilizzare lo script BUILD-EXE.cmd incluso, verificando prima i prerequisiti.

## Verifica consigliata
1. Compilazione Release senza errori.
2. Test del preset Consigliato su VM Windows 10/11.
3. Verifica che ripristino grafica e piano energetico recuperino valori originali dopo chiusura e riavvio del programma.
4. Test Office con Microsoft 365, Office LTSC e installazioni miste.
5. Test delle funzioni avanzate su macchina di prova, non su PC cliente.
