V6.10.8 - CORREZIONE PARZIALE, NON BUILD COLLAUDATA

Corretto il ripristino del piano energetico: prima della modifica viene acquisito il GUID attivo; il ripristino non forza piu il piano Bilanciato. Il GUID e conservato solo durante la sessione dell applicazione: se viene chiusa, il ripristino automatico non e disponibile.

ATTENZIONE: WinHubX.exe non e stato decompilato in modo affidabile. Non e stato possibile stabilire una corrispondenza verificata fra i singoli comandi delle due applicazioni, pertanto NON sono stati copiati o sostituiti tweak attribuiti a WinHubX.

Non compilato o testato su Windows: ambiente senza SDK dotnet. Non distribuire come versione di produzione senza compilazione e test.
