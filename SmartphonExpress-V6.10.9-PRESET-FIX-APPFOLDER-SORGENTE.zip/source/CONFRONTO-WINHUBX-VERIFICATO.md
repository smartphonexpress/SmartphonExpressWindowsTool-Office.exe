# Audit comparativo SmartphonExpress V6.10.8 / WinHubX

## Ambito e limiti
Confronto **statico** dei sorgenti disponibili: `Program.cs` SmartphonExpress e codice C# decompilato di WinHubX (`WinHubX.Forms.Settaggi/FormUtility.cs`). Non sono stati eseguiti i programmi su Windows e non sono stati misurati tempi di boot, reattività o avvio app. Non è corretto equiparare un comando eseguito a un miglioramento misurato.

## Riscontri diretti sul codice WinHubX
- `FormUtility.cs`, `btnSuggeriti_Click`: la selezione suggerita è costruita principalmente da tipo di disco (HDD/SSD/NVMe) e quantità di RAM letti da un JSON locale, non da benchmark prima/dopo.
- Fra i suggeriti generali compaiono `Disabilita Windows Tick dinamico`, `Disabilita Ibernazione`, `Disabilita Desktop Remoto`, `Disabilita UWP apps` e `Abilita HAGS`. **Non sono ottimizzazioni universalmente sicure né universalmente efficaci**.
- `Disabilita Windows Tick dinamico` esegue `bcdedit /set disabledynamictick yes` (intorno alla riga 700): intervento di boot configuration da NON trasferire al preset generale senza una diagnosi specifica.
- `Disabilita Index File` avvia PowerShell con uno script che usa `$Drive` senza definirlo nel frammento esaminato, e non controlla l'exit code; il blocco `catch` ignora gli errori. Non va copiato come implementazione affidabile.
- `FormUtility.cs` contiene anche impostazioni di privacy e sicurezza (fra cui `EnableSmartScreen=0`): non sono ottimizzazioni prestazionali da trasferire.

## SmartphonExpress: modifiche effettuate in questa revisione
- `EnablePerformanceVisuals`: tolta la modifica a Game DVR e alla policy HKLM GameDVR. Un preset per animazioni/trasparenze non deve disabilitare una funzione separata di registrazione video.
- `RestorePerformanceVisuals`: tolta la cancellazione indiscriminata delle chiavi Game DVR, che poteva eliminare preferenze/policy preesistenti anche se non modificate dall'utente.
- **Non** sono stati copiati i comandi WinHubX non supportati da una motivazione diagnostica; il codice precedente per le altre opzioni rimane invariato.

## Problemi ancora aperti (non risolti in questo ZIP)
1. `RestorePerformanceVisuals` ripristina valori predefiniti e non uno snapshot persistente dei valori originali: serve un backup per utente con ripristino esatto.
2. Il preset Consigliato di SmartphonExpress non ha ancora una selezione per hardware, servizi, carico startup e anomalie misurate.
3. Office: il rilevamento è multi-metodo (vnextdiag/OSPP) ma richiede test reali con Microsoft 365 e Office LTSC; non è dimostrato che WinHubX rilevi più accuratamente tutte le licenze.
4. Compilazione e test Windows **non eseguiti** in questo ambiente (SDK dotnet non disponibile). Il progetto è sorgente, non un eseguibile verificato.

## Prove suggerite
Su VM Windows 11: registrare valori di `GameDVR` e policy prima/dopo `Prestazioni: effetti grafici`, controllare che rimangano invariati. Verificare che animazioni/trasparenze vengano modificate come richiesto. Per Office confrontare output `vnextdiag.ps1 -action list` e `ospp.vbs /dstatusall` con la pagina Account di Office, senza trattare l'assenza di un metodo come licenza non valida.
