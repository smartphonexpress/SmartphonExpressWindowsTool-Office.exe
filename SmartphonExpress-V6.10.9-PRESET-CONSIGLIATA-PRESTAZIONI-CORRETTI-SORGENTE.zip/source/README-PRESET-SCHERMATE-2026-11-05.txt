PRESET CONSIGLIATO / PRESTAZIONI — allineamento alle schermate del 05/11/2026

La selezione CONSIGLIATO comprende ora tutte le voci spuntate mostrate nelle due schermate, più l’installazione facoltativa di Microsoft PC Manager:
- aggiunte: Disattiva ibernazione, Windows Defender: disattiva Accesso controllato alle cartelle, Pulizia finale al prossimo riavvio, Installa Microsoft PC Manager.
- tutte le precedenti 33 voci comuni restano comprese (Office 2024, Start, Chrome, Firefox, 7-Zip, VLC, download SmartphonExpress, AppFolder, licenze, Storage Sense, ecc.).
- voci comuni totali: 37.
- PRESTAZIONI contiene tutte le 37 voci del CONSIGLIATO, aggiunge ottimizzazione programmi avvio e ottimizzazione unità, e il piano energia Prestazioni elevate solo quando la batteria risulta assente (39 o 40 voci).

NOTE: selezionare un preset non esegue azioni. PC Manager richiede ancora la conferma quando parte l’installazione. Disattivare Accesso controllato alle cartelle riduce la protezione ransomware di Windows Defender; Disattiva ibernazione influisce anche su avvio rapido, se attivo. Queste due voci sono state incluse perché esplicitamente selezionate dall’utente.

Le voci non spuntate nelle schermate restano disattivate nel preset Consigliato. Le selezioni si basano sui nomi effettivi dei tweak, senza dipendere dalla posizione dei checkbox.

Verifica statica: nomi presenti e univoci, superset Prestazioni, corrispondenza con le schermate. Test WinForms incluso nella cartella verification; compilazione/esecuzione richiede Windows con .NET SDK 8.
