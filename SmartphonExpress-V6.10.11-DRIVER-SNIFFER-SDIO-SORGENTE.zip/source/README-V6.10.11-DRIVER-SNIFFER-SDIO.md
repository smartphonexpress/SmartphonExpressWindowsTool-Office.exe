# SmartphonExpress Windows Tool V6.10.11 — Driver Sniffer e SDIO

Nuova voce: scheda **Diagnostica & Ripristino** > **Hardware, rete e driver** > **Driver Sniffer + SDIO — gestione driver**.

- Driver Sniffer: inventario in sola lettura via CIM/PNP con Hardware ID, versione, provider, INF, firma, codici problema.
- Backup driver OEM esportati dal Driver Store in una cartella vuota, tramite `pnputil /export-driver`.
- Avvio dell'eseguibile SDIO portatile selezionato dal tecnico (non incluso e non scaricato automaticamente). Viene verificato il nome file prima dell'avvio.
- Accesso alla pagina ufficiale SDIO e agli aggiornamenti facoltativi di Windows Update.
- Report testuale esportabile.
- Accesso al gestore anche dalla finestra **Diagnostica: periferiche / driver**.
- Nessuna installazione automatica di driver, nessun cambio dei preset precedenti.

**Nota:** SDIO non è distribuito nel pacchetto per ragioni di aggiornamento/provenienza; scaricalo dalla fonte ufficiale e seleziona `SDIO_x64.exe` tramite il pulsante dedicato. Non confondere Driver Sniffer con un database online: è una scansione locale hardware/driver.

**Verifica richiesta su Windows:** compilazione `dotnet publish -c Release`, esecuzione dei pulsanti Sniffer / Backup / Avvio SDIO su ambiente di test. La build non è stata eseguita nell'ambiente corrente perché manca il .NET SDK per Windows.
