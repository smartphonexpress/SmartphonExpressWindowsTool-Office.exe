# SmartphonExpress Windows Tool — 6.10.10 (patch sorgente)

## Interventi
- VLC: il link hardcoded 3.0.23 nel percorso `last/win64` non puntava al file disponibile; aggiornato al file ufficiale 3.0.24.
- Office 2024 e Microsoft 365: il recupero dell'Office Deployment Tool tenta sia la pagina Microsoft dei dettagli sia quella di conferma, cerca il vero link `officedeploymenttool*.exe`, ne controlla firma binaria MZ e dimensione e verifica l'estrazione. Gli errori di download sono riportati più chiaramente.
- Office LTSC 2024: tolto `<Remove All="TRUE" />` e `<RemoveMSI />` dal flusso di installazione, perché cancellavano programmi Office presenti in modo implicito. Resta disponibile la voce separata per la rimozione completa Office. L'installazione necessita di licenze valide LTSC/Project/Visio.
- Driver: confermata l'esistenza del precedente controllo periferiche/driver (indice 60, Diagnostica & Ripristino), che non era un aggiornatore automatico. Aggiunte due voci esplicite e ben visibili nella sezione **Hardware, rete e driver**: pagina ufficiale Snappy Driver Installer Origin; Aggiornamenti facoltativi Windows Update.
- Driver: l'installazione di driver di terze parti resta sotto controllo manuale del tecnico, non viene eseguita in batch tramite preset.
- Preset Consigliato/Prestazioni lasciati invariati; mantenuta la diagnostica esistente.

## Limitazioni della verifica
Questa patch è stata ispezionata e modificata a livello sorgente. In questo ambiente non è disponibile il .NET SDK Windows per compilare ed eseguire il progetto WinForms; verificare la build e provare i download su PC Windows prima dell'uso sui clienti.

## Compilazione
Da Windows, con .NET 8 SDK e accesso a NuGet, usare `BUILD-PORTABLE-FINAL.cmd` oppure `dotnet publish -c Release -r win-x64 --self-contained true` nella cartella source.
