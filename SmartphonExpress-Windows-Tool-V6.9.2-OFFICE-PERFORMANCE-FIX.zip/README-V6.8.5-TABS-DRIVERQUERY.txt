SmartphonExpress Windows Tool v6.8.5

- UI divisa in due schede: Principale e Diagnostica & Ripristino.
- Diagnostiche spostate fuori dalla schermata principale, senza duplicare le operazioni.
- Aggiunta diagnostica driverquery /v + /si con report esterno e log completo.
- Diagnostica periferiche/driver e driverquery escluse dai preset Consigliato/Prestazioni.
- La diagnostica rete e' ora nella scheda Diagnostica.
