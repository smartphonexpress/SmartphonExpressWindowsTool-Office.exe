SmartphonExpress Windows Tool v6.9.2

Correzioni:
- Base: v6.9.1 UEFI manual only.
- Le 3 installazioni Office sono ora mutuamente esclusive.
- Office ODT: estrazione, timeout, exit code e verifica finale ProductReleaseIds.
- Prestazioni: animazioni/trasparenze + MenuShowDelay 100 ms + MouseHoverTime 200 ms.
- Piano Prestazioni elevate ora verificato; Power Throttling disattivato solo nel preset Prestazioni.
- Ibernazione con controllo exit code e verifica registro.
- Report automatico di verifica stato ottimizzazioni dopo l'esecuzione.

Nota WinHubX:
- Non sono stati copiati tweak aggressivi alla cieca (Search/SysMain/Update/Defender/defrag).
- Sono state rafforzate solo modifiche reversibili e verificabili che migliorano la reattivita percepita.
