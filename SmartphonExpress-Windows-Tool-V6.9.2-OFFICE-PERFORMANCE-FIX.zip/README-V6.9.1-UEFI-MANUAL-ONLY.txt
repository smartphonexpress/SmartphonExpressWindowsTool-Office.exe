SmartphonExpress Windows Tool v6.9.1 — UEFI Manual Only

- "Riavvia nel BIOS / UEFI" resta disponibile come azione manuale.
- La voce è esclusa dai preset "Seleziona tutti" e "Prestazioni".
- In questo modo non viene preselezionata automaticamente e non può causare un riavvio inatteso durante l'esecuzione cumulativa.
