SmartphonExpress Windows Tool v6.8.3

- Diagnostica specifica RPC/DISM errore 1726.
- Verifica RpcSs, DcomLaunch, RpcEptMapper e TrustedInstaller senza modificarli.
- Elenca i servizi di terze parti attivi in base alla firma digitale dell'eseguibile.
- SFC/DISM allegano automaticamente questa diagnostica quando rilevano 1726.
- Test reversibile: isolamento servizi non Microsoft con snapshot dello stato precedente.
- Non tocca servizi Microsoft, driver, Defender, Firewall, RPC core o voci di avvio.
- RIPRISTINO sulla stessa voce ripristina il tipo di avvio e riavvia i servizi che erano attivi.
