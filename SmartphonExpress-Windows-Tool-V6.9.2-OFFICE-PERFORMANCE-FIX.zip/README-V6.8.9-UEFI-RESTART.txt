SmartphonExpress Windows Tool v6.8.9 — BIOS / UEFI Restart

NOVITA'
- Nuova azione: Riavvia nel BIOS / UEFI.
- Controlla PEFirmwareType prima di usare shutdown /r /fw.
- Conferma esplicita prima del riavvio immediato.
- Su sistemi non UEFI o in caso di errore propone il fallback alle Opzioni di avvio avanzato (shutdown /r /o).
- Nessuna modifica permanente al firmware o a Windows.

TEST CONSIGLIATI
1. PC Windows 11 avviato UEFI: confermare che entri nel setup firmware.
2. Annullare la conferma: il PC non deve riavviarsi.
3. Sistema Legacy/CSM o VM senza firmware setup: verificare il fallback alle Opzioni avanzate.
4. Verificare che la nuova voce sia nella scheda Diagnostica & Ripristino > Sistema e ripristino.
