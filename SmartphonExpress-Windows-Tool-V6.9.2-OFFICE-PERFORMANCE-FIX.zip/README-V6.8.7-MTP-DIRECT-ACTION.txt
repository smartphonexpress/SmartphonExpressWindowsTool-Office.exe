SmartphonExpress Windows Tool v6.8.7

- Aggiunta voce autonoma "Ripara MTP Android" nella scheda Diagnostica & Ripristino > Hardware, rete e driver.
- La stessa riparazione MTP V2 resta disponibile anche dalla finestra della diagnostica periferiche/driver.
- L'azione diretta mostra conferma, esegue backup/repair controllato e apre un report finale con nuova diagnostica.
- Esclusa dai preset automatici Consigliato/Prestazioni.
