SmartphonExpress Windows Tool V6.8.4

- Aggiunto controllo dedicato MTP Android nella diagnostica periferiche.
- Rileva vecchi pacchetti Microsoft WpdMtp duplicati nel Driver Store.
- Nuovo pulsante Ripara MTP Android.
- La riparazione verifica prima WpdMtp.inf inbox, rimuove solo pacchetti Microsoft WPD sicuri senza /force, reinstalla/riassocia il driver inbox e forza una nuova scansione PnP.
- Verifica finale del codice problema MTP.
