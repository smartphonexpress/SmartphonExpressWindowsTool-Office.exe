using Microsoft.Win32;
using System.Diagnostics;
using System.ServiceProcess;

namespace SmartphonExpressWindowsTool;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

public sealed class MainForm : Form
{
    static Image? LoadEmbeddedLogo()
    {
        try
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            using var stream = asm.GetManifestResourceStream("SmartphonExpress.logo.png");
            if (stream == null) return null;
            using var temp = Image.FromStream(stream);
            return new Bitmap(temp);
        }
        catch { return null; }
    }

    readonly TextBox log = new() { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill };
    readonly Button apply = new() { Text = "▶  ESEGUI SELEZIONATI", AutoSize = false, Width = 250, Height = 46 };
    readonly Button all = new() { Text = "SELEZIONA TUTTI", AutoSize = false, Width = 145, Height = 46 };
    readonly Button none = new() { Text = "DESELEZIONA", AutoSize = false, Width = 135, Height = 46 };
    readonly Button restore = new() { Text = "RIPRISTINO BASE", AutoSize = false, Width = 150, Height = 46 };
    readonly Button exit = new() { Text = "ESCI", AutoSize = false, Width = 90, Height = 46 };
    readonly List<CheckBox> tweakChecks = new();
    readonly string temporaryDownloadFolder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
        "Downloads",
        "SmartphonExpress");

    readonly (string Name, Action Apply, Action? Undo)[] tweaks;

    public MainForm()
    {
        try { Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

        Text = "SmartphonExpress - Windows Tool";
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96F, 96F);
        ClientSize = new Size(1280, 820);
        MinimumSize = new Size(900, 650);
        BackColor = Color.FromArgb(247, 249, 252);
        ForeColor = Color.FromArgb(24, 36, 54);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);

        tweaks = new (string, Action, Action?)[]
        {
            ("Mostra file nascosti", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","Hidden",1), () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","Hidden",2)),
            ("Mostra icone desktop classiche (Questo PC, Utente, Pannello di controllo, Cestino, Rete)", ShowClassicDesktopIcons, null),
            ("Disattiva Nuovo Outlook / migrazione", DisableNewOutlook, null),
            ("NumLock all'avvio", EnableNumLock, null),
            ("Ricerca taskbar: icona", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Search","SearchboxTaskbarMode",1), null),
            ("Disattiva aggancio finestre", () => SetCU(@"Control Panel\Desktop","WindowArrangementActive","0"), () => SetCU(@"Control Panel\Desktop","WindowArrangementActive","1")),
            ("Disattiva Consumer Features", () => SetLM(@"SOFTWARE\Policies\Microsoft\Windows\CloudContent","DisableWindowsConsumerFeatures",1), () => DelLM(@"SOFTWARE\Policies\Microsoft\Windows\CloudContent","DisableWindowsConsumerFeatures")),
            ("Explorer: disattiva auto-discovery cartelle", ExplorerFolderType, null),
            ("Disattiva WPBT", () => SetLM(@"SYSTEM\CurrentControlSet\Control\Session Manager","DisableWpbtExecution",1), () => DelLM(@"SYSTEM\CurrentControlSet\Control\Session Manager","DisableWpbtExecution")),
            ("Servizi: CscService Disabled / StorSvc Manual", ServiceTweaks, null),
            ("Privacy / Telemetria", Telemetry, null),
            ("Delivery Optimization: HTTP only", () => SetLM(@"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization","DODownloadMode",0), () => DelLM(@"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization","DODownloadMode")),
            ("Elimina file temporanei", DeleteTemp, null),
            ("Abilita Termina attività dalla taskbar", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings","TaskbarEndTask",1), () => DelCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings","TaskbarEndTask")),
            ("Disattiva ibernazione", DisableHibernate, () => Run("powercfg.exe","/hibernate on")),
            ("Blocca metadata dispositivi dalla rete", () => SetLM(@"SOFTWARE\Policies\Microsoft\Windows\Device Metadata","PreventDeviceMetadataFromNetwork",1), () => DelLM(@"SOFTWARE\Policies\Microsoft\Windows\Device Metadata","PreventDeviceMetadataFromNetwork")),
            ("Disattiva app in background", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications","GlobalUserDisabled",1), () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications","GlobalUserDisabled",0)),
            ("Edge debloat / privacy", EdgeDebloat, null),
            ("RDP: disattiva avviso firma", RdpWarning, null),
            ("Menu contestuale classico Windows 11", ClassicContextMenu, () => DelCU(@"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}","")),
            ("Disattiva funzioni Windows AI visibili", WindowsAI, null),
            ("Rimuovi Widgets", RemoveWidgets, null),
            ("Rimuovi AppX selezionate dal log", RemoveAppx, null),
            ("Blocco note: disattiva ripristino sessione / tab precedenti", DisableNotepadSessionRestore, null),
            ("Windows Defender: disattiva Accesso controllato alle cartelle", DisableControlledFolderAccess, EnableControlledFolderAccess),
            ("START — Prepara pin Office + Chrome + Firefox + Impostazioni", ConfigureStartOfficePins, null),
            ("Google Chrome", InstallChrome, null),
            ("Mozilla Firefox (Italiano)", InstallFirefox, null),
            ("7-Zip (x64)", Install7Zip, null),
            ("VLC Media Player (x64)", InstallVlc, null),
            ("Installa Microsoft 365 64 bit in italiano", InstallOffice365Italian, null),
            ("Stato attivazione Windows", CheckWindowsLicense, null),
            ("Stato attivazione Office", CheckOfficeLicense, null),
            ("PULIZIA FINALE — al prossimo riavvio, una sola volta", ScheduleOneTimeFinalCleanup, null),
            ("Rete: Fix condivisione LAN (Privata + Firewall + Servizi)", RunNetworkConfigBat, null),
            ("Rete: Fix completo / Share / Diagnostica", RunNetworkCompleteBat, null),
            ("Pulizia: Rimuovi residui KMS / KMSpico / AutoKMS", RunKmsCleanupBat, null),
            ("Download SmartphonExpress preconfigurato", DownloadPreconfiguredFile, null),
            ("Download temporaneo (URL manuale)", DownloadTemporaryFile, null),
        };

        BuildModernUi();

        all.Click += (_,__) => tweakChecks.ForEach(c => c.Checked = true);
        none.Click += (_,__) => tweakChecks.ForEach(c => c.Checked = false);
        apply.Click += async (_,__) => await ApplySelected();
        restore.Click += async (_,__) => await RestoreSelected();
        exit.Click += (_,__) => Close();
        FormClosing += (_,__) => CleanupTemporaryDownloads();

        Log("Pronto. Seleziona le operazioni da eseguire.");
        Log("SmartphonExpress Windows Tool • Service Edition");
    }

    void BuildModernUi()
    {
        SuspendLayout();

        Color bg = Color.FromArgb(247, 249, 252);
        Color sidebarBg = Color.FromArgb(242, 246, 251);
        Color cardBg = Color.White;
        Color text = Color.FromArgb(24, 36, 54);
        Color muted = Color.FromArgb(96, 111, 132);
        Color accent = Color.FromArgb(20, 113, 236);
        Color border = Color.FromArgb(220, 227, 235);

        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = bg;
        ForeColor = text;

        var shell = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = bg,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };
        shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 300));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        // ---------------- SIDEBAR ----------------
        var sidebar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = sidebarBg,
            Padding = new Padding(16, 18, 14, 16)
        };

        var brand = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 84,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent
        };
        brand.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 46));
        brand.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        var logo = new PictureBox
        {
            Dock = DockStyle.Top,
            Height = 50,
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 0, 6, 0)
        };
        var sourceLogo = LoadEmbeddedLogo();
        if (sourceLogo != null)
            logo.Image = MakeLogoForLightTheme(sourceLogo);

        var brandText = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 1,
            BackColor = Color.Transparent,
            Padding = new Padding(6, 5, 0, 0)
        };
        brandText.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        brandText.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var brandName = new Label
        {
            Text = "SmartphonExpress",
            Dock = DockStyle.Top,
            AutoSize = false,
            Height = 28,
            AutoEllipsis = false,
            Font = new Font("Segoe UI Semibold", 10.0f, FontStyle.Bold),
            ForeColor = text,
            TextAlign = ContentAlignment.MiddleLeft
        };
        var brandSub = new Label
        {
            Text = "Windows Tool",
            Dock = DockStyle.Top,
            AutoSize = true,
            Font = new Font("Segoe UI", 9.2f),
            ForeColor = muted
        };
        brandText.Controls.Add(brandName, 0, 0);
        brandText.Controls.Add(brandSub, 0, 1);
        brand.Controls.Add(logo, 0, 0);
        brand.Controls.Add(brandText, 1, 0);

        var nav = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 8, 0, 0)
        };

        var navOps = MakeNavButton("Operazioni", true, accent, text);
        var navSettings = MakeNavButton("Impostazioni", false, accent, text);
        var navInfo = MakeNavButton("Info", false, accent, text);
        var navExit = MakeNavButton("Esci", false, accent, text);

        navSettings.Click += (_,__) =>
        {
            try { Process.Start(new ProcessStartInfo("ms-settings:") { UseShellExecute = true }); }
            catch { }
        };
        navInfo.Click += (_,__) =>
        {
            string release = Application.ProductVersion;
            MessageBox.Show(
                $"SmartphonExpress Windows Tool\n" +
                $"Service Edition\n\n" +
                $"Release: v{release}\n\n" +
                $"Utility di configurazione post-formattazione per Windows.",
                "Informazioni",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        };
        navExit.Click += (_,__) => Close();

        nav.Controls.Add(navOps);
        nav.Controls.Add(navSettings);
        nav.Controls.Add(navInfo);
        nav.Controls.Add(navExit);

        var version = new Label
        {
            Dock = DockStyle.Bottom,
            Height = 62,
            Text = $"SmartphonExpress\nService Edition • v{Application.ProductVersion}",
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = muted,
            TextAlign = ContentAlignment.BottomLeft
        };

        sidebar.Controls.Add(version);
        sidebar.Controls.Add(nav);
        sidebar.Controls.Add(brand);

        // ---------------- MAIN SCROLLER ----------------
        var mainScroll = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = bg
        };

        var content = new Panel
        {
            BackColor = bg,
            Location = new Point(18, 16)
        };
        mainScroll.Controls.Add(content);

        // HEADER
        var header = new TableLayoutPanel
        {
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent,
            Height = 84
        };
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));

        var headerLeft = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 1,
            BackColor = Color.Transparent
        };
        headerLeft.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        headerLeft.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var title = new Label
        {
            Text = "Strumenti per la configurazione di Windows",
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoEllipsis = true,
            Font = new Font("Segoe UI Semibold", 17f, FontStyle.Bold),
            ForeColor = text
        };
        var desc = new Label
        {
            Text = "Seleziona le operazioni da eseguire e avvia la procedura.",
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoEllipsis = true,
            Font = new Font("Segoe UI", 9.6f),
            ForeColor = muted,
            Margin = new Padding(1, 3, 0, 0)
        };
        headerLeft.Controls.Add(title, 0, 0);
        headerLeft.Controls.Add(desc, 0, 1);

        var service = new Label
        {
            Dock = DockStyle.Fill,
            Text = "SERVICE EDITION\nPC pronti, clienti soddisfatti.",
            Font = new Font("Segoe UI", 8.3f),
            ForeColor = muted,
            TextAlign = ContentAlignment.TopRight,
            Padding = new Padding(0, 3, 0, 0)
        };
        header.Controls.Add(headerLeft, 0, 0);
        header.Controls.Add(service, 1, 0);
        content.Controls.Add(header);

        // PRIMARY CARDS
        var primaryGrid = new TableLayoutPanel
        {
            ColumnCount = 2,
            RowCount = 3,
            BackColor = Color.Transparent,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };

        var primaryCards = new List<Panel>
        {
            MakePrimaryCard("START", "Prepara pin Office, Chrome, Firefox e Impostazioni", 25, cardBg, border, text, muted, accent),
            MakePrimaryCard("Sicurezza", "Disattiva Accesso controllato alle cartelle", 24, cardBg, border, text, muted, accent),
            MakePrimaryCard("Microsoft 365", "Installa Microsoft 365 64 bit in italiano", 30, cardBg, border, text, muted, accent),
            MakePrimaryCard("Google Chrome", "Installa Google Chrome", 26, cardBg, border, text, muted, accent),
            MakePrimaryCard("Mozilla Firefox", "Installa Firefox in italiano", 27, cardBg, border, text, muted, accent),
            MakePrimaryCard("Pulizia finale", "Pulisce i temporanei al prossimo riavvio, una sola volta", 33, cardBg, border, text, muted, accent)
        };

        content.Controls.Add(primaryGrid);

        // OPTIONS GROUPS
        var optionsGrid = new TableLayoutPanel
        {
            ColumnCount = 3,
            RowCount = 1,
            BackColor = cardBg,
            Padding = new Padding(14, 12, 14, 12),
            Margin = Padding.Empty
        };
        optionsGrid.Paint += (_, e) =>
        {
            using var pen = new Pen(border);
            e.Graphics.DrawRectangle(pen, 0, 0, optionsGrid.Width - 1, optionsGrid.Height - 1);
        };

        var optionGroups = new List<Control>
        {
            MakeOptionsColumn("Sistema", Enumerable.Range(0, 10).ToArray(), text, muted, accent),
            MakeOptionsColumn("Ottimizzazione", Enumerable.Range(10, 14).ToArray(), text, muted, accent),
            MakeOptionsColumn("Utility, rete e licenze", new[] { 28, 29, 31, 32, 34, 35, 36, 37, 38 }, text, muted, accent)
        };
        content.Controls.Add(optionsGrid);

        // ACTIONS
        var actionFlow = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            AutoSize = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 4, 0, 4)
        };

        apply.Text = "▶  Esegui selezionati";
        all.Text = "Seleziona tutti";
        none.Text = "Deseleziona";
        restore.Text = "Ripristino";

        apply.AutoSize = false; apply.Size = new Size(190, 40);
        all.AutoSize = false; all.Size = new Size(112, 40);
        none.AutoSize = false; none.Size = new Size(105, 40);
        restore.AutoSize = false; restore.Size = new Size(98, 40);

        StyleFluentButton(apply, accent, Color.White, border, true);
        StyleFluentButton(all, Color.White, text, border, false);
        StyleFluentButton(none, Color.White, text, border, false);
        StyleFluentButton(restore, Color.White, text, border, false);

        var clearLog = new Button { Text = "Pulisci log", Size = new Size(100, 40) };
        StyleFluentButton(clearLog, Color.White, text, border, false);
        clearLog.Click += (_,__) => log.Clear();

        actionFlow.Controls.Add(apply);
        actionFlow.Controls.Add(all);
        actionFlow.Controls.Add(none);
        actionFlow.Controls.Add(restore);
        actionFlow.Controls.Add(clearLog);
        content.Controls.Add(actionFlow);

        // LOG
        var logPanel = new Panel
        {
            Height = 145,
            BackColor = Color.White,
            Padding = new Padding(13, 9, 13, 10)
        };
        logPanel.Paint += (_, e) =>
        {
            using var pen = new Pen(border);
            e.Graphics.DrawRectangle(pen, 0, 0, logPanel.Width - 1, logPanel.Height - 1);
        };

        var logTitle = new Label
        {
            Text = "Log operazioni",
            Dock = DockStyle.Top,
            Height = 22,
            Font = new Font("Segoe UI Semibold", 9f),
            ForeColor = muted
        };
        log.BackColor = Color.White;
        log.ForeColor = Color.FromArgb(67, 78, 93);
        log.BorderStyle = BorderStyle.None;
        log.Font = new Font("Consolas", 8.5f);
        logPanel.Controls.Add(log);
        logPanel.Controls.Add(logTitle);
        content.Controls.Add(logPanel);

        shell.Controls.Add(sidebar, 0, 0);
        shell.Controls.Add(mainScroll, 1, 0);

        Controls.Clear();
        Controls.Add(shell);

        void RebuildPrimaryGrid(int columns, int width)
        {
            primaryGrid.SuspendLayout();
            primaryGrid.Controls.Clear();
            primaryGrid.ColumnStyles.Clear();
            primaryGrid.RowStyles.Clear();

            int rows = (int)Math.Ceiling(primaryCards.Count / (double)columns);
            primaryGrid.ColumnCount = columns;
            primaryGrid.RowCount = rows;

            for (int c = 0; c < columns; c++)
                primaryGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));
            for (int r = 0; r < rows; r++)
                primaryGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));

            primaryGrid.Width = width;
            primaryGrid.Height = rows * 76;

            for (int i = 0; i < primaryCards.Count; i++)
            {
                var card = primaryCards[i];
                card.Dock = DockStyle.Fill;
                card.Margin = new Padding(0, 0, i % columns == columns - 1 ? 0 : 10, 8);
                primaryGrid.Controls.Add(card, i % columns, i / columns);
            }
            primaryGrid.ResumeLayout(true);
        }

        void RebuildOptionsGrid(int columns, int width)
        {
            optionsGrid.SuspendLayout();
            optionsGrid.Controls.Clear();
            optionsGrid.ColumnStyles.Clear();
            optionsGrid.RowStyles.Clear();

            int rows = (int)Math.Ceiling(optionGroups.Count / (double)columns);
            optionsGrid.ColumnCount = columns;
            optionsGrid.RowCount = rows;

            for (int c = 0; c < columns; c++)
                optionsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));

            int rowHeight = 410;
            for (int r = 0; r < rows; r++)
                optionsGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, rowHeight));

            optionsGrid.Width = width;
            optionsGrid.Height = rows * rowHeight + optionsGrid.Padding.Vertical;

            for (int i = 0; i < optionGroups.Count; i++)
            {
                var group = optionGroups[i];
                group.Dock = DockStyle.Fill;
                group.Margin = new Padding(6, 0, 6, 0);
                optionsGrid.Controls.Add(group, i % columns, i / columns);
            }
            optionsGrid.ResumeLayout(true);
        }

        void ApplyResponsiveLayout()
        {
            int viewport = Math.Max(520, mainScroll.ClientSize.Width - 36);

            // Cap the content width: on 4K it stays readable instead of stretching
            // from one edge of the monitor to the other.
            int contentWidth = Math.Min(1500, viewport);
            content.Width = contentWidth;
            content.Left = Math.Max(18, (mainScroll.ClientSize.Width - contentWidth) / 2);
            content.Top = 16;

            header.Width = contentWidth;
            header.Left = 0;
            header.Top = 0;

            bool small = contentWidth < 900;
            service.Visible = !small;
            header.ColumnStyles[1].Width = small ? 0 : 210;

            int y = header.Bottom + 6;

            int primaryCols = contentWidth >= 820 ? 2 : 1;
            RebuildPrimaryGrid(primaryCols, contentWidth);
            primaryGrid.Left = 0;
            primaryGrid.Top = y;
            y = primaryGrid.Bottom + 8;

            int optionCols = contentWidth >= 1180 ? 3 : (contentWidth >= 760 ? 2 : 1);
            RebuildOptionsGrid(optionCols, contentWidth);
            optionsGrid.Left = 0;
            optionsGrid.Top = y;
            y = optionsGrid.Bottom + 8;

            actionFlow.Width = contentWidth;
            actionFlow.Height = contentWidth < 760 ? 92 : 50;
            actionFlow.Left = 0;
            actionFlow.Top = y;
            y = actionFlow.Bottom + 6;

            logPanel.Width = contentWidth;
            logPanel.Left = 0;
            logPanel.Top = y;
            y = logPanel.Bottom + 16;

            content.Height = y;

            int sidebarWidth = ClientSize.Width < 1050 ? 270 : 300;
            shell.ColumnStyles[0].Width = sidebarWidth;
            brandName.Width = Math.Max(175, sidebarWidth - 64);
            foreach (Control c in nav.Controls)
                c.Width = Math.Max(145, sidebarWidth - sidebar.Padding.Horizontal);
        }

        ApplyResponsiveLayout();
        SizeChanged += (_,__) => ApplyResponsiveLayout();
        mainScroll.SizeChanged += (_,__) => ApplyResponsiveLayout();

        ResumeLayout(true);
    }

    Button MakeNavButton(string caption, bool selected, Color accent, Color text)
    {
        var b = new Button
        {
            Text = caption,
            Height = 42,
            FlatStyle = FlatStyle.Flat,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(13, 0, 0, 0),
            Margin = new Padding(0, 0, 0, 6),
            Cursor = Cursors.Hand,
            Font = new Font("Segoe UI Semibold", 9.2f),
            ForeColor = selected ? accent : text,
            BackColor = selected ? Color.FromArgb(226, 238, 252) : Color.Transparent
        };
        b.FlatAppearance.BorderSize = 0;
        b.FlatAppearance.MouseOverBackColor = Color.FromArgb(232, 239, 247);
        return b;
    }

    Panel MakePrimaryCard(
        string heading,
        string subtitle,
        int index,
        Color cardBg,
        Color border,
        Color text,
        Color muted,
        Color accent)
    {
        var panel = new Panel
        {
            BackColor = cardBg,
            Padding = new Padding(14, 8, 12, 8)
        };

        panel.Paint += (_, e) =>
        {
            using var pen = new Pen(border);
            e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
        };

        var cb = new CheckBox
        {
            Tag = index,
            AutoSize = false,
            Width = 26,
            Height = 26,
            Location = new Point(14, 21),
            BackColor = Color.Transparent
        };
        tweakChecks.Add(cb);

        var h = new Label
        {
            Text = heading,
            AutoSize = true,
            Location = new Point(48, 10),
            Font = new Font("Segoe UI Semibold", 10.2f, FontStyle.Bold),
            ForeColor = text
        };

        var sub = new Label
        {
            Text = subtitle,
            AutoEllipsis = true,
            Location = new Point(48, 34),
            Height = 24,
            Font = new Font("Segoe UI", 8.7f),
            ForeColor = muted
        };

        panel.Resize += (_,__) => sub.Width = Math.Max(80, panel.ClientSize.Width - 62);

        panel.Controls.Add(cb);
        panel.Controls.Add(h);
        panel.Controls.Add(sub);
        return panel;
    }

    Control MakeOptionsColumn(string heading, int[] indices, Color text, Color muted, Color accent)
    {
        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(2, 0, 2, 0)
        };

        var headingLabel = new Label
        {
            Text = heading,
            AutoSize = false,
            Height = 30,
            Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold),
            ForeColor = text,
            Margin = new Padding(0, 0, 0, 3)
        };
        flow.Controls.Add(headingLabel);

        foreach (int i in indices)
        {
            var cb = new CheckBox
            {
                Text = tweaks[i].Name,
                Tag = i,
                AutoSize = false,
                Height = tweaks[i].Name.Length > 52 ? 42 : 29,
                ForeColor = text,
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 8.8f),
                Margin = new Padding(0, 0, 0, 2),
                CheckAlign = ContentAlignment.TopLeft,
                TextAlign = ContentAlignment.TopLeft
            };
            tweakChecks.Add(cb);
            flow.Controls.Add(cb);
        }

        flow.Resize += (_,__) =>
        {
            int w = Math.Max(170, flow.ClientSize.Width - 8);
            headingLabel.Width = w;
            foreach (Control c in flow.Controls)
                if (c is CheckBox cb)
                    cb.Width = w;
        };

        return flow;
    }

    static void StyleFluentButton(Button b, Color bg, Color fg, Color border, bool primary)
    {
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = primary ? 0 : 1;
        b.FlatAppearance.BorderColor = border;
        b.BackColor = bg;
        b.ForeColor = fg;
        b.Font = new Font("Segoe UI Semibold", 8.9f);
        b.Margin = new Padding(0, 0, 8, 4);
        b.Cursor = Cursors.Hand;
    }

    static Image MakeLogoForLightTheme(Image source)
    {
        var bmp = new Bitmap(source.Width, source.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(bmp))
            g.DrawImage(source, 0, 0, source.Width, source.Height);

        for (int y = 0; y < bmp.Height; y++)
        for (int x = 0; x < bmp.Width; x++)
        {
            var c = bmp.GetPixel(x, y);
            if (c.A < 10) continue;
            int lum = (c.R + c.G + c.B) / 3;
            if (lum < 150)
                bmp.SetPixel(x, y, Color.FromArgb(c.A, 28, 105, 190));
        }

        source.Dispose();
        return bmp;
    }

    IEnumerable<int> CheckedTweakIndices() =>
        tweakChecks.Where(c => c.Checked).Select(c => (int)c.Tag!).OrderBy(i => i);

    async Task ApplySelected()
    {
        apply.Enabled = false;
        foreach (int i in CheckedTweakIndices().ToArray())
        {
            var t = tweaks[i];
            Log($"▶ {t.Name}");
            try { await Task.Run(t.Apply); Log("  OK"); }
            catch(Exception ex) { Log("  ERRORE: " + ex.Message); }
        }
        Run("ie4uinit.exe","-show");
        Log("Operazioni terminate. Alcune modifiche richiedono disconnessione o riavvio.");
        apply.Enabled = true;
    }

    async Task RestoreSelected()
    {
        restore.Enabled = false;
        foreach (int i in CheckedTweakIndices().ToArray())
        {
            var t = tweaks[i];
            if (t.Undo is null) { Log($"↩ {t.Name}: ripristino automatico non definito."); continue; }
            try { await Task.Run(t.Undo); Log($"↩ {t.Name}: ripristinato."); }
            catch(Exception ex) { Log("  ERRORE: " + ex.Message); }
        }
        restore.Enabled = true;
    }

    void Log(string s)
    {
        if (InvokeRequired) { BeginInvoke(() => Log(s)); return; }
        log.AppendText($"[{DateTime.Now:HH:mm:ss}] {s}\r\n");
    }

    static void SetCU(string path,string name,object value) => Set(Registry.CurrentUser,path,name,value);
    static void SetLM(string path,string name,object value) => Set(Registry.LocalMachine,path,name,value);
    static void Set(RegistryKey hive,string path,string name,object value)
    {
        using var k=hive.CreateSubKey(path,true)!;
        var kind = value is int ? RegistryValueKind.DWord : RegistryValueKind.String;
        k.SetValue(name,value,kind);
    }
    static void DelCU(string p,string n)=>Del(Registry.CurrentUser,p,n);
    static void DelLM(string p,string n)=>Del(Registry.LocalMachine,p,n);
    static void Del(RegistryKey hive,string path,string name)
    {
        using var k=hive.OpenSubKey(path,true);
        if(k!=null) k.DeleteValue(name,false);
    }
    static void Run(string file,string args)
    {
        using var p=Process.Start(new ProcessStartInfo(file,args){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true});
        p?.WaitForExit();
    }
    void ScheduleOneTimeFinalCleanup()
    {
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "SmartphonExpress", "FinalCleanup");
        Directory.CreateDirectory(baseDir);

        var psPath = Path.Combine(baseDir, "FinalCleanup-Once.ps1");
        var logPath = Path.Combine(baseDir, "FinalCleanup.log");
        var taskName = "SmartphonExpress_FinalCleanup_Once";

        string ps = """
$ErrorActionPreference = 'SilentlyContinue'
$log = '__LOGPATH__'

function Write-Log([string]$m) {
    Add-Content -Path $log -Value ("[" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "] " + $m)
}

Write-Log "Avvio pulizia finale SmartphonExpress"

$targets = @(
    "$env:WINDIR\Temp",
    "$env:ProgramData\Microsoft\Windows\WER\ReportArchive",
    "$env:ProgramData\Microsoft\Windows\WER\ReportQueue"
)

foreach ($t in $targets) {
    if (Test-Path $t) {
        Write-Log ("Pulizia: " + $t)
        Get-ChildItem -LiteralPath $t -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $ut = Join-Path $_.FullName 'AppData\Local\Temp'
    if (Test-Path $ut) {
        Write-Log ("Pulizia: " + $ut)
        Get-ChildItem -LiteralPath $ut -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

try {
    Delete-DeliveryOptimizationCache -Force -ErrorAction Stop
    Write-Log "Cache Delivery Optimization eliminata"
}
catch {
    Write-Log "Cache Delivery Optimization non disponibile o già vuota"
}

Write-Log "Pulizia finale completata"

schtasks.exe /Delete /TN "__TASKNAME__" /F | Out-Null

$cmd = Join-Path $env:TEMP 'spex-clean-self.cmd'
("@echo off`r`nping 127.0.0.1 -n 3 >nul`r`ndel /f /q `"`"__PSPATH__`"`"`r`ndel /f /q `"`"%~f0`"`"") |
    Set-Content -Path $cmd -Encoding ASCII
Start-Process -FilePath $cmd -WindowStyle Hidden
""";
        ps = ps
            .Replace("__LOGPATH__", logPath.Replace("'", "''"))
            .Replace("__TASKNAME__", taskName)
            .Replace("__PSPATH__", psPath.Replace("\"", "\"\""));

        File.WriteAllText(psPath, ps, new System.Text.UTF8Encoding(false));

        // Elimina eventuale vecchio task con lo stesso nome.
        RunCapture("schtasks.exe", $"/Delete /TN \"{taskName}\" /F");

        // Esegue al prossimo avvio come SYSTEM, quindi può pulire anche Windows\Temp.
        string tr = $"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"{psPath}\"";
        var create = RunCapture(
            "schtasks.exe",
            $"/Create /TN \"{taskName}\" /TR \"{tr.Replace("\"", "\\\"")}\" /SC ONSTART /RU SYSTEM /RL HIGHEST /F");

        if (create.ExitCode != 0)
            throw new Exception("Impossibile programmare la pulizia finale. " + create.Output);

        Log("PULIZIA FINALE: programmata per il prossimo avvio.");
        Log("PULIZIA FINALE: verrà eseguita come SYSTEM e poi il task si eliminerà da solo.");
        Log($"PULIZIA FINALE: log -> {logPath}");
        Log("PULIZIA FINALE: non vengono svuotati Cestino, Download, Documenti o file personali.");
    }

    void RunBundledBat(string fileName, string content)
    {
        string dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "SmartphonExpress", "Scripts");
        Directory.CreateDirectory(dir);

        string path = Path.Combine(dir, fileName);
        File.WriteAllText(path, content, System.Text.Encoding.Default);

        Log($"SCRIPT: avvio {fileName}");
        Log($"SCRIPT: {path}");

        using var proc = Process.Start(new ProcessStartInfo
        {
            FileName = "cmd.exe",
            Arguments = $"/c \"\"{path}\"\"",
            UseShellExecute = true,
            WorkingDirectory = dir,
            WindowStyle = ProcessWindowStyle.Normal
        });

        if (proc == null)
            throw new Exception($"Impossibile avviare {fileName}.");

        proc.WaitForExit();
        Log($"SCRIPT: {fileName} terminato con codice {proc.ExitCode}.");
    }

    void RunNetworkConfigBat()
    {
        const string script = """
@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Fix Condivisione Rete - Windows 10/11
echo.
echo ============================================
echo   FIX CONDIVISIONE CARTELLE IN RETE (LAN)
echo ============================================
echo   - Imposta profilo rete su PRIVATA
echo   - Abilita Network Discovery
echo   - Abilita File and Printer Sharing
echo   - Avvia e imposta servizi necessari
echo ============================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERRORE] Devi eseguire questo file come AMMINISTRATORE.
  echo Tasto destro ^> Esegui come amministratore
  pause
  exit /b 1
)

echo [1/4] Imposto il profilo di rete su PRIVATA...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-NetConnectionProfile | ForEach-Object { if($_.NetworkCategory -ne 'Private'){ Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private } }" ^
  >nul 2>&1

echo [2/4] Abilito le regole Firewall per Network Discovery e File Sharing...
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes >nul 2>&1
netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes >nul 2>&1

echo [3/4] Configuro e avvio i servizi necessari...
call :SvcAutoStart FDResPub
call :SvcAutoStart fdPHost
call :SvcAutoStart LanmanServer
call :SvcAutoStart LanmanWorkstation
call :SvcAutoStart SSDPSRV
call :SvcAutoStart upnphost

echo [4/4] Abilito la pubblicazione risorse (condivisione visibile in rete)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Enable-NetFirewallRule -DisplayGroup 'Network Discovery' -ErrorAction SilentlyContinue | Out-Null } catch {}" ^
  >nul 2>&1

echo.
echo ============================================
echo FATTO.
echo - Se prima non si vedevano, riavvia il PC.
echo - Verifica che i PC siano nello stesso WORKGROUP (default: WORKGROUP).
echo ============================================
echo.
pause
exit /b 0

:SvcAutoStart
set "SVC=%~1"
sc query "%SVC%" >nul 2>&1
if %errorlevel% neq 0 (
  echo   - %SVC%: non presente su questo Windows (ok).
  goto :eof
)
sc config "%SVC%" start= auto >nul 2>&1
sc start "%SVC%" >nul 2>&1
echo   - %SVC%: OK
goto :eof
""";
        RunBundledBat("configurazione rete.bat", script);
    }

    void RunNetworkCompleteBat()
    {
        const string script = """
@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Fix Condivisione Rete - Compat

set "LOG=%USERPROFILE%\Desktop\FixShare_log.txt"
echo ==== START %DATE% %TIME% ==== > "%LOG%"

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERRORE] Esegui come amministratore.>>"%LOG%"
  echo [ERRORE] Devi eseguire questo file come AMMINISTRATORE.
  pause
  exit /b 1
)

set "SHARE_FOLDER=C:\Condivisa"
set "SHARE_NAME=Condivisa"
set "SHARE_USER=ShareUser"
set "WORKGROUP_NAME=WORKGROUP"

:MENU
cls
echo ==========================================
echo  Fix Condivisione Rete - COMPAT
echo  Log: %LOG%
echo ==========================================
echo [1] Fix rete (Privata + Firewall + Servizi)
echo [2] Crea share + utente + permessi
echo [3] Diagnostica
echo [0] Esci
echo.
set /p "CHOICE=Scelta: "
if "%CHOICE%"=="1" goto FIX_NETWORK
if "%CHOICE%"=="2" goto SHARE_SETUP
if "%CHOICE%"=="3" goto DIAG
if "%CHOICE%"=="0" goto END
goto MENU

:FIX_NETWORK
echo --- FIX_NETWORK --- >> "%LOG%"

echo Imposto profilo rete su Privata...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-NetConnectionProfile | ForEach-Object { if($_.NetworkCategory -ne 'Private'){ Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private } }" ^
  >>"%LOG%" 2>&1

echo Abilito firewall Discovery e File Sharing...
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes >>"%LOG%" 2>&1
netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes >>"%LOG%" 2>&1

echo Avvio servizi...
call :SvcAutoStart FDResPub
call :SvcAutoStart fdPHost
call :SvcAutoStart LanmanServer
call :SvcAutoStart LanmanWorkstation

echo Flush DNS...
ipconfig /flushdns >>"%LOG%" 2>&1

echo.
echo OK. (Se vuoi, riavvia dopo)
pause
goto MENU

:SHARE_SETUP
echo --- SHARE_SETUP --- >> "%LOG%"

echo.
echo Imposta una password per l'utente %SHARE_USER%:
for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Read-Host 'Password' -AsSecureString; $b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($p); [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)"`) do set "PASS=%%P"

if not defined PASS (
  echo Password non letta.>>"%LOG%"
  echo [ERRORE] Non sono riuscito a leggere la password (PowerShell bloccato?).
  pause
  goto MENU
)

echo Creo cartella...
if not exist "%SHARE_FOLDER%" mkdir "%SHARE_FOLDER%" >>"%LOG%" 2>&1

echo Creo/aggiorno utente...
net user "%SHARE_USER%" >nul 2>&1
if %errorlevel% neq 0 (
  net user "%SHARE_USER%" "%PASS%" /add /y >>"%LOG%" 2>&1
) else (
  net user "%SHARE_USER%" "%PASS%" >>"%LOG%" 2>&1
)

echo Permessi NTFS...
icacls "%SHARE_FOLDER%" /inheritance:r >>"%LOG%" 2>&1
icacls "%SHARE_FOLDER%" /grant "Administrators:(OI)(CI)F" "SYSTEM:(OI)(CI)F" >>"%LOG%" 2>&1
icacls "%SHARE_FOLDER%" /grant "%COMPUTERNAME%\%SHARE_USER%:(OI)(CI)M" >>"%LOG%" 2>&1

echo Ricreo share...
net share "%SHARE_NAME%" >nul 2>&1
if %errorlevel%==0 net share "%SHARE_NAME%" /delete /y >>"%LOG%" 2>&1

net share "%SHARE_NAME%=%SHARE_FOLDER%" ^
  /grant:"%COMPUTERNAME%\%SHARE_USER%",CHANGE ^
  /grant:"Administrators",FULL ^
  /grant:"SYSTEM",FULL >>"%LOG%" 2>&1

echo.
echo Share pronta: \\%COMPUTERNAME%\%SHARE_NAME%
echo Utente: %COMPUTERNAME%\%SHARE_USER%
pause
goto MENU

:DIAG
echo --- DIAG --- >> "%LOG%"
cls
echo ====== DIAGNOSTICA ======
echo.

echo Profili rete:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetConnectionProfile | Select InterfaceAlias,NetworkCategory,IPv4Connectivity | Format-Table -AutoSize" 2>nul

echo.
echo Share presenti:
net share

echo.
echo IPv4:
ipconfig | findstr /I "IPv4"

echo.
echo (Dettagli nel log: %LOG%)
pause
goto MENU

:SvcAutoStart
set "SVC=%~1"
sc query "%SVC%" >>"%LOG%" 2>&1
sc config "%SVC%" start= auto >>"%LOG%" 2>&1
sc start "%SVC%" >>"%LOG%" 2>&1
goto :eof

:END
echo ==== END %DATE% %TIME% ====>>"%LOG%"
endlocal
exit /b 0
""";
        RunBundledBat("fix rete completo.bat", script);
    }

    void RunKmsCleanupBat()
    {
        const string script = """
@echo off
setlocal EnableExtensions EnableDelayedExpansion
title KMS/KMSpico cleanup (Windows 10/11)

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERRORE] Avvia questo file come AMMINISTRATORE.
  pause
  exit /b 1
)

echo ==========================================================
echo   KMS / KMSpico cleanup
echo   - servizi / task / cartelle / autorun
echo ==========================================================
echo.

set "LOG=%USERPROFILE%\Desktop\kms_cleanup_log.txt"
echo ==== LOG %DATE% %TIME% ==== > "%LOG%"

call :log "Avvio cleanup..."
call :log "Ricerca e rimozione servizi sospetti (kms/autokms)..."

for /f "tokens=2 delims=:" %%S in ('sc query type^= service state^= all ^| findstr /i "SERVICE_NAME:"') do (
  set "SVC=%%S"
  set "SVC=!SVC: =!"
  echo !SVC! | findstr /i "kms" >nul
  if !errorlevel! == 0 (
    call :log "Servizio trovato: !SVC!"
    sc stop "!SVC!" >> "%LOG%" 2>&1
    sc delete "!SVC!" >> "%LOG%" 2>&1
  )
)

call :log "Ricerca e rimozione Task pianificati (kms/autokms)..."
for /f "delims=" %%T in ('schtasks /Query /FO LIST /V ^| findstr /i /c:"TaskName:"') do (
  set "LINE=%%T"
  for /f "tokens=2* delims=:" %%A in ("!LINE!") do (
    set "TN=%%B"
    set "TN=!TN:~1!"
    echo !TN! | findstr /i "kms autokms" >nul
    if !errorlevel! == 0 (
      call :log "Task trovato: !TN!"
      schtasks /Delete /TN "!TN!" /F >> "%LOG%" 2>&1
    )
  )
)

call :log "Rimozione cartelle tipiche..."
call :delpath "C:\Program Files\KMSpico"
call :delpath "C:\Program Files (x86)\KMSpico"
call :delpath "C:\Windows\AutoKMS"
call :delpath "C:\Windows\System32\Tasks\AutoKMS"
call :delpath "%ProgramData%\KMSpico"
call :delpath "%ProgramData%\AutoKMS"

call :log "Pulizia voci di avvio nel Registro (Run/RunOnce con 'kms')..."
call :cleanrun "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
call :cleanrun "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"
call :cleanrun "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
call :cleanrun "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"

call :log "Controllo file hosts (solo segnalazione righe con 'kms')..."
set "HOSTS=%WINDIR%\System32\drivers\etc\hosts"
if exist "%HOSTS%" (
  findstr /i "kms" "%HOSTS%" >nul
  if !errorlevel! == 0 (
    call :log "ATTENZIONE: trovate righe con 'kms' nel file hosts:"
    findstr /i "kms" "%HOSTS%" >> "%LOG%" 2>&1
  ) else (
    call :log "OK: nessuna riga 'kms' nel file hosts."
  )
)

call :log "Fine cleanup. Riavvia il PC."
echo.
echo ==========================================================
echo COMPLETATO. Log salvato su:
echo   %LOG%
echo ==========================================================
echo.
pause
exit /b 0

:log
echo [%DATE% %TIME%] %~1
echo [%DATE% %TIME%] %~1 >> "%LOG%"
exit /b

:delpath
set "P=%~1"
if exist "%P%" (
  call :log "Elimino: %P%"
  rmdir /s /q "%P%" >> "%LOG%" 2>&1
  del /f /q "%P%" >> "%LOG%" 2>&1
) else (
  call :log "Non trovato: %P%"
)
exit /b

:cleanrun
set "K=%~1"
reg query "%K%" >nul 2>&1
if %errorlevel% neq 0 (
  call :log "Chiave non presente: %K%"
  exit /b
)
for /f "tokens=1,2,*" %%A in ('reg query "%K%" ^| findstr /i "REG_"') do (
  echo %%C | findstr /i "kms" >nul
  if !errorlevel! == 0 (
    call :log "Rimuovo autorun: [%K%] %%A = %%C"
    reg delete "%K%" /v "%%A" /f >> "%LOG%" 2>&1
  )
)
exit /b
""";
        RunBundledBat("kmsPico remove.bat", script);
    }


    void DownloadPreconfiguredFile()
    {
        const string url = "https://raw.githubusercontent.com/smartphonexpress/winutilmirror/main/attivo.rar";

        Directory.CreateDirectory(temporaryDownloadFolder);

        string archivePath = Path.Combine(temporaryDownloadFolder, "attivo.rar");

        Log("DOWNLOAD PRECONFIGURATO: scarico attivo.rar...");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.1.4");
            byte[] data = http.GetByteArrayAsync(url).GetAwaiter().GetResult();
            File.WriteAllBytes(archivePath, data);
        }

        Log($"DOWNLOAD PRECONFIGURATO: completato -> {archivePath}");
        Log("ESTRAZIONE: avvio estrazione RAR...");

        var extractedFiles = new List<string>();

        using (var archive = SharpCompress.Archives.ArchiveFactory.OpenArchive(archivePath))
        {
            string root = Path.GetFullPath(temporaryDownloadFolder);
            if (!root.EndsWith(Path.DirectorySeparatorChar))
                root += Path.DirectorySeparatorChar;

            foreach (var entry in archive.Entries)
            {
                if (entry.IsDirectory || string.IsNullOrWhiteSpace(entry.Key))
                    continue;

                string key = Convert.ToString(entry.Key) ?? string.Empty;
                string relative = key
                    .Replace('/', Path.DirectorySeparatorChar)
                    .Replace('\\', Path.DirectorySeparatorChar);

                string destination = Path.GetFullPath(
                    Path.Combine(temporaryDownloadFolder, relative));

                // Protezione da path traversal nell'archivio.
                if (!destination.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                    throw new Exception("Archivio non valido: percorso di estrazione non sicuro.");

                extractedFiles.Add(destination);
            }

            SharpCompress.Archives.IArchiveExtensions.WriteToDirectory(
                archive,
                temporaryDownloadFolder,
                new SharpCompress.Common.ExtractionOptions
                {
                    ExtractFullPath = true,
                    Overwrite = true
                });
        }

        Log($"ESTRAZIONE: completata ({extractedFiles.Count} file).");
        Log("DOWNLOAD PRECONFIGURATO: nessun file viene eseguito automaticamente.");
        Log("PULIZIA: archivio, file estratti e cartella SmartphonExpress verranno eliminati alla chiusura.");

        string? selectPath = extractedFiles.FirstOrDefault(File.Exists);

        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = selectPath is not null
                ? $"/select,\"{selectPath}\""
                : $"\"{temporaryDownloadFolder}\"",
            UseShellExecute = true
        });
    }

    void DownloadTemporaryFile()
    {
        (string Url, string Extension)? request = null;

        if (InvokeRequired)
        {
            Invoke(() => request = ShowDownloadDialog());
        }
        else
        {
            request = ShowDownloadDialog();
        }

        if (request is null)
        {
            Log("DOWNLOAD TEMP: annullato.");
            return;
        }

        string url = request.Value.Url.Trim();
        string extension = request.Value.Extension.Trim();

        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
            throw new Exception("URL non valido. Usa un indirizzo http:// o https://.");

        Directory.CreateDirectory(temporaryDownloadFolder);

        string fileName = Path.GetFileName(Uri.UnescapeDataString(uri.AbsolutePath));
        if (string.IsNullOrWhiteSpace(fileName))
            fileName = "download_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");

        // Avoid invalid Windows filename characters.
        foreach (char c in Path.GetInvalidFileNameChars())
            fileName = fileName.Replace(c, '_');

        // Optional generic extension. The user can leave it blank.
        if (!string.IsNullOrWhiteSpace(extension))
        {
            if (!extension.StartsWith("."))
                extension = "." + extension;

            // Only a simple extension is accepted; this is a rename only, never execution.
            if (extension.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||
                extension.Contains("\\") || extension.Contains("/"))
                throw new Exception("Estensione non valida.");

            if (!fileName.EndsWith(extension, StringComparison.OrdinalIgnoreCase))
                fileName += extension;
        }

        string target = Path.Combine(temporaryDownloadFolder, fileName);

        Log($"DOWNLOAD TEMP: scarico {fileName}...");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.1");
            byte[] data = http.GetByteArrayAsync(uri).GetAwaiter().GetResult();
            File.WriteAllBytes(target, data);
        }

        Log($"DOWNLOAD TEMP: completato -> {target}");
        Log("DOWNLOAD TEMP: il file NON viene eseguito automaticamente.");

        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = $"/select,\"{target}\"",
            UseShellExecute = true
        });
    }

    (string Url, string Extension)? ShowDownloadDialog()
    {
        using var dlg = new Form
        {
            Text = "Download temporaneo",
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false,
            ShowInTaskbar = false,
            ClientSize = new Size(590, 225),
            Font = new Font("Segoe UI", 9.5f)
        };

        var info = new Label
        {
            Text = "Inserisci un URL diretto al file. Il download verrà salvato in Downloads\\\\SmartphonExpress,\\naperto in Esplora file ma mai eseguito automaticamente.",
            AutoSize = true,
            Location = new Point(18, 16)
        };

        var urlLabel = new Label
        {
            Text = "URL:",
            AutoSize = true,
            Location = new Point(18, 70)
        };

        var urlBox = new TextBox
        {
            Location = new Point(18, 91),
            Width = 550
        };

        var extLabel = new Label
        {
            Text = "Estensione da aggiungere (facoltativa, es. .txt):",
            AutoSize = true,
            Location = new Point(18, 127)
        };

        var extBox = new TextBox
        {
            Location = new Point(18, 148),
            Width = 230
        };

        var ok = new Button
        {
            Text = "Scarica",
            DialogResult = DialogResult.OK,
            Location = new Point(374, 180),
            Size = new Size(92, 32)
        };

        var cancel = new Button
        {
            Text = "Annulla",
            DialogResult = DialogResult.Cancel,
            Location = new Point(476, 180),
            Size = new Size(92, 32)
        };

        dlg.Controls.AddRange(new Control[] { info, urlLabel, urlBox, extLabel, extBox, ok, cancel });
        dlg.AcceptButton = ok;
        dlg.CancelButton = cancel;

        if (dlg.ShowDialog(this) != DialogResult.OK)
            return null;

        if (string.IsNullOrWhiteSpace(urlBox.Text))
        {
            MessageBox.Show("Inserisci l'URL del file.", "Download temporaneo",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return null;
        }

        return (urlBox.Text.Trim(), extBox.Text.Trim());
    }

    void CleanupTemporaryDownloads()
    {
        try
        {
            if (!Directory.Exists(temporaryDownloadFolder))
                return;

            // Permanent deletion: no Recycle Bin.
            Directory.Delete(temporaryDownloadFolder, true);
        }
        catch (Exception ex)
        {
            try
            {
                Log("DOWNLOAD TEMP: impossibile eliminare completamente la cartella alla chiusura: " + ex.Message);
            }
            catch { }
        }
    }

    void CheckWindowsLicense()
    {
        Log("LICENZA WINDOWS: controllo stato attivazione...");

        // Metodo affidabile: interroga SoftwareLicensingProduct tramite CIM.
        string ps =
            "$p = Get-CimInstance SoftwareLicensingProduct | " +
            "Where-Object { $_.PartialProductKey -and $_.Name -like 'Windows*' } | " +
            "Sort-Object LicenseStatus -Descending | Select-Object -First 1; " +
            "if (-not $p) { Write-Output 'STATUS=UNKNOWN'; exit 2 }; " +
            "Write-Output ('NAME=' + $p.Name); " +
            "Write-Output ('DESCRIPTION=' + $p.Description); " +
            "Write-Output ('PARTIALKEY=' + $p.PartialProductKey); " +
            "Write-Output ('LICENSESTATUS=' + $p.LicenseStatus)";

        var result = RunCapture(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
        {
            foreach (var line in result.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("LICENZA WINDOWS: " + line.Trim());
        }

        if (result.ExitCode != 0)
        {
            MessageBox.Show(
                "Non sono riuscito a determinare lo stato di attivazione di Windows.\n\nControlla il log del programma.",
                "SmartphonExpress - Licenza Windows",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        int status = -1;
        var statusLine = result.Output
            .Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries)
            .FirstOrDefault(x => x.StartsWith("LICENSESTATUS=", StringComparison.OrdinalIgnoreCase));

        if (statusLine != null)
            int.TryParse(statusLine.Substring("LICENSESTATUS=".Length), out status);

        string stato = status switch
        {
            1 => "ATTIVATO",
            2 => "Periodo di tolleranza iniziale",
            3 => "Periodo di tolleranza aggiuntivo",
            4 => "Tolleranza non autentica",
            5 => "Notifica",
            6 => "Tolleranza estesa",
            0 => "NON ATTIVATO",
            _ => "STATO NON DETERMINATO"
        };

        Log("LICENZA WINDOWS: risultato = " + stato);

        MessageBox.Show(
            "Stato Windows: " + stato + "\n\nI dettagli sono riportati anche nel log.",
            "SmartphonExpress - Licenza Windows",
            MessageBoxButtons.OK,
            status == 1 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
    }
    void CheckOfficeLicense()
    {
        Log("LICENZA OFFICE: controllo stato...");

        string[] candidates =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\root\Office16\OSPP.VBS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\Office16\OSPP.VBS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\root\Office16\OSPP.VBS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\Office16\OSPP.VBS")
        };

        string? ospp = candidates.FirstOrDefault(File.Exists);

        if (ospp is null)
        {
            Log("LICENZA OFFICE: OSPP.VBS non trovato.");
            MessageBox.Show(
                "OSPP.VBS non è presente.\n\n" +
                "Con Microsoft 365 attivato tramite account, lo stato completo può non essere disponibile tramite OSPP.VBS.\n" +
                "Controlla Word/Excel > File > Account.",
                "SmartphonExpress - Licenza Office",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        Log("LICENZA OFFICE: OSPP -> " + ospp);

        var result = RunCapture(
            "cscript.exe",
            $"//Nologo \"{ospp}\" /dstatus");

        if (!string.IsNullOrWhiteSpace(result.Output))
        {
            foreach (var line in result.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("LICENZA OFFICE: " + line.Trim());
        }

        if (result.ExitCode != 0)
        {
            MessageBox.Show(
                "Il controllo licenza Office ha restituito un errore.\n\nGuarda il log per i dettagli.",
                "SmartphonExpress - Licenza Office",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        string upper = result.Output.ToUpperInvariant();
        string stato;

        if (upper.Contains("LICENSE STATUS:  ---LICENSED---") ||
            upper.Contains("LICENSE STATUS: ---LICENSED---"))
            stato = "ATTIVATO";
        else if (upper.Contains("LICENSE STATUS:"))
            stato = "NON RISULTA ATTIVATO / STATO DA VERIFICARE";
        else
            stato = "STATO NON DETERMINATO";

        Log("LICENZA OFFICE: risultato = " + stato);

        MessageBox.Show(
            "Stato Office: " + stato + "\n\nI dettagli sono riportati nel log.",
            "SmartphonExpress - Licenza Office",
            MessageBoxButtons.OK,
            stato == "ATTIVATO" ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
    }

    static void RunVisible(string exe, string args)
    {
        Process.Start(new ProcessStartInfo(exe,args){UseShellExecute=true});
    }

    static void OpenWindowsActivation() => Process.Start(new ProcessStartInfo("ms-settings:activation"){UseShellExecute=true});
    static void OpenMicrosoft365() => Process.Start(new ProcessStartInfo("https://www.microsoft365.com/"){UseShellExecute=true});

    static void PS(string command) =>
        Run("powershell.exe",$"-NoProfile -ExecutionPolicy Bypass -Command \"{command.Replace("\"","\\\"")}\"");

    static void DisableNewOutlook()
    {
        SetCU(@"SOFTWARE\Microsoft\Office\16.0\Outlook\Preferences","UseNewOutlook",0);
        SetCU(@"Software\Microsoft\Office\16.0\Outlook\Options\General","HideNewOutlookToggle",1);
        SetCU(@"Software\Policies\Microsoft\Office\16.0\Outlook\Options\General","DoNewOutlookAutoMigration",0);
        DelCU(@"Software\Policies\Microsoft\Office\16.0\Outlook\Preferences","NewOutlookMigrationUserSetting");
    }
    static void ShowClassicDesktopIcons()
    {
        string[] paths = {
            @"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel",
            @"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu"
        };
        string[] icons = {
            "{20D04FE0-3AEA-1069-A2D8-08002B30309D}", // Questo PC
            "{59031A47-3F72-44A7-89C5-5595FE6B30EE}", // File utente
            "{5399E694-6CE5-4D6C-8FCE-1D8870FDCBA0}", // Pannello di controllo
            "{645FF040-5081-101B-9F08-00AA002F954E}", // Cestino
            "{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}"  // Rete
        };
        foreach (var path in paths)
            foreach (var icon in icons)
                SetCU(path, icon, 0);

        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "HideIcons", 0);

        // Aggiorna il desktop senza chiudere forzatamente Explorer.
        Run("ie4uinit.exe", "-show");
    }

    static void EnableNumLock()
    {
        SetCU(@"Control Panel\Keyboard","InitialKeyboardIndicators","2");
        using var users=Registry.Users.CreateSubKey(@".Default\Control Panel\Keyboard",true)!;
        users.SetValue("InitialKeyboardIndicators","2",RegistryValueKind.String);
    }
    static void ExplorerFolderType()
    {
        try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags",false); } catch {}
        try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU",false); } catch {}
        SetCU(@"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell","FolderType","NotSpecified");
    }
    static void ServiceTweaks()
    {
        Run("sc.exe","config CscService start= disabled");
        Run("sc.exe","config StorSvc start= demand");
    }
    static void Telemetry()
    {
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo","Enabled",0);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Privacy","TailoredExperiencesWithDiagnosticDataEnabled",0);
        SetCU(@"Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy","HasAccepted",0);
        SetCU(@"Software\Microsoft\Input\TIPC","Enabled",0);
        SetCU(@"Software\Microsoft\InputPersonalization","RestrictImplicitInkCollection",1);
        SetCU(@"Software\Microsoft\InputPersonalization","RestrictImplicitTextCollection",1);
        SetCU(@"Software\Microsoft\InputPersonalization\TrainedDataStore","HarvestContacts",0);
        SetCU(@"Software\Microsoft\Personalization\Settings","AcceptedPrivacyPolicy",0);
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection","AllowTelemetry",0);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","Start_TrackProgs",0);
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\System","PublishUserActivities",0);
        SetCU(@"Software\Microsoft\Siuf\Rules","NumberOfSIUFInPeriod",0);
    }
    static void DeleteTemp()
    {
        foreach(var p in new[]{Path.GetTempPath(), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"Temp")})
            try { foreach(var f in Directory.EnumerateFiles(p,"*",SearchOption.TopDirectoryOnly)) try{File.Delete(f);}catch{} } catch {}
    }
    static void DisableHibernate()
    {
        SetLM(@"System\CurrentControlSet\Control\Session Manager\Power","HibernateEnabled",0);
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings","ShowHibernateOption",0);
        Run("powercfg.exe","/hibernate off");
    }
    static void EdgeDebloat()
    {
        SetLM(@"SOFTWARE\Policies\Microsoft\EdgeUpdate","CreateDesktopShortcutDefault",0);
        string p=@"SOFTWARE\Policies\Microsoft\Edge";
        SetLM(p,"PersonalizationReportingEnabled",0); SetLM(p,"ShowRecommendationsEnabled",0);
        SetLM(p,"HideFirstRunExperience",1); SetLM(p,"UserFeedbackAllowed",0); SetLM(p,"ConfigureDoNotTrack",1);
        SetLM(p,"AlternateErrorPagesEnabled",0); SetLM(p,"EdgeCollectionsEnabled",0); SetLM(p,"EdgeShoppingAssistantEnabled",0);
        SetLM(p,"MicrosoftEdgeInsiderPromotionEnabled",0); SetLM(p,"ShowMicrosoftRewards",0); SetLM(p,"WebWidgetAllowed",0);
        SetLM(p,"DiagnosticData",0); SetLM(p,"EdgeAssetDeliveryServiceEnabled",0); SetLM(p,"WalletDonationEnabled",0);
        SetLM(p,"DefaultBrowserSettingsCampaignEnabled",0);
        SetLM(p+@"\ExtensionInstallBlocklist","1","ofefcgjbeghpigppfmkologfjadafddi");
    }
    static void RdpWarning()
    {
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\Client","RedirectionWarningDialogVersion",1);
        SetCU(@"SOFTWARE\Microsoft\Terminal Server Client","RdpLaunchConsentAccepted",1);
    }
    static void ClassicContextMenu()
    {
        using var k=Registry.CurrentUser.CreateSubKey(@"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32",true)!;
        k.SetValue("","",RegistryValueKind.String);
    }
    static void WindowsAI()
    {
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer","SettingsPageVisibility","hide:aicomponents");
        SetLM(@"SOFTWARE\Policies\WindowsNotepad","DisableAIFeatures",1);
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\WindowsAI","DisableAIDataAnalysis",1);
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\WindowsAI","TurnOffWindowsCopilot",1);
        SetCU(@"Software\Policies\Microsoft\Windows\WindowsCopilot","TurnOffWindowsCopilot",1);
    }
    static void RemoveWidgets()
    {
        PS("Get-AppxPackage *WebExperience* | Remove-AppxPackage -ErrorAction SilentlyContinue");
    }
    static void RemoveAppx()
    {
        string[] pkgs = {
            "Microsoft.GetHelp","Microsoft.WindowsFeedbackHub","Microsoft.GamingApp","Microsoft.XboxGamingOverlay",
            "Microsoft.XboxIdentityProvider","Microsoft.XboxSpeechToTextOverlay","Microsoft.Xbox.TCUI",
            "Microsoft.BingSearch","Microsoft.BingNews","Microsoft.StartExperiencesApp","Microsoft.BingWeather"
        };
        foreach(var x in pkgs)
        {
            PS($"Get-AppxPackage -AllUsers '{x}' | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue; " +
               $"Get-AppxProvisionedPackage -Online | Where-Object {{$_.DisplayName -like '{x}'}} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue");
        }
    }
    static void InstallChrome() =>
        DownloadAndInstallMsi(
            "Google Chrome",
            "https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi",
            "googlechromestandaloneenterprise64.msi");

    static void InstallFirefox() =>
        DownloadAndInstall(
            "Mozilla Firefox",
            "https://download.mozilla.org/?product=firefox-latest&os=win64&lang=it",
            "firefox_installer.exe",
            "-ms");

    static void Install7Zip() =>
        DownloadAndInstall(
            "7-Zip",
            "https://www.7-zip.org/a/7z2603-x64.exe",
            "7zip_installer.exe",
            "/S");

    static void InstallVlc() =>
        DownloadAndInstall(
            "VLC Media Player",
            "https://mirror.solnet.ch/videolan/vlc/3.0.23/win64/vlc-3.0.23-win64.exe",
            "vlc_installer.exe",
            "/S");

    static void DownloadAndInstallMsi(string displayName, string url, string fileName)
    {
        string dir = Path.Combine(Path.GetTempPath(), "SmartphonExpress-Apps");
        Directory.CreateDirectory(dir);
        string installer = Path.Combine(dir, fileName);

        try
        {
            using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = true });
            http.Timeout = TimeSpan.FromMinutes(10);
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpressWindowsTool/3.0");
            using var response = http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            using (var input = response.Content.ReadAsStream())
            using (var output = new FileStream(installer, FileMode.Create, FileAccess.Write, FileShare.None))
                input.CopyTo(output);

            if (!File.Exists(installer) || new FileInfo(installer).Length < 1_000_000)
                throw new Exception("Il file MSI scaricato non sembra valido.");

            using var proc = Process.Start(new ProcessStartInfo(
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "msiexec.exe"),
                $"/i \"{installer}\" /qn /norestart")
            {
                UseShellExecute = true,
                WorkingDirectory = dir
            });
            if (proc is null) throw new Exception("Impossibile avviare Windows Installer.");
            proc.WaitForExit();

            if (proc.ExitCode != 0 && proc.ExitCode != 3010 && proc.ExitCode != 1641)
                throw new Exception($"Windows Installer terminato con codice {proc.ExitCode}.");
        }
        catch (Exception ex)
        {
            throw new Exception($"{displayName}: {ex.Message}", ex);
        }
        finally
        {
            try { if (File.Exists(installer)) File.Delete(installer); } catch { }
        }
    }

    static void DownloadAndInstall(string displayName, string url, string fileName, string arguments)
    {
        string dir = Path.Combine(Path.GetTempPath(), "SmartphonExpress-Apps");
        Directory.CreateDirectory(dir);
        string installer = Path.Combine(dir, fileName);

        try
        {
            using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = true });
            http.Timeout = TimeSpan.FromMinutes(10);
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpressWindowsTool/3.0");
            using var response = http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            using (var input = response.Content.ReadAsStream())
            using (var output = new FileStream(installer, FileMode.Create, FileAccess.Write, FileShare.None))
                input.CopyTo(output);

            if (!File.Exists(installer) || new FileInfo(installer).Length < 100_000)
                throw new Exception("Il file scaricato non sembra essere un installer valido.");

            using var proc = Process.Start(new ProcessStartInfo(installer, arguments)
            {
                UseShellExecute = true,
                WorkingDirectory = dir
            });
            if (proc is null) throw new Exception("Impossibile avviare l'installer.");
            proc.WaitForExit();

            // 0 = success; some installers use 3010 for success + reboot required.
            if (proc.ExitCode != 0 && proc.ExitCode != 3010)
                throw new Exception($"Installer terminato con codice {proc.ExitCode}.");
        }
        catch (Exception ex)
        {
            throw new Exception($"{displayName}: {ex.Message}", ex);
        }
        finally
        {
            try { if (File.Exists(installer)) File.Delete(installer); } catch { }
        }
    }


    void DisableControlledFolderAccess()
    {
        var result = RunCapture(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"Set-MpPreference -EnableControlledFolderAccess Disabled; $v=(Get-MpPreference).EnableControlledFolderAccess; Write-Output ('ControlledFolderAccess=' + $v)\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
            Log("DEFENDER CFA: " + result.Output.Replace("\r", " ").Replace("\n", " ").Trim());

        if (result.ExitCode != 0)
            throw new Exception("Impossibile disattivare Accesso controllato alle cartelle. " + result.Output);

        Log("DEFENDER CFA: Accesso controllato alle cartelle disattivato.");
    }

    void EnableControlledFolderAccess()
    {
        var result = RunCapture(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"Set-MpPreference -EnableControlledFolderAccess Enabled; $v=(Get-MpPreference).EnableControlledFolderAccess; Write-Output ('ControlledFolderAccess=' + $v)\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
            Log("DEFENDER CFA: " + result.Output.Replace("\r", " ").Replace("\n", " ").Trim());

        if (result.ExitCode != 0)
            throw new Exception("Impossibile riattivare Accesso controllato alle cartelle. " + result.Output);

        Log("DEFENDER CFA: Accesso controllato alle cartelle riattivato.");
    }

    void DisableNotepadSessionRestore()
    {
        // Microsoft documents the UI setting but not a stable public registry/GPO
        // for toggling it. Avoid writing undocumented registry values.
        var pkg = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            @"Packages\Microsoft.WindowsNotepad_8wekyb3d8bbwe\LocalState");

        Log("BLOCCO NOTE: Microsoft non espone una chiave Registry/GPO pubblica e stabile per questa preferenza.");
        Log("BLOCCO NOTE: apro direttamente le Impostazioni del Blocco note.");
        Log("BLOCCO NOTE: imposta 'Quando si avvia Blocco note' su 'Avvia nuova sessione e ignora/scarta le modifiche non salvate'.");

        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "notepad.exe",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            throw new Exception("Impossibile avviare Blocco note: " + ex.Message);
        }

        if (Directory.Exists(Path.Combine(pkg, "TabState")))
            Log("BLOCCO NOTE: rilevati dati sessione in LocalState\\TabState.");
    }

    void ConfigureStartOfficePins()
    {
        int build = Environment.OSVersion.Version.Build;
        int ubr = 0;
        try
        {
            using var cv = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            if (cv?.GetValue("UBR") is int u) ubr = u;
        }
        catch { }

        Log($"START: Windows build completa = {build}.{ubr}");

        var commonPrograms = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu), "Programs");
        var userPrograms = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs");

        string[] wanted =
        {
            "Word", "Excel", "PowerPoint", "Outlook", "OneNote", "Access", "Publisher",
            "Google Chrome", "Firefox"
        };

        var found = new List<string>();
        foreach (var app in wanted)
        {
            string? chosen = null;
            foreach (var root in new[] { commonPrograms, userPrograms })
            {
                if (!Directory.Exists(root)) continue;
                try
                {
                    var links = Directory.EnumerateFiles(root, "*.lnk", SearchOption.AllDirectories).ToList();

                    bool IsPrivateShortcut(string n) =>
                        n.Contains("anonima", StringComparison.OrdinalIgnoreCase) ||
                        n.Contains("privata", StringComparison.OrdinalIgnoreCase) ||
                        n.Contains("private", StringComparison.OrdinalIgnoreCase) ||
                        n.Contains("incognito", StringComparison.OrdinalIgnoreCase);

                    chosen = links.FirstOrDefault(x =>
                    {
                        var n = Path.GetFileNameWithoutExtension(x);
                        if (IsPrivateShortcut(n)) return false;

                        if (app == "Firefox")
                            return n.Equals("Firefox", StringComparison.OrdinalIgnoreCase)
                                || n.Equals("Mozilla Firefox", StringComparison.OrdinalIgnoreCase)
                                || (n.Contains("Firefox", StringComparison.OrdinalIgnoreCase) && !IsPrivateShortcut(n));

                        if (app == "Google Chrome")
                            return n.Equals("Google Chrome", StringComparison.OrdinalIgnoreCase)
                                || (n.Contains("Chrome", StringComparison.OrdinalIgnoreCase) && !IsPrivateShortcut(n));

                        return n.Equals(app, StringComparison.OrdinalIgnoreCase)
                            || n.StartsWith(app + " ", StringComparison.OrdinalIgnoreCase)
                            || n.StartsWith("Microsoft " + app, StringComparison.OrdinalIgnoreCase);
                    });
                }
                catch { }

                if (chosen != null) break;
            }

            if (chosen != null)
            {
                found.Add(chosen);
                Log($"START: trovato {app} -> {chosen}");
            }
            else
            {
                Log($"START: {app} non trovato, salto.");
            }
        }

        var pinned = new List<Dictionary<string, string>>
        {
            new()
            {
                ["packagedAppId"] =
                    "windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel"
            }
        };

        foreach (var link in found)
            pinned.Add(new Dictionary<string, string> { ["desktopAppLink"] = link });

        var payload = new Dictionary<string, object>
        {
            ["applyOnce"] = true,
            ["pinnedList"] = pinned
        };

        var json = System.Text.Json.JsonSerializer.Serialize(payload);
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "SmartphonExpress", "StartPins");
        Directory.CreateDirectory(baseDir);
        var jsonPath = Path.Combine(baseDir, "LayoutModification.json");
        File.WriteAllText(jsonPath, json, new System.Text.UTF8Encoding(false));
        Log($"START: JSON pin -> {jsonPath}");

        // Windows 11 24H2 con KB5062660 o successivo: usa la GPO ConfigureStartPins.
        // KB5062660 corrisponde alla build 26100.4770.
        bool gpoSupported = build > 26100 || (build == 26100 && ubr >= 4770);

        if (gpoSupported)
        {
            using var key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
                @"Software\Policies\Microsoft\Windows\Explorer", true);
            if (key == null)
                throw new Exception("Impossibile aprire la chiave policy Explorer.");

            key.SetValue(
                "ConfigureStartPins",
                jsonPath,
                Microsoft.Win32.RegistryValueKind.String);

            key.DeleteValue("ConfigureStartPinsJSON", false);

            Log($"START: ConfigureStartPins applicabile su {build}.{ubr}; REG_SZ scritto.");
            var gp = RunCapture("gpupdate.exe", "/target:user /force");
            Log($"START: gpupdate exit code = {gp.ExitCode}");
        }
        else
        {
            Log($"START: ConfigureStartPins GPO non disponibile su {build}.{ubr} (serve almeno 26100.4770).");
            Log("START: attivo comunque StartPinAppsWhenInstalled PRIMA delle installazioni.");
        }

        // Fallback per PC appena preparati: pin delle app quando vengono installate.
        string[] appIds =
        {
            "Microsoft.Office.WINWORD.EXE.15",
            "Microsoft.Office.EXCEL.EXE.15",
            "Microsoft.Office.POWERPNT.EXE.15",
            "Microsoft.Office.OUTLOOK.EXE.15",
            "Microsoft.Office.ONENOTE.EXE.15",
            "Microsoft.Office.MSACCESS.EXE.15",
            "Microsoft.Office.MSPUB.EXE.15",
            "Chrome",
            "Firefox"
        };

        using (var root = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
            @"Software\Policies\Microsoft\Windows\Explorer", true))
        {
            root?.SetValue("StartPinAppsWhenInstalled", 1, Microsoft.Win32.RegistryValueKind.DWord);
        }

        using (var list = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
            @"Software\Policies\Microsoft\Windows\Explorer\StartPinAppsWhenInstalled", true))
        {
            if (list != null)
            {
                int n = 1;
                foreach (var appId in appIds)
                    list.SetValue((n++).ToString(), appId, Microsoft.Win32.RegistryValueKind.String);
            }
        }

        // Impostazioni: usa il WMI Bridge come SYSTEM.
        // Se l'istanza non esiste, la crea invece di fallire.
        var psPath = Path.Combine(baseDir, "Enable-Settings-Pin.ps1");
        var resultPath = Path.Combine(baseDir, "SettingsPinResult.txt");

        string ps = """
$ErrorActionPreference = 'Stop'
$ns = 'root\cimv2\mdm\dmmap'
$result = '__RESULTPATH__'

try {
    $x = Get-CimInstance -Namespace $ns -ClassName MDM_Policy_Config01_Start02 -Filter "InstanceID='Start'" -ErrorAction SilentlyContinue

    if ($null -eq $x) {
        $props = @{
            ParentID = './Vendor/MSFT/Policy/Config'
            InstanceID = 'Start'
            AllowPinnedFolderSettings = 1
        }

        $x = New-CimInstance -Namespace $ns -ClassName MDM_Policy_Config01_Start02 -Property $props -ErrorAction Stop
        "CREATED InstanceID=Start" | Set-Content -Path $result -Encoding UTF8
    }
    else {
        $x.AllowPinnedFolderSettings = 1
        Set-CimInstance -CimInstance $x -ErrorAction Stop | Out-Null
        "UPDATED InstanceID=Start" | Set-Content -Path $result -Encoding UTF8
    }

    $verify = Get-CimInstance -Namespace $ns -ClassName MDM_Policy_Result01_Start02 -Filter "InstanceID='Start'" -ErrorAction SilentlyContinue
    if ($verify) {
        ("OK AllowPinnedFolderSettings=" + $verify.AllowPinnedFolderSettings) | Add-Content -Path $result -Encoding UTF8
    }
    else {
        "OK Config written; Result instance not yet available" | Add-Content -Path $result -Encoding UTF8
    }
}
catch {
    ("ERROR " + $_.Exception.Message) | Set-Content -Path $result -Encoding UTF8
    exit 1
}
""";
        ps = ps.Replace("__RESULTPATH__", resultPath.Replace("'", "''"));

        File.WriteAllText(psPath, ps, new System.Text.UTF8Encoding(false));
        try { if (File.Exists(resultPath)) File.Delete(resultPath); } catch { }

        string taskName = "SmartphonExpress_StartSettingsPin_" + Guid.NewGuid().ToString("N");
        string tr = $"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"{psPath}\"";

        var create = RunCapture(
            "schtasks.exe",
            $"/Create /TN \"{taskName}\" /TR \"{tr.Replace("\"", "\\\"")}\" /SC ONCE /ST 23:59 /RU SYSTEM /RL HIGHEST /F");

        if (create.ExitCode == 0)
        {
            var run = RunCapture("schtasks.exe", $"/Run /TN \"{taskName}\"");
            Log($"START: task SYSTEM Impostazioni avviato, exit code={run.ExitCode}");

            for (int i = 0; i < 40 && !File.Exists(resultPath); i++)
                System.Threading.Thread.Sleep(250);

            if (File.Exists(resultPath))
            {
                foreach (var line in File.ReadAllLines(resultPath))
                    Log("START: " + line);
            }
            else
            {
                Log("START: nessun risultato WMI ricevuto entro il timeout.");
            }

            RunCapture("schtasks.exe", $"/Delete /TN \"{taskName}\" /F");
        }
        else
        {
            Log("START: impossibile creare task SYSTEM per Impostazioni.");
            if (!string.IsNullOrWhiteSpace(create.Output))
                Log("START: " + create.Output.Replace("\r", " ").Replace("\n", " "));
        }

        if (gpoSupported)
        {
            Log("START: layout completo predisposto. DISCONNETTI e accedi di nuovo.");
            Log("START: con applyOnce=true potrai modificare i pin dopo la prima applicazione.");
        }
        else
        {
            Log("START: su questa build i pin delle app dipendono da StartPinAppsWhenInstalled.");
            Log("START: ora la voce START viene eseguita prima di Chrome/Firefox/Office quando selezioni tutto.");
            Log("START: per applicazione retroattiva dei pin già installati aggiorna Windows almeno a 26100.4770.");
        }
    }

    static void RemoveOldStartPinRegistryPolicy()
    {
        foreach (var hive in new[] { Microsoft.Win32.Registry.CurrentUser, Microsoft.Win32.Registry.LocalMachine })
        {
            try
            {
                using var key = hive.OpenSubKey(
                    @"Software\Policies\Microsoft\Windows\Explorer", writable: true);
                if (key == null) continue;
                key.DeleteValue("ConfigureStartPins", false);
                key.DeleteValue("ConfigureStartPinsJSON", false);
            }
            catch { }
        }
    }

    static string? FindExecutable(string name)
    {
        try
        {
            var path = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (var dir in path.Split(';', StringSplitOptions.RemoveEmptyEntries))
            {
                try
                {
                    var candidate = Path.Combine(dir.Trim(), name);
                    if (File.Exists(candidate)) return candidate;
                }
                catch { }
            }
        }
        catch { }
        return null;
    }

    static string? FindIcdExe()
    {
        string[] known =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                @"Windows Kits\10\Assessment and Deployment Kit\Imaging and Configuration Designer\x86\ICD.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                @"Windows Kits\10\Assessment and Deployment Kit\Imaging and Configuration Designer\amd64\ICD.exe")
        };

        foreach (var p in known)
            if (File.Exists(p)) return p;

        var fromPath = FindExecutable("ICD.exe");
        if (fromPath != null) return fromPath;

        try
        {
            var q = RunCapture(
                "powershell.exe",
                "-NoProfile -Command \"$p=Get-AppxPackage -Name Microsoft.WindowsConfigurationDesigner | Select-Object -First 1 -ExpandProperty InstallLocation; if($p){Write-Output $p}\"");
            var installLocation = q.Output.Trim();
            if (Directory.Exists(installLocation))
            {
                var found = Directory.EnumerateFiles(
                    installLocation, "ICD.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (found != null) return found;
            }
        }
        catch { }

        return null;
    }

    static (int ExitCode, string Output) RunCapture(string file, string args)
    {
        using var p = Process.Start(new ProcessStartInfo(file, args)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        });

        if (p == null) return (-1, "Impossibile avviare il processo.");

        string stdout = p.StandardOutput.ReadToEnd();
        string stderr = p.StandardError.ReadToEnd();
        p.WaitForExit();

        string output = (stdout + Environment.NewLine + stderr).Trim();
        return (p.ExitCode, output);
    }

    static string? FindStartShortcut(string root, string appName)
    {
        if (string.IsNullOrWhiteSpace(root) || !Directory.Exists(root)) return null;
        try
        {
            return Directory.EnumerateFiles(root, "*.lnk", SearchOption.AllDirectories)
                .FirstOrDefault(f => string.Equals(Path.GetFileNameWithoutExtension(f), appName, StringComparison.OrdinalIgnoreCase)
                                  || Path.GetFileNameWithoutExtension(f).StartsWith(appName + " ", StringComparison.OrdinalIgnoreCase));
        }
        catch { return null; }
    }

    static void InstallOffice365Italian()
    {
        // Microsoft 365 Apps for enterprise, Current Channel, 64-bit, Italian.
        // Uses Microsoft's Office Deployment Tool downloaded at runtime.
        string work = Path.Combine(Path.GetTempPath(), "SmartphonExpress-ODT");
        Directory.CreateDirectory(work);
        string odt = Path.Combine(work, "officedeploymenttool.exe");
        string setup = Path.Combine(work, "setup.exe");
        string xml = Path.Combine(work, "configuration.xml");

        // Official Microsoft Download Center short link for the current Office Deployment Tool.
        using (var wc = new System.Net.WebClient())
            wc.DownloadFile("https://www.microsoft.com/en-us/download/details.aspx?id=49117", Path.Combine(work, "odt-page.html"));

        // Resolve the current Microsoft-hosted ODT executable URL from the official page.
        string html = File.ReadAllText(Path.Combine(work, "odt-page.html"));
        var m = System.Text.RegularExpressions.Regex.Match(
            html,
            @"https://download\.microsoft\.com/download/[^""']+officedeploymenttool[^""']+\.exe",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if (!m.Success) throw new Exception("Impossibile trovare il download ufficiale corrente di Office Deployment Tool.");
        using (var wc = new System.Net.WebClient())
            wc.DownloadFile(System.Net.WebUtility.HtmlDecode(m.Value), odt);

        Run(odt, $"/quiet /extract:{Quote(work)}");
        if (!File.Exists(setup)) throw new Exception("Office Deployment Tool: setup.exe non estratto.");

        string config = """
<Configuration>
  <Add OfficeClientEdition="64" Channel="Current" AllowCdnFallback="TRUE">
    <Product ID="O365ProPlusRetail">
      <Language ID="it-it" />
    </Product>
  </Add>
  <Updates Enabled="TRUE" />
  <Display Level="Full" AcceptEULA="TRUE" />
</Configuration>
""";
        File.WriteAllText(xml, config, new System.Text.UTF8Encoding(false));

        Run(setup, $"/configure {Quote(xml)}");
    }

    static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
}
