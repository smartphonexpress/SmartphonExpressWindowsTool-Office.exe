SmartphonExpress Windows Tool v6.9.8
UI VISIBILITY FIX

Correzione rispetto alla v6.9.7:
- La voce "Ripara Windows Search / Cerca (crash Explorer)" ora e visibile nella scheda Diagnostica & Ripristino, gruppo Servizi e compatibilita.
- Anche "Riavvia nel BIOS / UEFI", gia presente nel codice ma non esposto dalla griglia della scheda, e ora visibile nello stesso gruppo.
- Entrambe restano manuali/facoltative ed escluse da Seleziona tutti/Consigliato e Prestazioni.
- Nessuna modifica alle altre funzioni della v6.9.7.
