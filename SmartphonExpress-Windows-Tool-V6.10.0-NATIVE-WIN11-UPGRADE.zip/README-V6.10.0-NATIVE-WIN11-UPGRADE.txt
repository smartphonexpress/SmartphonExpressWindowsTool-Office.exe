SMARTPHONEXPRESS WINDOWS TOOL V6.10.0
NATIVE WINDOWS 11 UNSUPPORTED UPGRADE

- La funzione "Upgrade Windows 11 su PC non supportato" non scarica piu Flyby11/FlyOOBE.
- Selezione manuale di una ISO ufficiale Windows 11.
- Mount ISO tramite Mount-DiskImage.
- Imposta AllowUpgradesWithUnsupportedTPMOrCPU=1.
- Avvia setup.exe /product server per il percorso di bypass hardware.
- Windows Setup resta interattivo: verificare "Mantieni file personali e app" prima di installare.
- Funzione manuale/facoltativa, esclusa da Seleziona tutti e Prestazioni.
- Le voci separate di download FlyOOBE/Flyby11 gia presenti nel Tool non vengono usate da questa funzione.
