using System.Reflection;
using SmartphonExpressWindowsTool;

internal static class PresetChecks
{
    const BindingFlags Instance = BindingFlags.Instance | BindingFlags.NonPublic;
    static void Require(bool ok, string message) { if (!ok) throw new Exception(message); }
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        using var form = new MainForm(); // Never shown: no Shown diagnostics or Apply actions.
        var checks = (List<CheckBox>)typeof(MainForm).GetField("tweakChecks", Instance)!.GetValue(form)!;
        var tweaks = ((string Name, Action Apply, Action? Undo)[])typeof(MainForm).GetField("tweaks", Instance)!.GetValue(form)!;
        int applied = 0;
        for (int i = 0; i < tweaks.Length; i++) tweaks[i] = (tweaks[i].Name, () => applied++, () => applied++);
        var policy = typeof(MainForm).GetMethod("GetPresetSelection", BindingFlags.Static | BindingFlags.NonPublic)!;
        HashSet<string> Selection(bool advanced, bool battery) => (HashSet<string>)policy.Invoke(null, new object[] { advanced, battery })!;
        void Click(string field) => typeof(Button).GetMethod("OnClick", Instance)!.Invoke(typeof(MainForm).GetField(field, Instance)!.GetValue(form), new object[] { EventArgs.Empty });
        HashSet<string> Actual() => checks.Where(c => c.Checked).Select(c => tweaks[(int)c.Tag!].Name).ToHashSet();
        bool battery = SystemInformation.PowerStatus.BatteryChargeStatus != BatteryChargeStatus.NoSystemBattery;
        Require(checks.Select(c => (int)c.Tag!).Distinct().Count() == tweaks.Length, "Missing checkbox mapping");
        foreach (bool advanced in new[] { false, true })
        foreach (bool onBattery in new[] { false, true })
        {
            var expected = Selection(advanced, onBattery);
            Require(expected.Contains("Crea AppFolder sul Desktop"), "AppFolder missing");
            foreach (string required in new[] { "Disattiva ibernazione", "Windows Defender: disattiva Accesso controllato alle cartelle", "PULIZIA FINALE — al prossimo riavvio, una sola volta", "Installa Microsoft PC Manager (facoltativo)", "Rimuovi Widgets", "Rimuovi AppX selezionate dal log", "DNS Google — primario / secondario" })
                Require(expected.Contains(required), "Missing screenshot selection: " + required);
            Require(expected.Contains("Installa Office LTSC 2024 completo 64 bit in italiano") && !expected.Contains("Installa Microsoft 365 64 bit in italiano") && !expected.Contains("Microsoft 365 completo + Visio + Project 64 bit ITA"), "Default Office selection");
            Require(expected.All(n => tweaks.Any(t => t.Name == n)), "Unknown preset entry");
            Require(expected.Contains("Prestazioni: piano energia Prestazioni elevate") == (advanced && !onBattery), "Power plan policy");
            Require(!expected.Contains("DNS Cloudflare — primario / secondario"), "Google/Cloudflare both in default");
            Require(!expected.Any(n => n.StartsWith("Diagnostica:") || n.StartsWith("Ripristino:")), "Diagnostics incorrectly selected");
            Require(!expected.Contains("Riavvia nel BIOS / UEFI"), "Firmware restart selected");
            Require(!expected.Contains("Office: rimozione completa (tutte le versioni)"), "Office removal selected");
            if (advanced) Require(expected.IsSupersetOf(Selection(false, onBattery)), "Common selections lost");
        }
        checks.Reverse(); // UI order must not determine the tweak association.
        checks.ForEach(c => c.Checked = true);
        Click("all");
        Require(Actual().SetEquals(Selection(false, battery)), "Recommended click mismatch");
        Click("performanceSelect");
        Require(Actual().SetEquals(Selection(true, battery)), "Performance click mismatch");
        Click("all");
        Require(Actual().SetEquals(Selection(false, battery)), "Performance -> recommended mismatch");
        Click("all");
        Require(Actual().SetEquals(Selection(false, battery)), "Repeated click mismatch");
        Click("none");
        Require(Actual().Count == 0, "Deselect failed");
        Click("performanceSelect");
        Require(Actual().Contains("Crea AppFolder sul Desktop"), "AppFolder not reselected");
        foreach (int index in new[] { 30, 43, 61 })
        {
            checks.Single(c => (int)c.Tag! == index).Checked = true;
            Require(checks.Count(c => new[] { 30, 43, 61 }.Contains((int)c.Tag!) && c.Checked) == 1, "Office alternatives broken");
        }
        checks.Single(c => (int)c.Tag! == 44).Checked = true;
        checks.Single(c => (int)c.Tag! == 45).Checked = true;
        Require(!checks.Single(c => (int)c.Tag! == 44).Checked, "DNS alternatives broken");
        Require(applied == 0, "Selecting a preset executed actions");
        Console.WriteLine($"PASS: real button handlers, {checks.Count} checkbox mappings, transitions, AppFolder, battery policy, Office/DNS alternatives, no actions executed. Recommended={Selection(false,battery).Count}, Performance={Selection(true,battery).Count}.");
    }
}
