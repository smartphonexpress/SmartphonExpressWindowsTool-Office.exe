AGGIORNAMENTO PRESET 05/11/2026

Entrambi i preset ora selezionano anche Rimuovi Widgets, Rimuovi AppX selezionate dal log e DNS Google primario/secondario. DNS Cloudflare resta non selezionato (mutua esclusione).

DIAGNOSTICA E RIPRISTINO: la scheda era gia presente nel sorgente originario e resta invariata. Non viene selezionata automaticamente nei preset: operazioni diagnostiche e di riparazione da avviare manualmente.

Il profilo Prestazioni resta il superset di Consigliato; piano energia Prestazioni elevate escluso per batterie presenti o stato sconosciuto.

NOTA: le operazioni rimuovi AppX, Widgets e cambi DNS sono modifiche effettive del sistema quando si preme Esegui selezionati.
