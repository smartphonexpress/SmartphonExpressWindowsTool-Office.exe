SmartphonExpress Windows Tool v6.9.5 — Compile Fix

Correzione degli escape C# nelle stringhe di diagnostica NumLock introdotte nella 6.9.4.
Le funzionalità NumLock e menu contestuale classico restano invariate.
