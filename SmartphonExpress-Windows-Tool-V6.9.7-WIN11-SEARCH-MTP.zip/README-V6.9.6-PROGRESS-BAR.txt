SmartphonExpress Windows Tool v6.9.6 — Barra di avanzamento

- Aggiunta barra di avanzamento generale azzurrina sotto i pulsanti azione.
- Mostra operazione corrente, percentuale e conteggio X di Y.
- La percentuale rappresenta il progresso reale della coda di operazioni selezionate; non inventa percentuali interne per comandi che non le espongono.
- Integrata anche nel Ripristino.
- Il log operazioni resta invariato e completo.
