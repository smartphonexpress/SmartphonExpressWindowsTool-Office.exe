SmartphonExpress Windows Tool v6.9.7
WIN11 UNSUPPORTED UPGRADE + WINDOWS SEARCH FIX + MTP BINDING FIX

Base: v6.9.6 Progress Bar.

NOVITA'
1) Windows 11: prepara upgrade su hardware non supportato
- Voce manuale, non selezionata da "Seleziona tutti" o "Prestazioni".
- Rileva TPM e stato Windows.
- Imposta AllowUpgradesWithUnsupportedTPMOrCPU=1 sotto MoSetup.
- Se TPM 1.2/2.0 non viene rilevato, segnala che MoSetup da solo non basta e propone il download/estrazione di FlyOOBE gia' integrato nel Tool.
- Non avvia automaticamente setup/upgrade.

2) Ripara Windows Search / Cerca (crash Explorer)
- Voce manuale/facoltativa, esclusa dai preset automatici.
- Arresta SearchHost/SearchApp se presenti.
- Verifica e riavvia WSearch; lo riabilita solo se era Disabled.
- Registra nuovamente i pacchetti MicrosoftWindows.Client.CBS / Microsoft.Windows.Search presenti per l'utente.
- Non cancella file personali e non azzera automaticamente l'indice.
- Riavvia Explorer al termine e verifica SearchHost.

3) MTP Android
- Estesa la rilevazione ai dispositivi MS_COMP_MTP con binding incompleto / classe diversa da WPD anche quando ConfigManagerErrorCode e' 0.
- Copre il caso reale verificato in cui un vecchio wpdmtp OEM prevale sul driver inbox e Windows finisce con binding NULL pur mostrando ProblemCode 0.

NOTA BUILD
Il sorgente e' stato aggiornato, ma l'ambiente di generazione non dispone del .NET SDK. Compilare con BUILD-EXE.cmd su Windows come per le build precedenti.
