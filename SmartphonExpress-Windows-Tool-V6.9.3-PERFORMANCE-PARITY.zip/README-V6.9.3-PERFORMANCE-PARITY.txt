SmartphonExpress Windows Tool v6.9.3 — Performance parity

Confronto statico con WinHubX: integrate soltanto modifiche prestazioni verificabili e reversibili.

Aggiunto nel profilo Prestazioni:
- StartupDelayInMSec = 0 (avvio desktop più immediato)
- Game DVR / cattura in background disattivata
- Edge Startup Boost disattivato
- Edge background mode disattivato
- verifica post-applicazione di tutte le nuove impostazioni

Già presenti e mantenuti:
- animazioni/trasparenze ridotte
- MenuShowDelay / MouseHoverTime
- applicazioni in background
- power plan Prestazioni elevate + Power Throttling off
- startup optimizer conservativo
- TRIM/Optimize e verifica

NON copiati automaticamente i tweak WinHubX più invasivi o non universalmente utili
(es. disattivazione Search/indicizzazione, SysMain/Superfetch, Windows Update, manutenzione automatica, Defender/Firewall, Reserved Storage).
