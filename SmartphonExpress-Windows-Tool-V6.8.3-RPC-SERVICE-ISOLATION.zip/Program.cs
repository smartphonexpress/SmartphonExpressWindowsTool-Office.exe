﻿using Microsoft.Win32;
using System.Diagnostics;
using System.ServiceProcess;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Text;

namespace SmartphonExpressWindowsTool;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}

public sealed class MainForm : Form
{
    // Snapshot usato esclusivamente dallo switch Defender temporaneo.
    // Al ripristino vengono rimessi SOLO i valori modificati dallo switch.
    bool defenderTemporaryOffByTool = false;
    bool defenderRestoreInProgress = false;
    bool defenderOldRealtimeDisabled;
    int defenderOldMapsReporting;
    int defenderOldSubmitSamplesConsent;
    bool defenderOldBlockAtFirstSeenDisabled;
    Button? defenderToggleButton;
    Label? defenderQuickStatusLabel;
    const int ERROR_SUCCESS = 0;
    const int KEY_QUERY_VALUE = 0x0001;
    const int KEY_SET_VALUE = 0x0002;
    const int REG_PROCESS_APPKEY = 0x00000001;

    // Tipi usati internamente dal settings.dat delle app Store/UWP.
    // Windows Notepad usa questi tipi custom nel proprio application hive.
    const uint NOTEPAD_SETTING_UINT32 = 0x05F5E104;
    const uint NOTEPAD_SETTING_BOOL   = 0x05F5E10B;

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern int RegLoadAppKey(
        string lpFile,
        out IntPtr phkResult,
        int samDesired,
        int dwOptions,
        int reserved);

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern int RegSetValueEx(
        IntPtr hKey,
        string lpValueName,
        int reserved,
        uint dwType,
        byte[] lpData,
        int cbData);

    [DllImport("advapi32.dll")]
    static extern int RegCloseKey(IntPtr hKey);

    static Image? LoadEmbeddedLogo()
    {
        try
        {
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            using var stream = asm.GetManifestResourceStream("SmartphonExpress.logo.png");
            if (stream == null) return null;
            using var temp = Image.FromStream(stream);
            return new Bitmap(temp);
        }
        catch { return null; }
    }

    readonly TextBox log = new() { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill };
    readonly Button apply = new() { Text = "▶  ESEGUI SELEZIONATI", AutoSize = false, Width = 250, Height = 46 };
    readonly Button all = new() { Text = "CONSIGLIATO", AutoSize = false, Width = 145, Height = 46 };
    readonly Button none = new() { Text = "DESELEZIONA", AutoSize = false, Width = 135, Height = 46 };
    readonly Button performanceSelect = new() { Text = "PRESTAZIONI", AutoSize = false, Width = 175, Height = 46 };
    readonly Button restore = new() { Text = "RIPRISTINO BASE", AutoSize = false, Width = 150, Height = 46 };
    readonly Button exit = new() { Text = "ESCI", AutoSize = false, Width = 90, Height = 46 };
    readonly ToolTip helpTip = new()
    {
        AutoPopDelay = 12000,
        InitialDelay = 250,
        ReshowDelay = 100,
        ShowAlways = true
    };
    readonly List<CheckBox> tweakChecks = new();
    int currentRunTimeouts = 0;
    string windowsActivationSummary = "NON CONTROLLATO";
    string officeActivationSummary = "NON CONTROLLATO";
    bool collectDiagnosticReports;
    readonly List<(string Title, string Report)> diagnosticReports = new();

    readonly string temporaryDownloadFolder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
        "Downloads",
        "SmartphonExpress");

    readonly (string Name, Action Apply, Action? Undo)[] tweaks;

    public MainForm()
    {
        try { Icon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

        Text = "SmartphonExpress - Windows Tool";
        AutoScaleMode = AutoScaleMode.Dpi;
        AutoScaleDimensions = new SizeF(96F, 96F);
        ClientSize = new Size(1280, 820);
        MinimumSize = new Size(900, 650);
        BackColor = Color.FromArgb(247, 249, 252);
        ForeColor = Color.FromArgb(24, 36, 54);
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);

        tweaks = new (string, Action, Action?)[]
        {
            ("Mostra file nascosti", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","Hidden",1), () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","Hidden",2)),
            ("Mostra icone desktop classiche (Questo PC, Utente, Pannello di controllo, Cestino, Rete)", ShowClassicDesktopIcons, null),
            ("Disattiva Nuovo Outlook / migrazione", DisableNewOutlook, null),
            ("NumLock all'avvio", EnableNumLock, null),
            ("Ricerca taskbar: icona", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Search","SearchboxTaskbarMode",1), null),
            ("Disattiva aggancio finestre", () => SetCU(@"Control Panel\Desktop","WindowArrangementActive","0"), () => SetCU(@"Control Panel\Desktop","WindowArrangementActive","1")),
            ("Disattiva Consumer Features", () => SetLM(@"SOFTWARE\Policies\Microsoft\Windows\CloudContent","DisableWindowsConsumerFeatures",1), () => DelLM(@"SOFTWARE\Policies\Microsoft\Windows\CloudContent","DisableWindowsConsumerFeatures")),
            ("Explorer: disattiva auto-discovery cartelle", ExplorerFolderType, null),
            ("Disattiva WPBT", () => SetLM(@"SYSTEM\CurrentControlSet\Control\Session Manager","DisableWpbtExecution",1), () => DelLM(@"SYSTEM\CurrentControlSet\Control\Session Manager","DisableWpbtExecution")),
            ("Servizi avanzati: CscService Disabled / StorSvc Manual", ServiceTweaks, null),
            ("Privacy / Telemetria", Telemetry, null),
            ("Delivery Optimization: HTTP only", () => SetLM(@"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization","DODownloadMode",0), () => DelLM(@"SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization","DODownloadMode")),
            ("Elimina file temporanei", DeleteTemp, null),
            ("Abilita Termina attività dalla taskbar", () => SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings","TaskbarEndTask",1), () => DelCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\TaskbarDeveloperSettings","TaskbarEndTask")),
            ("Disattiva ibernazione", DisableHibernate, () => Run("powercfg.exe","/hibernate on")),
            ("Blocca metadata dispositivi dalla rete", () => SetLM(@"SOFTWARE\Policies\Microsoft\Windows\Device Metadata","PreventDeviceMetadataFromNetwork",1), () => DelLM(@"SOFTWARE\Policies\Microsoft\Windows\Device Metadata","PreventDeviceMetadataFromNetwork")),
            ("Disattiva app in background", DisableBackgroundApps, RestoreBackgroundApps),
            ("Edge debloat / privacy", EdgeDebloat, null),
            ("RDP: disattiva avviso firma", RdpWarning, null),
            ("Menu contestuale classico Windows 11", ClassicContextMenu, () => DelCU(@"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}","")),
            ("Disattiva funzioni Windows AI visibili", WindowsAI, null),
            ("Rimuovi Widgets", RemoveWidgets, null),
            ("Rimuovi AppX selezionate dal log", RemoveAppx, null),
            ("Blocco note: disattiva ripristino sessione / tab precedenti", DisableNotepadSessionRestore, null),
            ("Windows Defender: disattiva Accesso controllato alle cartelle", DisableControlledFolderAccess, EnableControlledFolderAccess),
            ("START — Prepara pin Office + Chrome + Firefox + Impostazioni", ConfigureStartOfficePins, null),
            ("Google Chrome", InstallChrome, null),
            ("Mozilla Firefox (Italiano)", InstallFirefox, null),
            ("7-Zip (x64)", Install7Zip, null),
            ("VLC Media Player (x64)", InstallVlc, null),
            ("Installa Microsoft 365 64 bit in italiano", InstallOffice365Italian, null),
            ("Stato attivazione Windows", CheckWindowsLicense, null),
            ("Stato attivazione Office", CheckOfficeLicense, null),
            ("PULIZIA FINALE — al prossimo riavvio, una sola volta", ScheduleOneTimeFinalCleanup, null),
            ("Rete: Fix condivisione LAN (Privata + Firewall + Servizi)", RunNetworkConfigBat, null),
            ("Rete: Fix completo / Share / Diagnostica", RunNetworkCompleteBat, null),
            ("Pulizia: Rimuovi residui KMS / KMSpico / AutoKMS", RunKmsCleanupBat, null),
            ("Download SmartphonExpress preconfigurato", DownloadPreconfiguredFile, null),
            ("Download temporaneo (URL manuale)", DownloadTemporaryFile, null),
            ("Crea AppFolder sul Desktop", CreateAppFolderShortcut, null),
            ("Windows: disattiva SmartScreen / controlli reputazione app", DisableAppReputationControls, RestoreAppReputationControls),
            ("Scarica / estrai FlyOOBE", DownloadFlyOobe, null),
            ("Scarica / estrai Flyby11", DownloadFlyby11, null),
            ("Installa Office LTSC 2024 completo 64 bit in italiano", InstallOffice2024CompleteItalian, null),
            ("DNS Google — primario / secondario", SetGoogleDns, ResetDnsAutomatic),
            ("DNS Cloudflare — primario / secondario", SetCloudflareDns, ResetDnsAutomatic),
            ("Storage Sense sicuro — temporanei settimanali, niente Download/Cestino", EnableSafeStorageSense, RestoreStorageSense),
            ("Diagnostica rete — gateway, DHCP, DNS, IPv4/IPv6, velocità link", RunNetworkDiagnostics, null),

            // PERFORMANCE EDITION
            ("Prestazioni: riduci animazioni e trasparenze", EnablePerformanceVisuals, RestorePerformanceVisuals),
            ("Prestazioni: piano energia Prestazioni elevate", EnableHighPerformancePlan, RestoreBalancedPowerPlan),
            ("Prestazioni: ottimizza programmi in avvio automatico", OptimizeStartupPrograms, RestoreStartupPrograms),
            ("Prestazioni: ottimizza unità di sistema (TRIM/Optimize)", OptimizeSystemDrive, null),
            ("Prestazioni: verifica TRIM SSD", CheckTrimStatus, null),
            ("Prestazioni: analisi programmi in avvio automatico", AuditStartupPrograms, null),
            ("Prestazioni: check hardware/software rapido", RunPerformanceCheck, null),

            // DIAGNOSTICA E RIPRISTINO
            ("Diagnostica: SFC /Scannow", RunSfcScan, null),
            ("Diagnostica: DISM RestoreHealth", RunDismRestoreHealth, null),
            ("Ripristino: reset componenti Windows Update", ResetWindowsUpdateComponents, null),
            ("Diagnostica: stato WinRE / Recovery", CheckWinReStatus, null),
            ("Diagnostica: batteria / salute e capacità", RunBatteryHealthCheck, null),
            ("Diagnostica: periferiche / driver", RunDriverDiagnostics, null),

            // OFFICE EXTRA
            ("Microsoft 365 completo + Visio + Project 64 bit ITA", InstallOffice365CompleteItalian, null),
            ("Office: rimozione completa (tutte le versioni)", UninstallAllOffice, null),

            // DIAGNOSTICA CONFLITTI SERVIZI / RPC
            ("Diagnostica: conflitti servizi / RPC 1726", RunRpcServiceConflictDiagnostics, null),
            ("Ripristino: isola servizi non Microsoft (test)", PrepareThirdPartyServiceIsolation, RestoreThirdPartyServiceIsolation),
        };

        BuildModernUi();

        // Office 2024 e Microsoft 365 sono alternative: selezionarne uno deseleziona l'altro.
        var office365Check = tweakChecks.FirstOrDefault(c => Convert.ToInt32(c.Tag) == 30);
        var office2024Check = tweakChecks.FirstOrDefault(c => Convert.ToInt32(c.Tag) == 43);

        if (office365Check is not null && office2024Check is not null)
        {
            office365Check.CheckedChanged += (_,__) =>
            {
                if (office365Check.Checked)
                    office2024Check.Checked = false;
            };

            office2024Check.CheckedChanged += (_,__) =>
            {
                if (office2024Check.Checked)
                    office365Check.Checked = false;
            };
        }

        // Google DNS e Cloudflare DNS sono alternative.
        var googleDnsCheck = tweakChecks.FirstOrDefault(c => Convert.ToInt32(c.Tag) == 44);
        var cloudflareDnsCheck = tweakChecks.FirstOrDefault(c => Convert.ToInt32(c.Tag) == 45);

        if (googleDnsCheck is not null && cloudflareDnsCheck is not null)
        {
            googleDnsCheck.CheckedChanged += (_,__) =>
            {
                if (googleDnsCheck.Checked)
                    cloudflareDnsCheck.Checked = false;
            };

            cloudflareDnsCheck.CheckedChanged += (_,__) =>
            {
                if (cloudflareDnsCheck.Checked)
                    googleDnsCheck.Checked = false;
            };
        }

        all.Click += (_,__) =>
        {
            var esclusiDaSelezionaTutti = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "Download temporaneo (URL manuale)",
                "Crea AppFolder sul Desktop",
                "Rete: Fix condivisione LAN (Privata + Firewall + Servizi)",
                "Rete: Fix completo / Share / Diagnostica",
                "Pulizia: Rimuovi residui KMS / KMSpico / AutoKMS",
                "Scarica / estrai FlyOOBE",
                "Scarica / estrai Flyby11",
                "Installa Microsoft 365 64 bit in italiano",
                "Office: rimozione completa (tutte le versioni)",
                "DNS Google — primario / secondario",
                "DNS Cloudflare — primario / secondario",
                "Servizi avanzati: CscService Disabled / StorSvc Manual",
                "Diagnostica rete — gateway, DHCP, DNS, IPv4/IPv6, velocità link",
                "Prestazioni: piano energia Prestazioni elevate",
                "Prestazioni: ottimizza programmi in avvio automatico",
                "Prestazioni: ottimizza unità di sistema (TRIM/Optimize)",
                "Prestazioni: verifica TRIM SSD",
                "Prestazioni: analisi programmi in avvio automatico",
                "Prestazioni: check hardware/software rapido",
                "Diagnostica: SFC /Scannow",
                "Diagnostica: DISM RestoreHealth",
                "Ripristino: reset componenti Windows Update",
                "Diagnostica: stato WinRE / Recovery",
                "Diagnostica: batteria / salute e capacità",
                "Diagnostica: conflitti servizi / RPC 1726",
                "Ripristino: isola servizi non Microsoft (test)"
            };

            foreach (var c in tweakChecks)
            {
                int index = Convert.ToInt32(c.Tag);
                string nome = tweaks[index].Name;

                // Le voci speciali non devono essere toccate da "Seleziona tutti":
                // restano nello stato scelto manualmente dall'utente.
                if (esclusiDaSelezionaTutti.Contains(nome))
                    continue;

                c.Checked = true;
            }
        };
        performanceSelect.Click += (_,__) =>
        {
            var result = MessageBox.Show(
                "Seleziona anche le ottimizzazioni prestazioni più incisive (piano Prestazioni elevate, pulizia dei programmi non necessari in avvio e ottimizzazione unità).\n\nLe modifiche rischiose per sicurezza o compatibilità restano escluse. Continuare?",
                "Seleziona prestazioni",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information);
            if (result != DialogResult.Yes) return;

            // "Prestazioni" e' cumulativo: parte sempre dal preset Consigliato
            // e aggiunge soltanto le ottimizzazioni piu incisive.
            var esclusiDalConsigliato = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "Download temporaneo (URL manuale)",
                "Crea AppFolder sul Desktop",
                "Rete: Fix condivisione LAN (Privata + Firewall + Servizi)",
                "Rete: Fix completo / Share / Diagnostica",
                "Pulizia: Rimuovi residui KMS / KMSpico / AutoKMS",
                "Scarica / estrai FlyOOBE",
                "Scarica / estrai Flyby11",
                "Installa Microsoft 365 64 bit in italiano",
                "Office: rimozione completa (tutte le versioni)",
                "DNS Google — primario / secondario",
                "DNS Cloudflare — primario / secondario",
                "Servizi avanzati: CscService Disabled / StorSvc Manual",
                "Diagnostica rete — gateway, DHCP, DNS, IPv4/IPv6, velocità link",
                "Prestazioni: piano energia Prestazioni elevate",
                "Prestazioni: ottimizza programmi in avvio automatico",
                "Prestazioni: ottimizza unità di sistema (TRIM/Optimize)",
                "Prestazioni: verifica TRIM SSD",
                "Prestazioni: analisi programmi in avvio automatico",
                "Prestazioni: check hardware/software rapido",
                "Diagnostica: SFC /Scannow",
                "Diagnostica: DISM RestoreHealth",
                "Ripristino: reset componenti Windows Update",
                "Diagnostica: stato WinRE / Recovery",
                "Diagnostica: batteria / salute e capacità",
                "Diagnostica: conflitti servizi / RPC 1726",
                "Ripristino: isola servizi non Microsoft (test)"
            };

            foreach (var c in tweakChecks)
            {
                int index = Convert.ToInt32(c.Tag);
                if (!esclusiDalConsigliato.Contains(tweaks[index].Name))
                    c.Checked = true;
            }

            var performanceNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "Prestazioni: riduci animazioni e trasparenze",
                "Prestazioni: piano energia Prestazioni elevate",
                "Prestazioni: ottimizza programmi in avvio automatico",
                "Prestazioni: ottimizza unità di sistema (TRIM/Optimize)",
                "Prestazioni: verifica TRIM SSD",
                "Prestazioni: analisi programmi in avvio automatico",
                "Prestazioni: check hardware/software rapido",
            };
            foreach (var c in tweakChecks)
            {
                int index = Convert.ToInt32(c.Tag);
                if (performanceNames.Contains(tweaks[index].Name)) c.Checked = true;
            }
        };
        none.Click += (_,__) => tweakChecks.ForEach(c => c.Checked = false);
        apply.Click += async (_,__) => await ApplySelected();
        restore.Click += async (_,__) => await RestoreSelected();
        exit.Click += (_,__) => Close();
        FormClosing += (_,__) =>
        {
            if (defenderTemporaryOffByTool)
            {
                try { RestoreTemporaryDefenderProtection(); } catch { }
            }
            CleanupTemporaryDownloads();
        };

        Log("Pronto. Seleziona le operazioni da eseguire.");
        Log("SmartphonExpress Windows Tool • Service Edition");
    }

    void BuildModernUi()
    {
        SuspendLayout();

        Color bg = Color.FromArgb(247, 249, 252);
        Color sidebarBg = Color.FromArgb(242, 246, 251);
        Color cardBg = Color.White;
        Color text = Color.FromArgb(24, 36, 54);
        Color muted = Color.FromArgb(96, 111, 132);
        Color accent = Color.FromArgb(20, 113, 236);
        Color border = Color.FromArgb(220, 227, 235);

        AutoScaleMode = AutoScaleMode.Dpi;
        BackColor = bg;
        ForeColor = text;

        var shell = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = bg,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };
        shell.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 300));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        // ---------------- SIDEBAR ----------------
        var sidebar = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = sidebarBg,
            Padding = new Padding(16, 18, 14, 16)
        };

        var brand = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 84,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent
        };
        brand.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
        brand.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        var logo = new PictureBox
        {
            Dock = DockStyle.Top,
            Height = 50,
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 0, 6, 0)
        };
        var sourceLogo = LoadEmbeddedLogo();
        if (sourceLogo != null)
            logo.Image = MakeLogoForLightTheme(sourceLogo);

        var brandText = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 1,
            BackColor = Color.Transparent,
            Padding = new Padding(2, 5, 0, 0)
        };
        brandText.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        brandText.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var brandName = new Label
        {
            Text = "SmartphonExpress",
            Dock = DockStyle.Top,
            AutoSize = false,
            Height = 28,
            AutoEllipsis = false,
            Font = new Font("Segoe UI Semibold", 9.4f, FontStyle.Bold),
            ForeColor = text,
            TextAlign = ContentAlignment.MiddleLeft
        };
        var brandSub = new Label
        {
            Text = "Windows Tool",
            Dock = DockStyle.Top,
            AutoSize = true,
            Font = new Font("Segoe UI", 9.2f),
            ForeColor = muted
        };
        brandText.Controls.Add(brandName, 0, 0);
        brandText.Controls.Add(brandSub, 0, 1);
        brand.Controls.Add(logo, 0, 0);
        brand.Controls.Add(brandText, 1, 0);

        var nav = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 8, 0, 0)
        };

        var navOps = MakeNavButton("Operazioni", true, accent, text);
        var navSettings = MakeNavButton("Impostazioni", false, accent, text);
        var navInfo = MakeNavButton("Info", false, accent, text);
        var navExit = MakeNavButton("Esci", false, accent, text);

        navSettings.Click += (_,__) =>
        {
            try { Process.Start(new ProcessStartInfo("ms-settings:") { UseShellExecute = true }); }
            catch { }
        };
        navInfo.Click += (_,__) =>
        {
            string release = Application.ProductVersion;
            MessageBox.Show(
                $"SmartphonExpress Windows Tool\n" +
                $"Service Edition\n\n" +
                $"Release: v{release}\n\n" +
                $"Utility di configurazione post-formattazione per Windows.",
                "Informazioni",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        };
        navExit.Click += (_,__) => Close();

        nav.Controls.Add(navOps);
        nav.Controls.Add(navSettings);
        nav.Controls.Add(navInfo);
        nav.Controls.Add(navExit);

        // Stato rapido: visibile subito nella colonna sinistra, aggiornato senza bloccare l'apertura.
        var quickStatus = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 158,
            BackColor = Color.Transparent,
            Padding = new Padding(2, 6, 0, 0)
        };
        var quickTitle = new Label
        {
            Dock = DockStyle.Top, Height = 26, Text = "STATO SISTEMA",
            Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold), ForeColor = muted
        };
        var windowsStatusLabel = MakeQuickStatusLabel("Windows", "Controllo...", muted);
        var officeStatusLabel = MakeQuickStatusLabel("Office", "Controllo...", muted);
        var defenderStatusLabel = MakeQuickStatusLabel("Defender", "Controllo...", muted);
        defenderQuickStatusLabel = defenderStatusLabel;
        defenderStatusLabel.Top = 82; officeStatusLabel.Top = 58; windowsStatusLabel.Top = 34;
        quickStatus.Controls.Add(defenderStatusLabel);
        quickStatus.Controls.Add(officeStatusLabel);
        quickStatus.Controls.Add(windowsStatusLabel);
        quickStatus.Controls.Add(quickTitle);

        defenderToggleButton = new Button
        {
            Left = 0, Top = 110, Width = 178, Height = 34,
            Text = "DEFENDER  ON",
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(230, 247, 237),
            ForeColor = Color.FromArgb(24, 120, 65),
            Font = new Font("Segoe UI Semibold", 8.8f, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        defenderToggleButton.FlatAppearance.BorderSize = 2;
        defenderToggleButton.FlatAppearance.BorderColor = Color.FromArgb(28, 140, 75);
        defenderToggleButton.Click += async (_,__) => await ToggleTemporaryDefenderAsync();
        quickStatus.Controls.Add(defenderToggleButton);

        Shown += async (_,__) =>
        {
            try
            {
                var winTask = Task.Run(GetWindowsQuickStatus);
                var offTask = Task.Run(GetOfficeQuickStatus);
                var defTask = Task.Run(GetDefenderQuickStatus);
                var win = await winTask; SetQuickStatus(windowsStatusLabel, "Windows", win);
                var off = await offTask; SetQuickStatus(officeStatusLabel, "Office", off);
                var def = await defTask; SetQuickStatus(defenderStatusLabel, "Defender", def);
            }
            catch { }
        };

        var version = new Label
        {
            Dock = DockStyle.Bottom,
            Height = 62,
            Text = $"SmartphonExpress\nService Edition • v{Application.ProductVersion}",
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = muted,
            TextAlign = ContentAlignment.BottomLeft
        };

        sidebar.Controls.Add(version);
        sidebar.Controls.Add(quickStatus);
        sidebar.Controls.Add(nav);
        sidebar.Controls.Add(brand);

        // ---------------- MAIN SCROLLER ----------------
        var mainScroll = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = bg
        };

        var content = new Panel
        {
            BackColor = bg,
            Location = new Point(18, 16)
        };
        mainScroll.Controls.Add(content);

        // HEADER
        var header = new TableLayoutPanel
        {
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent,
            Height = 84
        };
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));

        var headerLeft = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            RowCount = 2,
            ColumnCount = 1,
            BackColor = Color.Transparent
        };
        headerLeft.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        headerLeft.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var title = new Label
        {
            Text = "Strumenti per la configurazione di Windows",
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoEllipsis = true,
            Font = new Font("Segoe UI Semibold", 17f, FontStyle.Bold),
            ForeColor = text
        };
        var desc = new Label
        {
            Text = "Seleziona le operazioni da eseguire e avvia la procedura.",
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoEllipsis = true,
            Font = new Font("Segoe UI", 9.6f),
            ForeColor = muted,
            Margin = new Padding(1, 3, 0, 0)
        };
        headerLeft.Controls.Add(title, 0, 0);
        headerLeft.Controls.Add(desc, 0, 1);

        var service = new Label
        {
            Dock = DockStyle.Fill,
            Text = "SERVICE EDITION\nPC pronti, clienti soddisfatti.",
            Font = new Font("Segoe UI", 8.3f),
            ForeColor = muted,
            TextAlign = ContentAlignment.TopRight,
            Padding = new Padding(0, 3, 0, 0)
        };
        header.Controls.Add(headerLeft, 0, 0);
        header.Controls.Add(service, 1, 0);
        content.Controls.Add(header);

        // PRIMARY CARDS
        var primaryGrid = new TableLayoutPanel
        {
            ColumnCount = 2,
            RowCount = 3,
            BackColor = Color.Transparent,
            Padding = Padding.Empty,
            Margin = Padding.Empty
        };

        var primaryCards = new List<Panel>
        {
            MakePrimaryCard("START", "Prepara pin Office, Chrome, Firefox e Impostazioni", 25, cardBg, border, text, muted, accent),
            MakePrimaryCard("Sicurezza", "Disattiva Accesso controllato alle cartelle", 24, cardBg, border, text, muted, accent),
            MakePrimaryCard("Office 2024 completo", "LTSC Pro Plus + Project Pro + Visio Pro, 64 bit ITA", 43, cardBg, border, text, muted, accent),
            MakePrimaryCard("Google Chrome", "Installa Google Chrome", 26, cardBg, border, text, muted, accent),
            MakePrimaryCard("Mozilla Firefox", "Installa Firefox in italiano", 27, cardBg, border, text, muted, accent),
            MakePrimaryCard("Pulizia finale", "Pulisce i temporanei al prossimo riavvio, una sola volta", 33, cardBg, border, text, muted, accent)
        };

        content.Controls.Add(primaryGrid);

        // OPTIONS GROUPS
        var optionsGrid = new TableLayoutPanel
        {
            ColumnCount = 3,
            RowCount = 1,
            BackColor = cardBg,
            Padding = new Padding(14, 12, 14, 12),
            Margin = Padding.Empty
        };
        optionsGrid.Paint += (_, e) =>
        {
            using var pen = new Pen(border);
            e.Graphics.DrawRectangle(pen, 0, 0, optionsGrid.Width - 1, optionsGrid.Height - 1);
        };

        // Prestazioni e Diagnostica condividono la stessa colonna: in questo modo
        // la diagnostica resta subito sotto Prestazioni e la pagina e' molto piu compatta.
        var performanceDiagnostics = new TableLayoutPanel
        {
            ColumnCount = 1,
            RowCount = 2,
            Dock = DockStyle.Fill,
            BackColor = Color.Transparent,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        performanceDiagnostics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        performanceDiagnostics.RowStyles.Add(new RowStyle(SizeType.Absolute, 285f));
        performanceDiagnostics.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
        performanceDiagnostics.Controls.Add(MakeOptionsColumn("Prestazioni", Enumerable.Range(48, 7).ToArray(), text, muted, accent), 0, 0);
        performanceDiagnostics.Controls.Add(MakeOptionsColumn("Diagnostica e ripristino", Enumerable.Range(55, 6).Concat(new[] { 63, 64 }).ToArray(), text, muted, accent), 0, 1);

        var optionGroups = new List<Control>
        {
            MakeOptionsColumn("Sistema", Enumerable.Range(0, 10).ToArray(), text, muted, accent),
            MakeOptionsColumn("Ottimizzazione", Enumerable.Range(10, 14).Concat(new[] { 46 }).ToArray(), text, muted, accent),
            MakeOptionsColumn("Utility, rete e licenze", new[] { 28, 29, 30, 61, 62, 31, 32, 34, 35, 36, 37, 38, 39, 40, 41, 42, 44, 45, 47 }, text, muted, accent),
            performanceDiagnostics
        };
        content.Controls.Add(optionsGrid);

        // ACTIONS
        var actionFlow = new FlowLayoutPanel
        {
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            AutoSize = false,
            BackColor = Color.Transparent,
            Padding = new Padding(0, 4, 0, 4)
        };

        apply.Text = "▶  Esegui selezionati";
        all.Text = "Consigliato";
        none.Text = "Deseleziona";
        performanceSelect.Text = "Prestazioni";
        restore.Text = "Ripristino";

        apply.AutoSize = false; apply.Size = new Size(190, 40);
        all.AutoSize = false; all.Size = new Size(125, 40);
        none.AutoSize = false; none.Size = new Size(125, 40);
        performanceSelect.AutoSize = false; performanceSelect.Size = new Size(125, 40);
        restore.AutoSize = false; restore.Size = new Size(125, 40);

        StyleFluentButton(apply, accent, Color.White, border, true);
        StyleFluentButton(all, Color.White, text, border, false);
        StyleFluentButton(performanceSelect, Color.White, text, border, false);
        StyleFluentButton(none, Color.White, text, border, false);

        // I due preset principali devono essere immediatamente riconoscibili.
        all.FlatAppearance.BorderSize = 3;
        all.FlatAppearance.BorderColor = accent;
        all.Font = new Font("Segoe UI Semibold", 9.2f);
        performanceSelect.FlatAppearance.BorderSize = 3;
        performanceSelect.FlatAppearance.BorderColor = Color.FromArgb(55, 65, 81);
        performanceSelect.Font = new Font("Segoe UI Semibold", 9.2f);
        StyleFluentButton(restore, Color.White, text, border, false);

        var clearLog = new Button { Text = "Pulisci log", Size = new Size(100, 40) };
        StyleFluentButton(clearLog, Color.White, text, border, false);
        clearLog.Click += (_,__) => log.Clear();

        actionFlow.Controls.Add(apply);
        actionFlow.Controls.Add(all);
        actionFlow.Controls.Add(performanceSelect);
        actionFlow.Controls.Add(none);
        actionFlow.Controls.Add(restore);
        actionFlow.Controls.Add(clearLog);
        content.Controls.Add(actionFlow);

        // LOG
        var logPanel = new Panel
        {
            Height = 145,
            BackColor = Color.White,
            Padding = new Padding(13, 9, 13, 10)
        };
        logPanel.Paint += (_, e) =>
        {
            using var pen = new Pen(border);
            e.Graphics.DrawRectangle(pen, 0, 0, logPanel.Width - 1, logPanel.Height - 1);
        };

        var logTitle = new Label
        {
            Text = "Log operazioni",
            Dock = DockStyle.Top,
            Height = 22,
            Font = new Font("Segoe UI Semibold", 9f),
            ForeColor = muted
        };
        log.BackColor = Color.White;
        log.ForeColor = Color.FromArgb(67, 78, 93);
        log.BorderStyle = BorderStyle.None;
        log.Font = new Font("Consolas", 8.5f);
        logPanel.Controls.Add(log);
        logPanel.Controls.Add(logTitle);
        content.Controls.Add(logPanel);

        shell.Controls.Add(sidebar, 0, 0);
        shell.Controls.Add(mainScroll, 1, 0);

        Controls.Clear();
        Controls.Add(shell);

        void RebuildPrimaryGrid(int columns, int width)
        {
            primaryGrid.SuspendLayout();
            primaryGrid.Controls.Clear();
            primaryGrid.ColumnStyles.Clear();
            primaryGrid.RowStyles.Clear();

            int rows = (int)Math.Ceiling(primaryCards.Count / (double)columns);
            primaryGrid.ColumnCount = columns;
            primaryGrid.RowCount = rows;

            for (int c = 0; c < columns; c++)
                primaryGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));
            for (int r = 0; r < rows; r++)
                primaryGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));

            primaryGrid.Width = width;
            primaryGrid.Height = rows * 76;

            for (int i = 0; i < primaryCards.Count; i++)
            {
                var card = primaryCards[i];
                card.Dock = DockStyle.Fill;
                card.Margin = new Padding(0, 0, i % columns == columns - 1 ? 0 : 10, 8);
                primaryGrid.Controls.Add(card, i % columns, i / columns);
            }
            primaryGrid.ResumeLayout(true);
        }

        void RebuildOptionsGrid(int columns, int width)
        {
            optionsGrid.SuspendLayout();
            optionsGrid.Controls.Clear();
            optionsGrid.ColumnStyles.Clear();
            optionsGrid.RowStyles.Clear();

            int rows = (int)Math.Ceiling(optionGroups.Count / (double)columns);
            optionsGrid.ColumnCount = columns;
            optionsGrid.RowCount = rows;

            for (int c = 0; c < columns; c++)
                optionsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));

            // La colonna "Ottimizzazione" contiene più voci:
            // 500 px evitano che le ultime checkbox vengano tagliate.
            int rowHeight = 740;
            for (int r = 0; r < rows; r++)
                optionsGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, rowHeight));

            optionsGrid.Width = width;
            optionsGrid.Height = rows * rowHeight + optionsGrid.Padding.Vertical;

            for (int i = 0; i < optionGroups.Count; i++)
            {
                var group = optionGroups[i];
                group.Dock = DockStyle.Fill;
                group.Margin = new Padding(6, 0, 6, 0);
                optionsGrid.Controls.Add(group, i % columns, i / columns);
            }
            optionsGrid.ResumeLayout(true);
        }

        void ApplyResponsiveLayout()
        {
            int viewport = Math.Max(520, mainScroll.ClientSize.Width - 36);

            // Cap the content width: on 4K it stays readable instead of stretching
            // from one edge of the monitor to the other.
            int contentWidth = Math.Min(1500, viewport);
            content.Width = contentWidth;
            content.Left = Math.Max(18, (mainScroll.ClientSize.Width - contentWidth) / 2);
            content.Top = 16;

            header.Width = contentWidth;
            header.Left = 0;
            header.Top = 0;

            bool small = contentWidth < 900;
            service.Visible = !small;
            header.ColumnStyles[1].Width = small ? 0 : 210;

            int y = header.Bottom + 6;

            int primaryCols = contentWidth >= 820 ? 2 : 1;
            RebuildPrimaryGrid(primaryCols, contentWidth);
            primaryGrid.Left = 0;
            primaryGrid.Top = y;
            y = primaryGrid.Bottom + 8;

            int optionCols = contentWidth >= 1380 ? 4 : (contentWidth >= 820 ? 2 : 1);
            RebuildOptionsGrid(optionCols, contentWidth);
            optionsGrid.Left = 0;
            optionsGrid.Top = y;
            y = optionsGrid.Bottom + 8;

            actionFlow.Width = contentWidth;
            actionFlow.Height = contentWidth < 760 ? 92 : 50;
            actionFlow.Left = 0;
            actionFlow.Top = y;
            y = actionFlow.Bottom + 6;

            logPanel.Width = contentWidth;
            logPanel.Left = 0;
            logPanel.Top = y;
            y = logPanel.Bottom + 16;

            content.Height = y;

            int sidebarWidth = ClientSize.Width < 1050 ? 300 : 330;
            shell.ColumnStyles[0].Width = sidebarWidth;
            brandName.Width = Math.Max(205, sidebarWidth - 58);
            foreach (Control c in nav.Controls)
                c.Width = Math.Max(145, sidebarWidth - sidebar.Padding.Horizontal);
        }

        ApplyResponsiveLayout();
        SizeChanged += (_,__) => ApplyResponsiveLayout();
        mainScroll.SizeChanged += (_,__) => ApplyResponsiveLayout();

        ResumeLayout(true);
    }

    Button MakeNavButton(string caption, bool selected, Color accent, Color text)
    {
        var b = new Button
        {
            Text = caption,
            Height = 42,
            FlatStyle = FlatStyle.Flat,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(13, 0, 0, 0),
            Margin = new Padding(0, 0, 0, 6),
            Cursor = Cursors.Hand,
            Font = new Font("Segoe UI Semibold", 9.2f),
            ForeColor = selected ? accent : text,
            BackColor = selected ? Color.FromArgb(226, 238, 252) : Color.Transparent
        };
        b.FlatAppearance.BorderSize = 0;
        b.FlatAppearance.MouseOverBackColor = Color.FromArgb(232, 239, 247);
        return b;
    }

    Panel MakePrimaryCard(
        string heading,
        string subtitle,
        int index,
        Color cardBg,
        Color border,
        Color text,
        Color muted,
        Color accent)
    {
        var panel = new Panel
        {
            BackColor = cardBg,
            Padding = new Padding(14, 8, 12, 8)
        };

        panel.Paint += (_, e) =>
        {
            using var pen = new Pen(border);
            e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
        };

        var cb = new CheckBox
        {
            Tag = index,
            AutoSize = false,
            Width = 26,
            Height = 26,
            Location = new Point(14, 21),
            BackColor = Color.Transparent
        };
        tweakChecks.Add(cb);

        var h = new Label
        {
            Text = heading,
            AutoSize = true,
            Location = new Point(48, 10),
            Font = new Font("Segoe UI Semibold", 10.2f, FontStyle.Bold),
            ForeColor = text
        };

        var sub = new Label
        {
            Text = subtitle,
            AutoEllipsis = true,
            Location = new Point(48, 34),
            Height = 24,
            Font = new Font("Segoe UI", 8.7f),
            ForeColor = muted
        };

        var help = MakeHelpIcon(index, accent);

        panel.Resize += (_,__) =>
        {
            sub.Width = Math.Max(80, panel.ClientSize.Width - 96);
            help.Location = new Point(Math.Max(50, panel.ClientSize.Width - 29), 11);
        };

        panel.Controls.Add(cb);
        panel.Controls.Add(h);
        panel.Controls.Add(sub);
        panel.Controls.Add(help);
        return panel;
    }

    Control MakeOptionsColumn(string heading, int[] indices, Color text, Color muted, Color accent)
    {
        var flow = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Color.Transparent,
            Padding = new Padding(2, 0, 2, 0)
        };

        var headingLabel = new Label
        {
            Text = heading,
            AutoSize = false,
            Height = 30,
            Font = new Font("Segoe UI Semibold", 10f, FontStyle.Bold),
            ForeColor = text,
            Margin = new Padding(0, 0, 0, 3)
        };
        flow.Controls.Add(headingLabel);

        foreach (int i in indices)
        {
            int rowHeight = tweaks[i].Name.Length > 52 ? 44 : 31;

            var row = new Panel
            {
                Height = rowHeight,
                BackColor = Color.Transparent,
                Margin = new Padding(0, 0, 0, 1)
            };

            var cb = new CheckBox
            {
                Text = tweaks[i].Name,
                Tag = i,
                AutoSize = false,
                Height = rowHeight,
                ForeColor = text,
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 8.8f),
                Location = new Point(0, 0),
                CheckAlign = ContentAlignment.TopLeft,
                TextAlign = ContentAlignment.TopLeft
            };

            var help = MakeHelpIcon(i, accent);
            help.Location = new Point(0, Math.Max(2, (rowHeight - help.Height) / 2));

            tweakChecks.Add(cb);
            helpTip.SetToolTip(cb, TweakHelpText(i));

            row.Controls.Add(cb);
            row.Controls.Add(help);
            flow.Controls.Add(row);

            row.Resize += (_,__) =>
            {
                help.Location = new Point(
                    Math.Max(28, row.ClientSize.Width - 22),
                    Math.Max(2, (row.ClientSize.Height - help.Height) / 2));
                cb.Width = Math.Max(120, row.ClientSize.Width - 30);
            };
        }

        flow.Resize += (_,__) =>
        {
            int w = Math.Max(170, flow.ClientSize.Width - 8);
            headingLabel.Width = w;

            foreach (Control c in flow.Controls)
            {
                if (c is Panel row)
                    row.Width = w;
            }
        };

        return flow;
    }

    Label MakeHelpIcon(int index, Color accent)
    {
        Color normal = Color.FromArgb(112, 118, 126);
        Color hover = accent;

        var help = new Label
        {
            Text = "",
            Width = 18,
            Height = 18,
            AutoSize = false,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            Tag = index
        };

        help.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            e.Graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;

            Color c = (Color)(help.Tag is int ? help.ForeColor : normal);
            if (help.ForeColor == Color.Empty)
                c = normal;

            float d = 14f;
            float x = (help.Width - d) / 2f;
            float y = (help.Height - d) / 2f;

            using var pen = new Pen(c, 1.25f);
            e.Graphics.DrawEllipse(pen, x, y, d, d);

            // Disegno manuale della "i" per tenerla perfettamente centrata.
            using var brush = new SolidBrush(c);

            // puntino
            float dot = 1.7f;
            e.Graphics.FillEllipse(
                brush,
                help.Width / 2f - dot / 2f,
                5.0f,
                dot,
                dot);

            // stelo
            float stemW = 1.5f;
            float stemH = 5.0f;
            e.Graphics.FillRectangle(
                brush,
                help.Width / 2f - stemW / 2f,
                8.0f,
                stemW,
                stemH);
        };

        help.ForeColor = normal;

        help.MouseEnter += (_,__) =>
        {
            help.ForeColor = hover;
            help.Invalidate();
        };

        help.MouseLeave += (_,__) =>
        {
            help.ForeColor = normal;
            help.Invalidate();
        };

        string info = TweakHelpText(index);
        helpTip.SetToolTip(help, info);

        help.Click += (_,__) =>
        {
            MessageBox.Show(
                info,
                tweaks[index].Name,
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        };

        return help;
    }

    string TweakHelpText(int index) => index switch
    {
        0 => "Mostra in Esplora file gli elementi normalmente nascosti. Non elimina né modifica i file.",
        1 => "Ripristina sul Desktop le icone classiche di Windows: Questo PC, profilo utente, Pannello di controllo, Cestino e Rete.",
        2 => "Mantiene Outlook classico, nasconde il passaggio al nuovo Outlook e blocca le migrazioni automatiche supportate.",
        3 => "Fa partire Windows con NumLock attivo quando la configurazione firmware/tastiera lo consente.",
        4 => "Riduce la casella Ricerca della taskbar alla sola icona.",
        5 => "Disattiva l'aggancio automatico classico delle finestre ai bordi dello schermo. Ripristinabile.",
        6 => "Riduce app suggerite, installazioni/promozioni consumer e contenuti consigliati gestiti dalla relativa policy Windows.",
        7 => "Evita che Explorer cambi automaticamente il tipo/visualizzazione delle cartelle in base ai file contenuti.",
        8 => "Impedisce l'esecuzione della Windows Platform Binary Table (WPBT). Modifica avanzata di sicurezza/firmware.",
        9 => "Disabilita Offline Files (CscService) e mette Storage Service su Manuale. È avanzato e resta fuori da Seleziona tutti.",
        10 => "Riduce telemetria, ID pubblicitario, esperienze personalizzate e raccolta dati secondo i limiti dell'edizione di Windows.",
        11 => "Disabilita il peer-to-peer di Delivery Optimization: Windows Update scarica via HTTP invece di scambiare dati con altri PC.",
        12 => "Elimina i file temporanei nelle cartelle temporanee di Windows/utente senza toccare documenti personali.",
        13 => "Aggiunge 'Termina attività' al menu contestuale delle app sulla taskbar, dove supportato.",
        14 => "Disattiva ibernazione e libera hiberfil.sys. Sui notebook elimina anche la funzione Ibernazione finché non viene ripristinata.",
        15 => "Blocca il download automatico da Internet dei metadata/icone dei dispositivi.",
        16 => "Forza il blocco delle app moderne in background. Può ridurre attività e notifiche; è ripristinabile.",
        17 => "Applica policy privacy/debloat a Microsoft Edge per ridurre suggerimenti, personalizzazione e funzioni promozionali.",
        18 => "Rimuove l'avviso di firma durante alcune connessioni Desktop remoto. Usare solo in ambienti conosciuti.",
        19 => "Ripristina il menu contestuale classico completo di Windows 11. È reversibile.",
        20 => "Disattiva o nasconde funzioni Windows AI/Recall supportate dalle policy correnti e mantiene alcuni fallback legacy.",
        21 => "Disabilita Widgets via policy e rimuove il Web Experience Pack per l'utente corrente.",
        22 => "Rimuove il gruppo di AppX previsto dal tool. Controlla il log per vedere quali pacchetti vengono rimossi.",
        23 => "Imposta Blocco note su nuova sessione all'avvio e apertura dei file in una nuova finestra invece che in schede; elimina anche il vecchio stato salvato quando l'app è chiusa.",
        24 => "Disattiva Controlled Folder Access di Defender. Utile per software tecnici incompatibili, ma riduce la protezione anti-ransomware.",
        25 => "Predispone un layout Start con Office, Chrome, Firefox e Impostazioni. Può richiedere disconnessione/nuovo accesso.",
        26 => "Installa Google Chrome con il metodo previsto dal tool.",
        27 => "Installa Mozilla Firefox in italiano.",
        28 => "Installa 7-Zip x64.",
        29 => "Installa VLC Media Player x64.",
        30 => "Installa Microsoft 365 64 bit in italiano. È alternativo a Office LTSC 2024.",
        31 => "Controlla lo stato di attivazione Windows. Ha timeout per evitare di bloccare l'intero flusso.",
        32 => "Controlla lo stato licenza Office tramite OSPP quando disponibile e riassume il risultato a fine procedura.",
        33 => "Programma una pulizia temporanei al prossimo avvio come SYSTEM, una sola volta, senza toccare Download/Documenti/Cestino.",
        34 => "Applica un fix base per condivisione LAN: rete privata, regole firewall e servizi di individuazione/condivisione.",
        35 => "Fix rete avanzato con condivisione e diagnostica. Può richiedere input e resta quindi manuale.",
        36 => "Rimuove residui di vecchi emulatori/servizi KMS, KMSpico o AutoKMS. È una funzione di pulizia, non di attivazione.",
        37 => "Scarica ed estrae il pacchetto SmartphonExpress preconfigurato nella cartella temporanea; non esegue automaticamente il contenuto.",
        38 => "Downloader generico: chiede un URL, scarica il file nella cartella temporanea e lo mostra in Esplora file.",
        39 => "Crea sul Desktop un collegamento AppFolder che apre tutte le applicazioni installate.",
        40 => "Disattiva SmartScreen/controlli reputazione e Smart App Control. Riduce significativamente la protezione e può richiedere riavvio.",
        41 => "Scarica ed estrae FlyOOBE nella cartella temporanea e mostra il contenuto senza avviarlo automaticamente.",
        42 => "Scarica ed estrae Flyby11 nella cartella temporanea e mostra il contenuto senza avviarlo automaticamente.",
        43 => "Installa Office LTSC 2024 completo 64 bit ITA: Pro Plus + Project Pro + Visio Pro. Richiede licenza valida.",
        44 => "Imposta Google DNS sulle schede attive: 8.8.8.8 / 8.8.4.4 e relativi IPv6. Ripristino = DNS automatici.",
        45 => "Imposta Cloudflare DNS sulle schede attive: 1.1.1.1 / 1.0.0.1 e relativi IPv6. Ripristino = DNS automatici.",
        46 => "Abilita Storage Sense settimanale per i temporanei, lasciando intatti Download e Cestino.",
        47 => "Diagnostica sola lettura: scheda, velocità link, DHCP, IPv4/IPv6, gateway e DNS effettivi.",
        48 => "Riduce animazioni della shell e trasparenze per rendere l'interfaccia più immediata. Non disattiva temi o compositing.",
        49 => "Attiva il piano energia Prestazioni elevate. Aumenta consumi e temperature, soprattutto sui notebook: resta manuale.",
        50 => "Disattiva dall’avvio automatico browser, Teams, launcher gaming e altri programmi non essenziali riconosciuti. Protegge antivirus/sicurezza, cloud, PowerToys, IDM, driver e utility hardware/OEM, VPN, password manager e backup. La modifica è ripristinabile.",
        51 => "Esegue l'ottimizzazione Windows dell'unità di sistema con /O: Windows sceglie TRIM per SSD e l'azione appropriata per HDD.",
        52 => "Controlla se TRIM/DeleteNotify è abilitato per NTFS/ReFS. È una diagnosi e non modifica il sistema.",
        53 => "Elenca i programmi configurati per partire automaticamente con Windows. È sola lettura.",
        54 => "Raccoglie un riepilogo rapido di CPU, RAM, dischi, spazio libero e stato dei dischi; il risultato viene mostrato anche in una finestra leggibile.",
        55 => "Esegue SFC /scannow. Se Windows Resource Protection non riesce a completare l'operazione, il Tool verifica TrustedInstaller e WinSxS\\Temp, esegue DISM CheckHealth/ScanHealth/RestoreHealth e riprova SFC automaticamente, senza disabilitare WRP.",
        56 => "Esegue DISM /Online /Cleanup-Image /RestoreHealth per verificare e riparare l'immagine componenti di Windows.",
        57 => "Riavvia i servizi Windows Update e ricrea SoftwareDistribution e catroot2. Utile quando Windows Update è bloccato o restituisce errori persistenti.",
        58 => "Controlla lo stato di Windows Recovery Environment (WinRE), la posizione dell'immagine di ripristino e la configurazione reagentc.",
        59 => "Mostra carica, capacità di progetto, capacità attuale e salute stimata della batteria quando il firmware espone questi dati.",
        60 => "Trova periferiche con problemi, codici errore e Hardware ID; mostra i driver candidati quando Windows li espone. Consente un nuovo rilevamento hardware e l’installazione sicura di driver INF da una cartella scelta dal tecnico.",
        61 => "Installa Microsoft 365 completo con Visio e Project 64 bit ITA. Richiede licenze valide.",
        62 => "Avvia la procedura Microsoft per la rimozione completa delle installazioni Office supportate.",
        63 => "Diagnostica sola lettura per errori RPC/DISM 1726: verifica i servizi core e identifica servizi di terze parti attivi che possono interferire nell'avvio normale.",
        64 => "Test reversibile di isolamento servizi: salva lo stato dei servizi di terze parti con firma valida, disabilita solo quelli non Microsoft e consente di ripristinare esattamente lo stato precedente. Non modifica servizi Microsoft, driver o voci di avvio.",
        _ => "Descrizione non disponibile."
    };

    static void StyleFluentButton(Button b, Color bg, Color fg, Color border, bool primary)
    {
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = primary ? 0 : 1;
        b.FlatAppearance.BorderColor = border;
        b.BackColor = bg;
        b.ForeColor = fg;
        b.Font = new Font("Segoe UI Semibold", 8.9f);
        b.Margin = new Padding(0, 0, 8, 4);
        b.Cursor = Cursors.Hand;
    }

    static Image MakeLogoForLightTheme(Image source)
    {
        var bmp = new Bitmap(source.Width, source.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(bmp))
            g.DrawImage(source, 0, 0, source.Width, source.Height);

        for (int y = 0; y < bmp.Height; y++)
        for (int x = 0; x < bmp.Width; x++)
        {
            var c = bmp.GetPixel(x, y);
            if (c.A < 10) continue;
            int lum = (c.R + c.G + c.B) / 3;
            if (lum < 150)
                bmp.SetPixel(x, y, Color.FromArgb(c.A, 28, 105, 190));
        }

        source.Dispose();
        return bmp;
    }

    IEnumerable<int> CheckedTweakIndices() =>
        tweakChecks.Where(c => c.Checked).Select(c => (int)c.Tag!).OrderBy(i => i);

    async Task ApplySelected()
    {
        apply.Enabled = false;
        currentRunTimeouts = 0;
        windowsActivationSummary = "NON CONTROLLATO";
        officeActivationSummary = "NON CONTROLLATO";
        collectDiagnosticReports = true;
        diagnosticReports.Clear();

        int ok = 0;
        int errors = 0;
        var errorNames = new List<string>();
        var selected = CheckedTweakIndices().ToArray();

        foreach (int i in selected)
        {
            var t = tweaks[i];
            Log($"▶ {t.Name}");
            try
            {
                await Task.Run(t.Apply);
                Log("  OK");
                ok++;
            }
            catch(Exception ex)
            {
                Log("  ERRORE: " + ex.Message);
                errors++;
                errorNames.Add(t.Name);
            }
        }

        collectDiagnosticReports = false;
        if (diagnosticReports.Count > 0)
        {
            var combined = new StringBuilder();
            combined.AppendLine("SMARTPHONEXPRESS — REPORT DIAGNOSTICA");
            combined.AppendLine($"Data: {DateTime.Now:dd/MM/yyyy HH:mm}");
            combined.AppendLine(new string('=', 72));
            foreach (var item in diagnosticReports)
            {
                combined.AppendLine();
                combined.AppendLine(item.Title.ToUpperInvariant());
                combined.AppendLine(new string('-', 72));
                combined.AppendLine(item.Report.Trim());
                combined.AppendLine();
            }
            ShowDiagnosticReportWindow("SmartphonExpress — Report diagnostica", combined.ToString());
            diagnosticReports.Clear();
        }

        Run("ie4uinit.exe","-show");

        Log("────────────────────────────────────────");
        Log($"RIEPILOGO: selezionate={selected.Length} | riuscite={ok} | errori={errors} | timeout={currentRunTimeouts}");

        if (errorNames.Count > 0)
        {
            Log("RIEPILOGO ERRORI:");
            foreach (var name in errorNames)
                Log("  • " + name);
        }

        Log("Operazioni terminate. Alcune modifiche richiedono disconnessione o riavvio.");

        if (windowsActivationSummary != "NON CONTROLLATO" ||
            officeActivationSummary != "NON CONTROLLATO")
        {
            MessageBox.Show(
                "Windows: " + windowsActivationSummary + "\n" +
                "Office: " + officeActivationSummary + "\n\n" +
                "I dettagli completi sono nel log.",
                "SmartphonExpress - Stato attivazioni",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        apply.Enabled = true;
    }

    async Task RestoreSelected()
    {
        restore.Enabled = false;
        foreach (int i in CheckedTweakIndices().ToArray())
        {
            var t = tweaks[i];
            if (t.Undo is null) { Log($"↩ {t.Name}: ripristino automatico non definito."); continue; }
            try { await Task.Run(t.Undo); Log($"↩ {t.Name}: ripristinato."); }
            catch(Exception ex) { Log("  ERRORE: " + ex.Message); }
        }
        restore.Enabled = true;
    }

    void Log(string s)
    {
        if (InvokeRequired) { BeginInvoke(() => Log(s)); return; }
        log.AppendText($"[{DateTime.Now:HH:mm:ss}] {s}\r\n");
    }

    static void SetCU(string path,string name,object value) => Set(Registry.CurrentUser,path,name,value);
    static void SetLM(string path,string name,object value) => Set(Registry.LocalMachine,path,name,value);
    static void Set(RegistryKey hive,string path,string name,object value)
    {
        using var k=hive.CreateSubKey(path,true)!;
        var kind = value is int ? RegistryValueKind.DWord : RegistryValueKind.String;
        k.SetValue(name,value,kind);
    }
    static void DelCU(string p,string n)=>Del(Registry.CurrentUser,p,n);
    static void DelLM(string p,string n)=>Del(Registry.LocalMachine,p,n);
    static void Del(RegistryKey hive,string path,string name)
    {
        using var k=hive.OpenSubKey(path,true);
        if(k!=null) k.DeleteValue(name,false);
    }
    static void Run(string file,string args)
    {
        // L'output non viene usato: non redirigiamo stdout/stderr, così processi molto verbosi
        // non possono bloccarsi riempiendo i buffer della pipe.
        using var p=Process.Start(new ProcessStartInfo(file,args)
        {
            UseShellExecute=false,
            CreateNoWindow=true,
            RedirectStandardOutput=false,
            RedirectStandardError=false
        });
        p?.WaitForExit();
    }
    void ScheduleOneTimeFinalCleanup()
    {
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "SmartphonExpress", "FinalCleanup");
        Directory.CreateDirectory(baseDir);

        var psPath = Path.Combine(baseDir, "FinalCleanup-Once.ps1");
        var logPath = Path.Combine(baseDir, "FinalCleanup.log");
        var taskName = "SmartphonExpress_FinalCleanup_Once";

        string ps = """
$ErrorActionPreference = 'SilentlyContinue'
$log = '__LOGPATH__'

function Write-Log([string]$m) {
    Add-Content -Path $log -Value ("[" + (Get-Date -Format "yyyy-MM-dd HH:mm:ss") + "] " + $m)
}

Write-Log "Avvio pulizia finale SmartphonExpress"

$targets = @(
    "$env:WINDIR\Temp",
    "$env:ProgramData\Microsoft\Windows\WER\ReportArchive",
    "$env:ProgramData\Microsoft\Windows\WER\ReportQueue"
)

foreach ($t in $targets) {
    if (Test-Path $t) {
        Write-Log ("Pulizia: " + $t)
        Get-ChildItem -LiteralPath $t -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

Get-ChildItem 'C:\Users' -Directory -Force -ErrorAction SilentlyContinue | ForEach-Object {
    $ut = Join-Path $_.FullName 'AppData\Local\Temp'
    if (Test-Path $ut) {
        Write-Log ("Pulizia: " + $ut)
        Get-ChildItem -LiteralPath $ut -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

try {
    Delete-DeliveryOptimizationCache -Force -ErrorAction Stop
    Write-Log "Cache Delivery Optimization eliminata"
}
catch {
    Write-Log "Cache Delivery Optimization non disponibile o già vuota"
}

Write-Log "Pulizia finale completata"

schtasks.exe /Delete /TN "__TASKNAME__" /F | Out-Null

$cmd = Join-Path $env:TEMP 'spex-clean-self.cmd'
("@echo off`r`nping 127.0.0.1 -n 3 >nul`r`ndel /f /q `"`"__PSPATH__`"`"`r`ndel /f /q `"`"%~f0`"`"") |
    Set-Content -Path $cmd -Encoding ASCII
Start-Process -FilePath $cmd -WindowStyle Hidden
""";
        ps = ps
            .Replace("__LOGPATH__", logPath.Replace("'", "''"))
            .Replace("__TASKNAME__", taskName)
            .Replace("__PSPATH__", psPath.Replace("\"", "\"\""));

        File.WriteAllText(psPath, ps, new System.Text.UTF8Encoding(false));

        // Elimina eventuale vecchio task con lo stesso nome.
        RunCapture("schtasks.exe", $"/Delete /TN \"{taskName}\" /F");

        // Esegue al prossimo avvio come SYSTEM, quindi può pulire anche Windows\Temp.
        string tr = $"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"{psPath}\"";
        var create = RunCapture(
            "schtasks.exe",
            $"/Create /TN \"{taskName}\" /TR \"{tr.Replace("\"", "\\\"")}\" /SC ONSTART /RU SYSTEM /RL HIGHEST /F");

        if (create.ExitCode != 0)
            throw new Exception("Impossibile programmare la pulizia finale. " + create.Output);

        Log("PULIZIA FINALE: programmata per il prossimo avvio.");
        Log("PULIZIA FINALE: verrà eseguita come SYSTEM e poi il task si eliminerà da solo.");
        Log($"PULIZIA FINALE: log -> {logPath}");
        Log("PULIZIA FINALE: non vengono svuotati Cestino, Download, Documenti o file personali.");
    }

    void RunBundledBat(string fileName, string content)
    {
        string dir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "SmartphonExpress", "Scripts");
        Directory.CreateDirectory(dir);

        string path = Path.Combine(dir, fileName);
        File.WriteAllText(path, content, System.Text.Encoding.Default);

        Log($"SCRIPT: avvio {fileName}");
        Log($"SCRIPT: {path}");

        using var proc = Process.Start(new ProcessStartInfo
        {
            FileName = "cmd.exe",
            Arguments = $"/c \"\"{path}\"\"",
            UseShellExecute = true,
            WorkingDirectory = dir,
            WindowStyle = ProcessWindowStyle.Normal
        });

        if (proc == null)
            throw new Exception($"Impossibile avviare {fileName}.");

        proc.WaitForExit();
        Log($"SCRIPT: {fileName} terminato con codice {proc.ExitCode}.");
    }

    void RunNetworkConfigBat()
    {
        const string script = """
@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Fix Condivisione Rete - Windows 10/11
echo.
echo ============================================
echo   FIX CONDIVISIONE CARTELLE IN RETE (LAN)
echo ============================================
echo   - Imposta profilo rete su PRIVATA
echo   - Abilita Network Discovery
echo   - Abilita File and Printer Sharing
echo   - Avvia e imposta servizi necessari
echo ============================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERRORE] Devi eseguire questo file come AMMINISTRATORE.
  echo Tasto destro ^> Esegui come amministratore
  pause
  exit /b 1
)

echo [1/4] Imposto il profilo di rete su PRIVATA...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-NetConnectionProfile | ForEach-Object { if($_.NetworkCategory -ne 'Private'){ Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private } }" ^
  >nul 2>&1

echo [2/4] Abilito le regole Firewall per Network Discovery e File Sharing...
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes >nul 2>&1
netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes >nul 2>&1

echo [3/4] Configuro e avvio i servizi necessari...
call :SvcAutoStart FDResPub
call :SvcAutoStart fdPHost
call :SvcAutoStart LanmanServer
call :SvcAutoStart LanmanWorkstation
call :SvcAutoStart SSDPSRV
call :SvcAutoStart upnphost

echo [4/4] Abilito la pubblicazione risorse (condivisione visibile in rete)...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Enable-NetFirewallRule -DisplayGroup 'Network Discovery' -ErrorAction SilentlyContinue | Out-Null } catch {}" ^
  >nul 2>&1

echo.
echo ============================================
echo FATTO.
echo - Se prima non si vedevano, riavvia il PC.
echo - Verifica che i PC siano nello stesso WORKGROUP (default: WORKGROUP).
echo ============================================
echo.
pause
exit /b 0

:SvcAutoStart
set "SVC=%~1"
sc query "%SVC%" >nul 2>&1
if %errorlevel% neq 0 (
  echo   - %SVC%: non presente su questo Windows (ok).
  goto :eof
)
sc config "%SVC%" start= auto >nul 2>&1
sc start "%SVC%" >nul 2>&1
echo   - %SVC%: OK
goto :eof
""";
        RunBundledBat("configurazione rete.bat", script);
    }

    void RunNetworkCompleteBat()
    {
        const string script = """
@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Fix Condivisione Rete - Compat

set "LOG=%USERPROFILE%\Desktop\FixShare_log.txt"
echo ==== START %DATE% %TIME% ==== > "%LOG%"

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERRORE] Esegui come amministratore.>>"%LOG%"
  echo [ERRORE] Devi eseguire questo file come AMMINISTRATORE.
  pause
  exit /b 1
)

set "SHARE_FOLDER=C:\Condivisa"
set "SHARE_NAME=Condivisa"
set "SHARE_USER=ShareUser"
set "WORKGROUP_NAME=WORKGROUP"

:MENU
cls
echo ==========================================
echo  Fix Condivisione Rete - COMPAT
echo  Log: %LOG%
echo ==========================================
echo [1] Fix rete (Privata + Firewall + Servizi)
echo [2] Crea share + utente + permessi
echo [3] Diagnostica
echo [0] Esci
echo.
set /p "CHOICE=Scelta: "
if "%CHOICE%"=="1" goto FIX_NETWORK
if "%CHOICE%"=="2" goto SHARE_SETUP
if "%CHOICE%"=="3" goto DIAG
if "%CHOICE%"=="0" goto END
goto MENU

:FIX_NETWORK
echo --- FIX_NETWORK --- >> "%LOG%"

echo Imposto profilo rete su Privata...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Get-NetConnectionProfile | ForEach-Object { if($_.NetworkCategory -ne 'Private'){ Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private } }" ^
  >>"%LOG%" 2>&1

echo Abilito firewall Discovery e File Sharing...
netsh advfirewall firewall set rule group="Network Discovery" new enable=Yes >>"%LOG%" 2>&1
netsh advfirewall firewall set rule group="File and Printer Sharing" new enable=Yes >>"%LOG%" 2>&1

echo Avvio servizi...
call :SvcAutoStart FDResPub
call :SvcAutoStart fdPHost
call :SvcAutoStart LanmanServer
call :SvcAutoStart LanmanWorkstation

echo Flush DNS...
ipconfig /flushdns >>"%LOG%" 2>&1

echo.
echo OK. (Se vuoi, riavvia dopo)
pause
goto MENU

:SHARE_SETUP
echo --- SHARE_SETUP --- >> "%LOG%"

echo.
echo Imposta una password per l'utente %SHARE_USER%:
for /f "usebackq delims=" %%P in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Read-Host 'Password' -AsSecureString; $b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($p); [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)"`) do set "PASS=%%P"

if not defined PASS (
  echo Password non letta.>>"%LOG%"
  echo [ERRORE] Non sono riuscito a leggere la password (PowerShell bloccato?).
  pause
  goto MENU
)

echo Creo cartella...
if not exist "%SHARE_FOLDER%" mkdir "%SHARE_FOLDER%" >>"%LOG%" 2>&1

echo Creo/aggiorno utente...
net user "%SHARE_USER%" >nul 2>&1
if %errorlevel% neq 0 (
  net user "%SHARE_USER%" "%PASS%" /add /y >>"%LOG%" 2>&1
) else (
  net user "%SHARE_USER%" "%PASS%" >>"%LOG%" 2>&1
)

echo Permessi NTFS...
icacls "%SHARE_FOLDER%" /inheritance:r >>"%LOG%" 2>&1
icacls "%SHARE_FOLDER%" /grant "Administrators:(OI)(CI)F" "SYSTEM:(OI)(CI)F" >>"%LOG%" 2>&1
icacls "%SHARE_FOLDER%" /grant "%COMPUTERNAME%\%SHARE_USER%:(OI)(CI)M" >>"%LOG%" 2>&1

echo Ricreo share...
net share "%SHARE_NAME%" >nul 2>&1
if %errorlevel%==0 net share "%SHARE_NAME%" /delete /y >>"%LOG%" 2>&1

net share "%SHARE_NAME%=%SHARE_FOLDER%" ^
  /grant:"%COMPUTERNAME%\%SHARE_USER%",CHANGE ^
  /grant:"Administrators",FULL ^
  /grant:"SYSTEM",FULL >>"%LOG%" 2>&1

echo.
echo Share pronta: \\%COMPUTERNAME%\%SHARE_NAME%
echo Utente: %COMPUTERNAME%\%SHARE_USER%
pause
goto MENU

:DIAG
echo --- DIAG --- >> "%LOG%"
cls
echo ====== DIAGNOSTICA ======
echo.

echo Profili rete:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetConnectionProfile | Select InterfaceAlias,NetworkCategory,IPv4Connectivity | Format-Table -AutoSize" 2>nul

echo.
echo Share presenti:
net share

echo.
echo IPv4:
ipconfig | findstr /I "IPv4"

echo.
echo (Dettagli nel log: %LOG%)
pause
goto MENU

:SvcAutoStart
set "SVC=%~1"
sc query "%SVC%" >>"%LOG%" 2>&1
sc config "%SVC%" start= auto >>"%LOG%" 2>&1
sc start "%SVC%" >>"%LOG%" 2>&1
goto :eof

:END
echo ==== END %DATE% %TIME% ====>>"%LOG%"
endlocal
exit /b 0
""";
        RunBundledBat("fix rete completo.bat", script);
    }

    void RunKmsCleanupBat()
    {
        const string script = """
@echo off
setlocal EnableExtensions EnableDelayedExpansion
title KMS/KMSpico cleanup (Windows 10/11)

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [ERRORE] Avvia questo file come AMMINISTRATORE.
  pause
  exit /b 1
)

echo ==========================================================
echo   KMS / KMSpico cleanup
echo   - servizi / task / cartelle / autorun
echo ==========================================================
echo.

set "LOG=%USERPROFILE%\Desktop\kms_cleanup_log.txt"
echo ==== LOG %DATE% %TIME% ==== > "%LOG%"

call :log "Avvio cleanup..."
call :log "Ricerca e rimozione servizi sospetti (kms/autokms)..."

for /f "tokens=2 delims=:" %%S in ('sc query type^= service state^= all ^| findstr /i "SERVICE_NAME:"') do (
  set "SVC=%%S"
  set "SVC=!SVC: =!"
  echo !SVC! | findstr /i "kms" >nul
  if !errorlevel! == 0 (
    call :log "Servizio trovato: !SVC!"
    sc stop "!SVC!" >> "%LOG%" 2>&1
    sc delete "!SVC!" >> "%LOG%" 2>&1
  )
)

call :log "Ricerca e rimozione Task pianificati (kms/autokms)..."
for /f "delims=" %%T in ('schtasks /Query /FO LIST /V ^| findstr /i /c:"TaskName:"') do (
  set "LINE=%%T"
  for /f "tokens=2* delims=:" %%A in ("!LINE!") do (
    set "TN=%%B"
    set "TN=!TN:~1!"
    echo !TN! | findstr /i "kms autokms" >nul
    if !errorlevel! == 0 (
      call :log "Task trovato: !TN!"
      schtasks /Delete /TN "!TN!" /F >> "%LOG%" 2>&1
    )
  )
)

call :log "Rimozione cartelle tipiche..."
call :delpath "C:\Program Files\KMSpico"
call :delpath "C:\Program Files (x86)\KMSpico"
call :delpath "C:\Windows\AutoKMS"
call :delpath "C:\Windows\System32\Tasks\AutoKMS"
call :delpath "%ProgramData%\KMSpico"
call :delpath "%ProgramData%\AutoKMS"

call :log "Pulizia voci di avvio nel Registro (Run/RunOnce con 'kms')..."
call :cleanrun "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
call :cleanrun "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"
call :cleanrun "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
call :cleanrun "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce"

call :log "Controllo file hosts (solo segnalazione righe con 'kms')..."
set "HOSTS=%WINDIR%\System32\drivers\etc\hosts"
if exist "%HOSTS%" (
  findstr /i "kms" "%HOSTS%" >nul
  if !errorlevel! == 0 (
    call :log "ATTENZIONE: trovate righe con 'kms' nel file hosts:"
    findstr /i "kms" "%HOSTS%" >> "%LOG%" 2>&1
  ) else (
    call :log "OK: nessuna riga 'kms' nel file hosts."
  )
)

call :log "Fine cleanup. Riavvia il PC."
echo.
echo ==========================================================
echo COMPLETATO. Log salvato su:
echo   %LOG%
echo ==========================================================
echo.
pause
exit /b 0

:log
echo [%DATE% %TIME%] %~1
echo [%DATE% %TIME%] %~1 >> "%LOG%"
exit /b

:delpath
set "P=%~1"
if exist "%P%" (
  call :log "Elimino: %P%"
  rmdir /s /q "%P%" >> "%LOG%" 2>&1
  del /f /q "%P%" >> "%LOG%" 2>&1
) else (
  call :log "Non trovato: %P%"
)
exit /b

:cleanrun
set "K=%~1"
reg query "%K%" >nul 2>&1
if %errorlevel% neq 0 (
  call :log "Chiave non presente: %K%"
  exit /b
)
for /f "tokens=1,2,*" %%A in ('reg query "%K%" ^| findstr /i "REG_"') do (
  echo %%C | findstr /i "kms" >nul
  if !errorlevel! == 0 (
    call :log "Rimuovo autorun: [%K%] %%A = %%C"
    reg delete "%K%" /v "%%A" /f >> "%LOG%" 2>&1
  )
)
exit /b
""";
        RunBundledBat("kmsPico remove.bat", script);
    }


    void DownloadPreconfiguredFile()
    {
        const string url = "https://raw.githubusercontent.com/smartphonexpress/winutilmirror/main/attivo.rar";

        Directory.CreateDirectory(temporaryDownloadFolder);

        string archivePath = Path.Combine(temporaryDownloadFolder, "attivo.rar");

        Log("DOWNLOAD PRECONFIGURATO: scarico attivo.rar...");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.0");
            byte[] data = http.GetByteArrayAsync(url).GetAwaiter().GetResult();
            File.WriteAllBytes(archivePath, data);
        }

        Log($"DOWNLOAD PRECONFIGURATO: completato -> {archivePath}");
        Log("ESTRAZIONE: avvio estrazione RAR...");

        var extractedFiles = new List<string>();

        using (var archive = SharpCompress.Archives.ArchiveFactory.OpenArchive(archivePath))
        {
            string root = Path.GetFullPath(temporaryDownloadFolder);
            if (!root.EndsWith(Path.DirectorySeparatorChar))
                root += Path.DirectorySeparatorChar;

            foreach (var entry in archive.Entries)
            {
                if (entry.IsDirectory || string.IsNullOrWhiteSpace(entry.Key))
                    continue;

                string key = Convert.ToString(entry.Key) ?? string.Empty;
                string relative = key
                    .Replace('/', Path.DirectorySeparatorChar)
                    .Replace('\\', Path.DirectorySeparatorChar);

                string destination = Path.GetFullPath(
                    Path.Combine(temporaryDownloadFolder, relative));

                // Protezione da path traversal nell'archivio.
                if (!destination.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                    throw new Exception("Archivio non valido: percorso di estrazione non sicuro.");

                extractedFiles.Add(destination);
            }

            SharpCompress.Archives.IArchiveExtensions.WriteToDirectory(
                archive,
                temporaryDownloadFolder,
                new SharpCompress.Common.ExtractionOptions
                {
                    ExtractFullPath = true,
                    Overwrite = true
                });
        }

        Log($"ESTRAZIONE: completata ({extractedFiles.Count} file).");
        Log("DOWNLOAD PRECONFIGURATO: nessun file viene eseguito automaticamente.");
        Log("PULIZIA: archivio, file estratti e cartella SmartphonExpress verranno eliminati alla chiusura.");

        string? selectPath = extractedFiles.FirstOrDefault(File.Exists);

        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = selectPath is not null
                ? $"/select,\"{selectPath}\""
                : $"\"{temporaryDownloadFolder}\"",
            UseShellExecute = true
        });
    }

    void DownloadFlyOobe()
    {
        DownloadAndExtractZip(
            "https://github.com/smartphonexpress/winutilmirror/raw/refs/heads/main/FlyoobeApp.zip",
            "FlyoobeApp.zip",
            "FlyOOBE");
    }

    void DownloadFlyby11()
    {
        DownloadAndExtractZip(
            "https://github.com/smartphonexpress/winutilmirror/raw/refs/heads/main/Flyby11.zip",
            "Flyby11.zip",
            "Flyby11");
    }

    void DownloadAndExtractZip(string url, string archiveFileName, string packageFolderName)
    {
        string packageRoot = Path.Combine(temporaryDownloadFolder, packageFolderName);
        string extractFolder = Path.Combine(packageRoot, "Estratto");
        string archivePath = Path.Combine(packageRoot, archiveFileName);

        Directory.CreateDirectory(packageRoot);

        Log($"{packageFolderName.ToUpperInvariant()}: download in corso...");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.0");
            byte[] data = http.GetByteArrayAsync(url).GetAwaiter().GetResult();
            File.WriteAllBytes(archivePath, data);
        }

        Log($"{packageFolderName.ToUpperInvariant()}: download completato -> {archivePath}");

        if (Directory.Exists(extractFolder))
            Directory.Delete(extractFolder, true);

        Directory.CreateDirectory(extractFolder);

        Log($"{packageFolderName.ToUpperInvariant()}: estrazione ZIP...");

        // Estrazione sicura contro percorsi che tentano di uscire dalla cartella prevista.
        using (var zip = ZipFile.OpenRead(archivePath))
        {
            string root = Path.GetFullPath(extractFolder);
            if (!root.EndsWith(Path.DirectorySeparatorChar))
                root += Path.DirectorySeparatorChar;

            foreach (var entry in zip.Entries)
            {
                string destination = Path.GetFullPath(
                    Path.Combine(extractFolder, entry.FullName));

                if (!destination.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                    throw new Exception("Archivio ZIP non valido: percorso di estrazione non sicuro.");

                if (string.IsNullOrEmpty(entry.Name))
                {
                    Directory.CreateDirectory(destination);
                    continue;
                }

                string? parent = Path.GetDirectoryName(destination);
                if (!string.IsNullOrWhiteSpace(parent))
                    Directory.CreateDirectory(parent);

                entry.ExtractToFile(destination, true);
            }
        }

        // Rimuove subito lo ZIP: alla chiusura viene eliminata definitivamente
        // anche tutta la cartella con i file estratti.
        try
        {
            if (File.Exists(archivePath))
                File.Delete(archivePath);
        }
        catch (Exception ex)
        {
            Log($"{packageFolderName.ToUpperInvariant()}: impossibile eliminare subito lo ZIP: {ex.Message}");
        }

        var extractedFiles = Directory
            .EnumerateFiles(extractFolder, "*", SearchOption.AllDirectories)
            .ToList();

        Log($"{packageFolderName.ToUpperInvariant()}: estrazione completata ({extractedFiles.Count} file).");
        Log($"{packageFolderName.ToUpperInvariant()}: nessun file viene eseguito automaticamente.");
        Log($"{packageFolderName.ToUpperInvariant()}: tutto verrà eliminato definitivamente alla chiusura del tool.");

        string? selectPath =
            extractedFiles.FirstOrDefault(x => x.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
            ?? extractedFiles.FirstOrDefault();

        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = selectPath is not null
                ? $"/select,\"{selectPath}\""
                : $"\"{extractFolder}\"",
            UseShellExecute = true
        });
    }

    void LogSmartAppControlState(string fase)
    {
        try
        {
            using var k = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\CI\Policy");
            object? raw = k?.GetValue("VerifiedAndReputablePolicyState");

            if (raw is null)
            {
                Log($"SMART APP CONTROL ({fase}): stato non presente nel Registro.");
                return;
            }

            int value = Convert.ToInt32(raw);
            string state = value switch
            {
                0 => "Off",
                1 => "On / Enforce",
                2 => "Evaluation",
                _ => "Valore sconosciuto: " + value
            };

            Log($"SMART APP CONTROL ({fase}): {state} [{value}]");
        }
        catch (Exception ex)
        {
            Log($"SMART APP CONTROL ({fase}): impossibile leggere lo stato: {ex.Message}");
        }
    }

    void DisableAppReputationControls()
    {
        Log("SICUREZZA APP: disattivo SmartScreen e controlli reputazione app...");
        LogSmartAppControlState("prima");

        // "Controlla app e file" / SmartScreen per Explorer.
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\System", "EnableSmartScreen", 0);
        Log("SICUREZZA APP: SmartScreen Explorer disattivato.");

        // Compatibilità con la voce storica di Explorer.
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "SmartScreenEnabled", "Off");

        // Consenti installazione/esecuzione di app non provenienti dallo Store.
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "AicEnabled", "Anywhere");

        // SmartScreen per contenuti/app del profilo utente.
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\AppHost", "EnableWebContentEvaluation", 0);

        // Smart App Control: Off.
        SetLM(@"SYSTEM\CurrentControlSet\Control\CI\Policy", "VerifiedAndReputablePolicyState", 0);
        Log("SICUREZZA APP: Smart App Control impostato su Off.");

        string ciTool = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.System),
            "CiTool.exe");

        if (File.Exists(ciTool))
        {
            Log("SMART APP CONTROL: aggiorno la policy con CiTool...");
            var ci = RunCaptureWithTimeout(ciTool, "-r", 15000);

            if (ci.TimedOut)
            {
                currentRunTimeouts++;
                Log("SMART APP CONTROL: CiTool non ha risposto entro 15 secondi; continuo. La modifica verrà recepita al riavvio.");
            }
            else if (!string.IsNullOrWhiteSpace(ci.Output))
                Log("SMART APP CONTROL: " + ci.Output.Replace("\r", " ").Replace("\n", " ").Trim());
            else
                Log($"SMART APP CONTROL: refresh completato (exit code {ci.ExitCode}).");
        }

        LogSmartAppControlState("dopo");
        Log("SICUREZZA APP: SmartScreen / reputazione app disattivati.");
        Log("SICUREZZA APP: per alcune modifiche può essere necessario riavviare Windows.");
    }

    void RestoreAppReputationControls()
    {
        Log("SICUREZZA APP: ripristino controlli reputazione app...");

        // Torna al comportamento gestito/predefinito di Windows.
        DelLM(@"SOFTWARE\Policies\Microsoft\Windows\System", "EnableSmartScreen");
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "SmartScreenEnabled", "Warn");
        DelLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer", "AicEnabled");
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\AppHost", "EnableWebContentEvaluation", 1);

        // Rimuove la forzatura di Smart App Control e lascia che Windows ne gestisca lo stato.
        DelLM(@"SYSTEM\CurrentControlSet\Control\CI\Policy", "VerifiedAndReputablePolicyState");

        string ciTool = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.System),
            "CiTool.exe");

        if (File.Exists(ciTool))
        {
            Log("SMART APP CONTROL: aggiorno la policy con CiTool...");
            var ci = RunCaptureWithTimeout(ciTool, "-r", 15000);

            if (ci.TimedOut)
            {
                currentRunTimeouts++;
                Log("SMART APP CONTROL: CiTool non ha risposto entro 15 secondi; continuo. La modifica verrà recepita al riavvio.");
            }
            else if (!string.IsNullOrWhiteSpace(ci.Output))
                Log("SMART APP CONTROL: " + ci.Output.Replace("\r", " ").Replace("\n", " ").Trim());
            else
                Log($"SMART APP CONTROL: refresh completato (exit code {ci.ExitCode}).");
        }

        Log("SICUREZZA APP: controlli reputazione ripristinati.");
        Log("SICUREZZA APP: per alcune modifiche può essere necessario riavviare Windows.");
    }

    void CreateAppFolderShortcut()
    {
        string desktop = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        string shortcutPath = Path.Combine(desktop, "AppFolder.lnk");

        string assetsFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SmartphonExpress");
        Directory.CreateDirectory(assetsFolder);

        string iconPath = Path.Combine(assetsFolder, "AppFolder.ico");
        CreateAppFolderIcon(iconPath);

        Type? shellType = Type.GetTypeFromProgID("WScript.Shell");
        if (shellType is null)
            throw new Exception("WScript.Shell non disponibile.");

        dynamic shell = Activator.CreateInstance(shellType)!;
        dynamic shortcut = shell.CreateShortcut(shortcutPath);

        shortcut.TargetPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            "explorer.exe");
        shortcut.Arguments = "shell:AppsFolder";
        shortcut.WorkingDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        shortcut.Description = "Tutte le applicazioni installate";
        shortcut.IconLocation = iconPath + ",0";
        shortcut.Save();

        Log($"APPFOLDER: collegamento creato/aggiornato sul Desktop -> {shortcutPath}");
    }

    static void CreateAppFolderIcon(string iconPath)
    {
        const int size = 64;

        using var bmp = new Bitmap(size, size, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

        using (var g = Graphics.FromImage(bmp))
        {
            g.Clear(Color.Transparent);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            using var tileBrush = new SolidBrush(Color.FromArgb(40, 115, 220));
            using var borderPen = new Pen(Color.FromArgb(25, 85, 165), 1.4f);

            const int tile = 13;
            const int gap = 5;
            int total = tile * 3 + gap * 2;
            int startPos = (size - total) / 2;

            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    var rect = new Rectangle(
                        startPos + col * (tile + gap),
                        startPos + row * (tile + gap),
                        tile,
                        tile);

                    g.FillRectangle(tileBrush, rect);
                    g.DrawRectangle(borderPen, rect);
                }
            }
        }

        using var pngStream = new MemoryStream();
        bmp.Save(pngStream, System.Drawing.Imaging.ImageFormat.Png);
        byte[] png = pngStream.ToArray();

        using var fs = new FileStream(iconPath, FileMode.Create, FileAccess.Write, FileShare.Read);
        using var bw = new BinaryWriter(fs);

        bw.Write((ushort)0);
        bw.Write((ushort)1);
        bw.Write((ushort)1);

        bw.Write((byte)size);
        bw.Write((byte)size);
        bw.Write((byte)0);
        bw.Write((byte)0);

        bw.Write((ushort)1);
        bw.Write((ushort)32);

        bw.Write(png.Length);
        bw.Write(6 + 16);
        bw.Write(png);
    }

    void DownloadTemporaryFile()
    {
        (string Url, string Extension)? request = null;

        if (InvokeRequired)
        {
            Invoke(() => request = ShowDownloadDialog());
        }
        else
        {
            request = ShowDownloadDialog();
        }

        if (request is null)
        {
            Log("DOWNLOAD TEMP: annullato.");
            return;
        }

        string url = request.Value.Url.Trim();
        string extension = request.Value.Extension.Trim();

        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
            throw new Exception("URL non valido. Usa un indirizzo http:// o https://.");

        Directory.CreateDirectory(temporaryDownloadFolder);

        string fileName = Path.GetFileName(Uri.UnescapeDataString(uri.AbsolutePath));
        if (string.IsNullOrWhiteSpace(fileName))
            fileName = "download_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");

        // Avoid invalid Windows filename characters.
        foreach (char c in Path.GetInvalidFileNameChars())
            fileName = fileName.Replace(c, '_');

        // Optional generic extension. The user can leave it blank.
        if (!string.IsNullOrWhiteSpace(extension))
        {
            if (!extension.StartsWith("."))
                extension = "." + extension;

            // Only a simple extension is accepted; this is a rename only, never execution.
            if (extension.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||
                extension.Contains("\\") || extension.Contains("/"))
                throw new Exception("Estensione non valida.");

            if (!fileName.EndsWith(extension, StringComparison.OrdinalIgnoreCase))
                fileName += extension;
        }

        string target = Path.Combine(temporaryDownloadFolder, fileName);

        Log($"DOWNLOAD TEMP: scarico {fileName}...");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.1");
            byte[] data = http.GetByteArrayAsync(uri).GetAwaiter().GetResult();
            File.WriteAllBytes(target, data);
        }

        Log($"DOWNLOAD TEMP: completato -> {target}");
        Log("DOWNLOAD TEMP: il file NON viene eseguito automaticamente.");

        Process.Start(new ProcessStartInfo
        {
            FileName = "explorer.exe",
            Arguments = $"/select,\"{target}\"",
            UseShellExecute = true
        });
    }

    (string Url, string Extension)? ShowDownloadDialog()
    {
        using var dlg = new Form
        {
            Text = "Download temporaneo",
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false,
            ShowInTaskbar = false,
            ClientSize = new Size(590, 225),
            Font = new Font("Segoe UI", 9.5f)
        };

        var info = new Label
        {
            Text = "Inserisci un URL diretto al file. Il download verrà salvato in Downloads\\\\SmartphonExpress,\\naperto in Esplora file ma mai eseguito automaticamente.",
            AutoSize = true,
            Location = new Point(18, 16)
        };

        var urlLabel = new Label
        {
            Text = "URL:",
            AutoSize = true,
            Location = new Point(18, 70)
        };

        var urlBox = new TextBox
        {
            Location = new Point(18, 91),
            Width = 550
        };

        var extLabel = new Label
        {
            Text = "Estensione da aggiungere (facoltativa, es. .txt):",
            AutoSize = true,
            Location = new Point(18, 127)
        };

        var extBox = new TextBox
        {
            Location = new Point(18, 148),
            Width = 230
        };

        var ok = new Button
        {
            Text = "Scarica",
            DialogResult = DialogResult.OK,
            Location = new Point(374, 180),
            Size = new Size(92, 32)
        };

        var cancel = new Button
        {
            Text = "Annulla",
            DialogResult = DialogResult.Cancel,
            Location = new Point(476, 180),
            Size = new Size(92, 32)
        };

        dlg.Controls.AddRange(new Control[] { info, urlLabel, urlBox, extLabel, extBox, ok, cancel });
        dlg.AcceptButton = ok;
        dlg.CancelButton = cancel;

        if (dlg.ShowDialog(this) != DialogResult.OK)
            return null;

        if (string.IsNullOrWhiteSpace(urlBox.Text))
        {
            MessageBox.Show("Inserisci l'URL del file.", "Download temporaneo",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return null;
        }

        return (urlBox.Text.Trim(), extBox.Text.Trim());
    }

    void CleanupTemporaryDownloads()
    {
        try
        {
            if (!Directory.Exists(temporaryDownloadFolder))
                return;

            // Permanent deletion: no Recycle Bin.
            Directory.Delete(temporaryDownloadFolder, true);
        }
        catch (Exception ex)
        {
            try
            {
                Log("DOWNLOAD TEMP: impossibile eliminare completamente la cartella alla chiusura: " + ex.Message);
            }
            catch { }
        }
    }

    void RunNetworkDiagnostics()
    {
        Log("RETE: diagnostica in corso...");

        string ps = """
$ErrorActionPreference='SilentlyContinue'
$all = @(Get-NetAdapter | Where-Object { $_.Name -notmatch 'Loopback' })
$physical = @($all | Where-Object { $_.HardwareInterface -eq $true })
$virtual = @($all | Where-Object { $_.HardwareInterface -ne $true })

if ($all.Count -eq 0) {
    Write-Output 'NESSUNA_SCHEDA_TROVATA'
    exit 2
}

function Write-AdapterInfo($a, $kind) {
    $ipcfg = Get-NetIPConfiguration -InterfaceIndex $a.ifIndex
    $v4if = Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4
    $v6if = Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv6
    $dns4 = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4).ServerAddresses
    $dns6 = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv6).ServerAddresses
    $gw4 = @(($ipcfg.IPv4DefaultGateway.NextHop))
    $isInternet = ($a.Status -eq 'Up' -and $gw4.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace(($gw4 -join '')))

    Write-Output ('TIPO=' + $kind)
    Write-Output ('ADAPTER=' + $a.Name)
    Write-Output ('DESC=' + $a.InterfaceDescription)
    Write-Output ('STATO=' + $a.Status)
    Write-Output ('CONNESSIONE_INTERNET=' + $(if($isInternet){'SI'}else{'NO'}))
    Write-Output ('LINK=' + $(if($a.Status -eq 'Up'){$a.LinkSpeed}else{'Non connessa'}))
    Write-Output ('DHCP4=' + $v4if.Dhcp)
    Write-Output ('DHCP6=' + $v6if.Dhcp)
    Write-Output ('IPV4=' + (($ipcfg.IPv4Address.IPAddress) -join ', '))
    Write-Output ('IPV6=' + (($ipcfg.IPv6Address.IPAddress) -join ', '))
    Write-Output ('GATEWAY=' + ($gw4 -join ', '))
    Write-Output ('DNS4=' + ($dns4 -join ', '))
    Write-Output ('DNS6=' + ($dns6 -join ', '))
    Write-Output '---'
}

Write-Output '=== SCHEDE FISICHE ==='
foreach ($a in $physical) { Write-AdapterInfo $a 'FISICA' }

if ($virtual.Count -gt 0) {
    Write-Output '=== SCHEDE VIRTUALI / SECONDARIE ==='
    foreach ($a in $virtual) { Write-AdapterInfo $a 'VIRTUALE' }
}
""";

        var result = RunCaptureWithTimeout(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"",
            20000);

        if (result.TimedOut)
        {
            currentRunTimeouts++;
            Log("RETE: diagnostica interrotta per timeout dopo 20 secondi.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(result.Output))
        {
            foreach (var line in result.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("RETE: " + line.Trim());
        }

        if (result.ExitCode != 0)
            throw new Exception($"Diagnostica rete terminata con codice {result.ExitCode}.");

        Log("RETE: diagnostica completata. Mostrate anche le schede fisiche non connesse e separate le interfacce virtuali.");
        ShowDiagnosticReport("Rete — Diagnostica completa", result.Output);
    }

    void SetGoogleDns()
    {
        ConfigureDnsProvider(
            "Google",
            new[]
            {
                "8.8.8.8",
                "8.8.4.4",
                "2001:4860:4860::8888",
                "2001:4860:4860::8844"
            });
    }

    void SetCloudflareDns()
    {
        ConfigureDnsProvider(
            "Cloudflare",
            new[]
            {
                "1.1.1.1",
                "1.0.0.1",
                "2606:4700:4700::1111",
                "2606:4700:4700::1001"
            });
    }

    void ConfigureDnsProvider(string provider, string[] servers)
    {
        string psServers = string.Join(",", servers.Select(x => $"'{x}'"));

        string command =
            "$adapters=@(Get-NetAdapter -Physical -ErrorAction SilentlyContinue);" +
            "if($adapters.Count -eq 0){" +
                "$adapters=@(Get-NetAdapter -ErrorAction Stop | Where-Object {$_.Name -notmatch 'Loopback' -and $_.HardwareInterface -eq $true});" +
            "};" +
            "if($adapters.Count -eq 0){throw 'Nessuna scheda di rete fisica trovata.'};" +
            $"foreach($a in $adapters){{Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses @({psServers}) -ErrorAction Stop;" +
                "Write-Output ($a.Name + ' -> ' + ((Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex).ServerAddresses -join ', '))" +
            "};" +
            "Clear-DnsClientCache";

        var result = RunCapture(
            "powershell.exe",
            $"-NoProfile -ExecutionPolicy Bypass -Command \"{command.Replace("\"", "\\\"")}\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
            Log($"DNS {provider.ToUpperInvariant()}: " + result.Output.Replace("\r", " ").Replace("\n", " | ").Trim());

        if (result.ExitCode != 0)
            throw new Exception($"Impossibile impostare i DNS {provider}. " + result.Output);

        Log($"DNS: {provider} impostato su tutte le schede di rete fisiche, incluse quelle al momento non connesse.");
        Log($"DNS IPv4: {servers[0]} primario / {servers[1]} secondario.");
        Log($"DNS IPv6: {servers[2]} primario / {servers[3]} secondario.");
    }

    void ResetDnsAutomatic()
    {
        string command =
            "$adapters=@(Get-NetAdapter -Physical -ErrorAction SilentlyContinue);" +
            "if($adapters.Count -eq 0){" +
                "$adapters=@(Get-NetAdapter -ErrorAction Stop | Where-Object {$_.Name -notmatch 'Loopback' -and $_.HardwareInterface -eq $true});" +
            "};" +
            "if($adapters.Count -eq 0){throw 'Nessuna scheda di rete fisica trovata.'};" +
            "foreach($a in $adapters){Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ResetServerAddresses -ErrorAction Stop;" +
                "Write-Output ($a.Name + ' -> DNS automatico/DHCP')" +
            "};" +
            "Clear-DnsClientCache";

        var result = RunCapture(
            "powershell.exe",
            $"-NoProfile -ExecutionPolicy Bypass -Command \"{command.Replace("\"", "\\\"")}\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
            Log("DNS RIPRISTINO: " + result.Output.Replace("\r", " ").Replace("\n", " | ").Trim());

        if (result.ExitCode != 0)
            throw new Exception("Impossibile ripristinare i DNS automatici. " + result.Output);

        Log("DNS: ripristinato l'uso dei DNS automatici/DHCP su tutte le schede di rete fisiche, incluse quelle non connesse.");
    }

    void CheckWindowsLicense()
    {
        Log("LICENZA WINDOWS: controllo stato attivazione...");

        var state = GetWindowsQuickStatus();
        windowsActivationSummary = state.Text.ToUpperInvariant();
        Log("LICENZA WINDOWS: risultato = " + windowsActivationSummary);

        // Dettaglio aggiuntivo nel log: slmgr /dlv e' utile nei casi dubbi,
        // ma lo stato principale resta basato sui dati strutturati SoftwareLicensingProduct.
        try
        {
            string slmgr = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "slmgr.vbs");
            if (File.Exists(slmgr))
            {
                var dlv = RunCaptureWithTimeout("cscript.exe", "//Nologo " + Quote(slmgr) + " /dli", 30000);
                if (!dlv.TimedOut && dlv.ExitCode == 0 && !string.IsNullOrWhiteSpace(dlv.Output))
                {
                    foreach (var line in dlv.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                        Log("LICENZA WINDOWS: " + line.Trim());
                }
            }
        }
        catch (Exception ex)
        {
            Log("LICENZA WINDOWS: dettaglio slmgr non disponibile: " + ex.Message);
        }
    }

    void CheckOfficeLicense()
    {
        Log("LICENZA OFFICE: controllo stato...");

        bool installed = IsOfficeInstalled();
        if (!installed)
        {
            officeActivationSummary = "NON INSTALLATO";
            Log("LICENZA OFFICE: nessuna installazione Office/Visio/Project rilevata.");
            return;
        }

        bool licensed = false;
        bool unlicensed = false;
        bool anyMethod = false;

        // Microsoft 365 / Project / Visio in abbonamento: da Office v1910 OSPP non e' piu'
        // il metodo corretto. Microsoft indica vnextdiag.ps1 come controllo ufficiale.
        string? vnext = FindOfficeVNextDiag();
        if (vnext is not null)
        {
            anyMethod = true;
            Log("LICENZA OFFICE: vnextdiag -> " + vnext);
            var vr = RunCaptureWithTimeout(
                "powershell.exe",
                "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(vnext) + " -action list",
                45000);

            if (!vr.TimedOut && vr.ExitCode == 0)
            {
                foreach (var line in (vr.Output ?? "").Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                    Log("LICENZA OFFICE [VNext]: " + line.Trim());

                var parsed = ParseOfficeLicenseOutput(vr.Output);
                licensed |= parsed.Licensed;
                unlicensed |= parsed.Unlicensed;
            }
            else
            {
                Log(vr.TimedOut
                    ? "LICENZA OFFICE: vnextdiag timeout."
                    : $"LICENZA OFFICE: vnextdiag exit code {vr.ExitCode}.");
            }
        }

        // Office LTSC / volume: OSPP resta il metodo Microsoft previsto.
        string? ospp = FindOsppVbs();
        if (ospp is not null)
        {
            anyMethod = true;
            Log("LICENZA OFFICE: OSPP -> " + ospp);
            var or = RunCaptureWithTimeout("cscript.exe", "//Nologo " + Quote(ospp) + " /dstatusall", 45000);
            if (!or.TimedOut && or.ExitCode == 0)
            {
                foreach (var line in (or.Output ?? "").Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                    Log("LICENZA OFFICE [OSPP]: " + line.Trim());

                var parsed = ParseOfficeLicenseOutput(or.Output);
                licensed |= parsed.Licensed;
                unlicensed |= parsed.Unlicensed;
            }
            else
            {
                Log(or.TimedOut
                    ? "LICENZA OFFICE: OSPP timeout."
                    : $"LICENZA OFFICE: OSPP exit code {or.ExitCode}.");
            }
        }

        if (licensed)
            officeActivationSummary = "ATTIVATO";
        else if (unlicensed)
            officeActivationSummary = "NON ATTIVATO / LICENZA DA VERIFICARE";
        else if (!anyMethod)
            officeActivationSummary = "INSTALLATO / STATO NON DETERMINABILE";
        else
            officeActivationSummary = "STATO DA VERIFICARE";

        Log("LICENZA OFFICE: risultato = " + officeActivationSummary);
    }

    static string? FindOfficeVNextDiag()
    {
        string[] candidates =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\Office16\vnextdiag.ps1"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\root\Office16\vnextdiag.ps1"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\Office16\vnextdiag.ps1"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\root\Office16\vnextdiag.ps1")
        };
        return candidates.FirstOrDefault(File.Exists);
    }

    static string? FindOsppVbs()
    {
        string[] candidates =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\root\Office16\OSPP.VBS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\Office16\OSPP.VBS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\root\Office16\OSPP.VBS"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\Office16\OSPP.VBS")
        };
        return candidates.FirstOrDefault(File.Exists);
    }

    static (bool Licensed, bool Unlicensed) ParseOfficeLicenseOutput(string? output)
    {
        string o = output ?? string.Empty;
        bool licensed =
            o.IndexOf("---LICENSED---", StringComparison.OrdinalIgnoreCase) >= 0 ||
            System.Text.RegularExpressions.Regex.IsMatch(o, @"(?im)license\s*(state|status)\s*:\s*licensed\b") ||
            System.Text.RegularExpressions.Regex.IsMatch(o, @"(?im)stato\s*(della\s*)?licenza\s*:\s*(con\s+licenza|licenziato|attivato)\b");

        bool unlicensed =
            o.IndexOf("---UNLICENSED---", StringComparison.OrdinalIgnoreCase) >= 0 ||
            o.IndexOf("---NOTIFICATIONS---", StringComparison.OrdinalIgnoreCase) >= 0 ||
            o.IndexOf("---OOB_GRACE---", StringComparison.OrdinalIgnoreCase) >= 0 ||
            System.Text.RegularExpressions.Regex.IsMatch(o, @"(?im)license\s*(state|status)\s*:\s*(unlicensed|notification|grace|expired)\b") ||
            System.Text.RegularExpressions.Regex.IsMatch(o, @"(?im)stato\s*(della\s*)?licenza\s*:\s*(senza\s+licenza|non\s+attivato|scadut[oa])\b");

        return (licensed, unlicensed);
    }

    static bool IsOfficeInstalled()
    {
        try
        {
            string[] exeCandidates =
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\root\Office16\WINWORD.EXE"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft Office\Office16\WINWORD.EXE"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\root\Office16\WINWORD.EXE"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\Office16\WINWORD.EXE")
            };
            if (exeCandidates.Any(File.Exists)) return true;

            using var c2r = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Office\ClickToRun\Configuration");
            string ids = Convert.ToString(c2r?.GetValue("ProductReleaseIds")) ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(ids)) return true;

            return GetOfficeInstalledProducts().Count > 0;
        }
        catch { return false; }
    }

    static List<string> GetOfficeInstalledProducts()
    {
        var found = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        void Scan(RegistryKey hive, string path)
        {
            try
            {
                using var root = hive.OpenSubKey(path);
                if (root is null) return;
                foreach (string subName in root.GetSubKeyNames())
                {
                    using var sub = root.OpenSubKey(subName);
                    string name = Convert.ToString(sub?.GetValue("DisplayName")) ?? string.Empty;
                    if (string.IsNullOrWhiteSpace(name)) continue;
                    bool office = name.IndexOf("Microsoft 365", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  name.IndexOf("Microsoft Office", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  name.IndexOf("Office LTSC", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  name.IndexOf("Microsoft Visio", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                  name.IndexOf("Microsoft Project", StringComparison.OrdinalIgnoreCase) >= 0;
                    if (office) found.Add(name.Trim());
                }
            }
            catch { }
        }

        Scan(Registry.LocalMachine, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
        Scan(Registry.LocalMachine, @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall");
        Scan(Registry.CurrentUser, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
        return found.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }

    static Label MakeQuickStatusLabel(string name, string value, Color color)
    {
        return new Label
        {
            AutoSize = false, Width = 285, Height = 22,
            Text = $"● {name}: {value}",
            Font = new Font("Segoe UI", 8.7f),
            ForeColor = color,
            TextAlign = ContentAlignment.MiddleLeft
        };
    }

    static void SetQuickStatus(Label label, string name, (string Text, int Kind) state)
    {
        label.Text = $"● {name}: {state.Text}";
        label.ForeColor = state.Kind switch
        {
            1 => Color.FromArgb(28, 140, 75),
            2 => Color.FromArgb(196, 55, 55),
            _ => Color.FromArgb(110, 120, 132)
        };
    }

    static (string Text, int Kind) GetWindowsQuickStatus()
    {
        try
        {
            const string windowsAppId = "55c92734-d682-4d71-983e-d6ec3f16059f";
            string ps =
                "$app='" + windowsAppId + "';" +
                "$p=@(Get-CimInstance -ClassName SoftwareLicensingProduct -ErrorAction Stop | " +
                "Where-Object {$_.ApplicationID -eq $app -and $_.PartialProductKey});" +
                "if($p.Count -eq 0){'UNKNOWN'}" +
                "elseif(@($p|Where-Object {$_.LicenseStatus -eq 1}).Count -gt 0){'LICENSED'}" +
                "elseif(@($p|Where-Object {$_.LicenseStatus -in 0,2,3,4,5,6}).Count -gt 0){'UNLICENSED'}" +
                "else{'UNKNOWN'}";
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(ps));
            var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded, 30000);
            if (!r.TimedOut && r.ExitCode == 0)
            {
                string output = (r.Output ?? "").Trim();
                if (output.EndsWith("LICENSED", StringComparison.OrdinalIgnoreCase) &&
                    !output.EndsWith("UNLICENSED", StringComparison.OrdinalIgnoreCase)) return ("Attivato", 1);
                if (output.EndsWith("UNLICENSED", StringComparison.OrdinalIgnoreCase)) return ("Non attivato", 2);
            }

            // Fallback ufficiale: slmgr /xpr. Usato solo se il controllo strutturato non ha risposto.
            string slmgr = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "slmgr.vbs");
            if (File.Exists(slmgr))
            {
                var xpr = RunCaptureWithTimeout("cscript.exe", "//Nologo " + Quote(slmgr) + " /xpr", 30000);
                if (!xpr.TimedOut && xpr.ExitCode == 0)
                {
                    string o = (xpr.Output ?? "").ToLowerInvariant();
                    if (o.Contains("permanently activated") || o.Contains("attivato definitivamente") ||
                        o.Contains("attivata definitivamente") || o.Contains("attivazione permanente") ||
                        o.Contains("permanentemente attivato") || o.Contains("permanentemente attivata"))
                        return ("Attivato", 1);
                    if (o.Contains("not activated") || o.Contains("non attivato") || o.Contains("non attivata") ||
                        o.Contains("notification mode") || o.Contains("modalità di notifica"))
                        return ("Non attivato", 2);
                    // Una data di scadenza reale indica tipicamente un client KMS attualmente attivato.
                    if ((o.Contains("expiration") || o.Contains("expires") || o.Contains("scadenza") || o.Contains("scadrà")) &&
                        !o.Contains("not activated") && !o.Contains("non attiv"))
                        return ("Attivato (scadenza)", 1);
                }
            }
        }
        catch { }
        return ("Da verificare", 0);
    }

    static (string Text, int Kind) GetOfficeQuickStatus()
    {
        try
        {
            if (!IsOfficeInstalled()) return ("Non installato", 0);

            bool licensed = false;
            bool unlicensed = false;
            bool checkedAny = false;

            string? vnext = FindOfficeVNextDiag();
            if (vnext is not null)
            {
                checkedAny = true;
                var r = RunCaptureWithTimeout("powershell.exe",
                    "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(vnext) + " -action list", 30000);
                if (!r.TimedOut && r.ExitCode == 0)
                {
                    var p = ParseOfficeLicenseOutput(r.Output);
                    licensed |= p.Licensed;
                    unlicensed |= p.Unlicensed;
                }
            }

            string? ospp = FindOsppVbs();
            if (ospp is not null)
            {
                checkedAny = true;
                var r = RunCaptureWithTimeout("cscript.exe", "//Nologo " + Quote(ospp) + " /dstatusall", 30000);
                if (!r.TimedOut && r.ExitCode == 0)
                {
                    var p = ParseOfficeLicenseOutput(r.Output);
                    licensed |= p.Licensed;
                    unlicensed |= p.Unlicensed;
                }
            }

            if (licensed) return ("Attivato", 1);
            if (unlicensed) return ("Non attivato", 2);
            return checkedAny ? ("Da verificare", 0) : ("Installato / verifica account", 0);
        }
        catch { return ("Da verificare", 0); }
    }

    static (string Text, int Kind) GetDefenderQuickStatus()
    {
        try
        {
            string ps = "$s=Get-MpComputerStatus -ErrorAction Stop; if($s.AntivirusEnabled -and $s.RealTimeProtectionEnabled){'ACTIVE'}elseif($s.AntivirusEnabled){'PARTIAL'}else{'OFF'}";
            var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"", 15000);
            string v = r.Output.Trim();
            if (!r.TimedOut && r.ExitCode == 0)
            {
                if (v.Equals("ACTIVE", StringComparison.OrdinalIgnoreCase)) return ("Attivo", 1);
                if (v.Equals("OFF", StringComparison.OrdinalIgnoreCase)) return ("Non attivo", 2);
                if (v.Equals("PARTIAL", StringComparison.OrdinalIgnoreCase)) return ("Protezione parziale", 0);
            }
        }
        catch { }
        return ("Da verificare", 0);
    }

    async Task ToggleTemporaryDefenderAsync()
    {
        if (defenderToggleButton is null) return;
        defenderToggleButton.Enabled = false;
        try
        {
            if (!defenderTemporaryOffByTool)
            {
                var confirm = MessageBox.Show(
                    "Disattivare temporaneamente la protezione Defender?\n\n" +
                    "Verranno sospesi solo:\n• Protezione in tempo reale\n• Protezione fornita dal cloud\n• Invio automatico campioni\n• Blocco al primo rilevamento\n\n" +
                    "Firewall, SmartScreen, Accesso controllato alle cartelle e Protezione antimanomissione NON vengono modificati.\n" +
                    "Alla chiusura del tool verranno ripristinati esclusivamente i valori cambiati da questo switch.",
                    "Defender temporaneo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirm != DialogResult.Yes) return;

                var result = await Task.Run(DisableTemporaryDefenderProtection);
                if (!result.Ok)
                {
                    MessageBox.Show(result.Message, "Defender temporaneo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                defenderTemporaryOffByTool = true;
                UpdateDefenderToggleUi(false);
                if (defenderQuickStatusLabel is not null)
                    SetQuickStatus(defenderQuickStatusLabel, "Defender", ("Protezione ridotta", 2));
            }
            else
            {
                await Task.Run(RestoreTemporaryDefenderProtection);
                defenderTemporaryOffByTool = false;
                UpdateDefenderToggleUi(true);
                if (defenderQuickStatusLabel is not null)
                {
                    var state = await Task.Run(GetDefenderQuickStatus);
                    SetQuickStatus(defenderQuickStatusLabel, "Defender", state);
                }
            }
        }
        finally { defenderToggleButton.Enabled = true; }
    }

    (bool Ok, string Message) DisableTemporaryDefenderProtection()
    {
        try
        {
            string read = "$p=Get-MpPreference -ErrorAction Stop; " +
                          "Write-Output ('RT=' + [int][bool]$p.DisableRealtimeMonitoring); " +
                          "Write-Output ('MAPS=' + [int]$p.MAPSReporting); " +
                          "Write-Output ('SAMPLES=' + [int]$p.SubmitSamplesConsent); " +
                          "Write-Output ('BAFS=' + [int][bool]$p.DisableBlockAtFirstSeen)";
            string encRead = Convert.ToBase64String(Encoding.Unicode.GetBytes(read));
            var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encRead, 20000);
            if (r.TimedOut || r.ExitCode != 0) return (false, "Impossibile leggere lo stato corrente di Defender. Nessuna impostazione è stata modificata.");

            var vals = new Dictionary<string,int>(StringComparer.OrdinalIgnoreCase);
            foreach (string line in (r.Output ?? "").Split(new[]{'\r','\n'}, StringSplitOptions.RemoveEmptyEntries))
            {
                int eq=line.IndexOf('=');
                if(eq>0 && int.TryParse(line[(eq+1)..].Trim(), out int v)) vals[line[..eq].Trim()]=v;
            }
            if (!vals.ContainsKey("RT") || !vals.ContainsKey("MAPS") || !vals.ContainsKey("SAMPLES") || !vals.ContainsKey("BAFS"))
                return (false, "Defender non ha restituito tutti i parametri necessari. Nessuna impostazione è stata modificata.");

            defenderOldRealtimeDisabled = vals["RT"] != 0;
            defenderOldMapsReporting = vals["MAPS"];
            defenderOldSubmitSamplesConsent = vals["SAMPLES"];
            defenderOldBlockAtFirstSeenDisabled = vals["BAFS"] != 0;

            string set = "Set-MpPreference -DisableRealtimeMonitoring $true -MAPSReporting 0 -SubmitSamplesConsent 2 -DisableBlockAtFirstSeen $true -ErrorAction Stop";
            string encSet = Convert.ToBase64String(Encoding.Unicode.GetBytes(set));
            var w = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encSet, 20000);
            if (w.TimedOut || w.ExitCode != 0)
                return (false, "Windows non ha consentito la modifica. Se Protezione antimanomissione è attiva, alcune impostazioni di Defender possono essere bloccate.");
            return (true, "OK");
        }
        catch (Exception ex) { return (false, "Errore Defender: " + ex.Message); }
    }

    void RestoreTemporaryDefenderProtection()
    {
        if (!defenderTemporaryOffByTool || defenderRestoreInProgress) return;
        defenderRestoreInProgress = true;
        try
        {
            string rt = defenderOldRealtimeDisabled ? "$true" : "$false";
            string bafs = defenderOldBlockAtFirstSeenDisabled ? "$true" : "$false";
            string set = $"Set-MpPreference -DisableRealtimeMonitoring {rt} -MAPSReporting {defenderOldMapsReporting} -SubmitSamplesConsent {defenderOldSubmitSamplesConsent} -DisableBlockAtFirstSeen {bafs} -ErrorAction Stop";
            string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(set));
            RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc, 20000);
            defenderTemporaryOffByTool = false;
        }
        finally { defenderRestoreInProgress = false; }
    }

    void UpdateDefenderToggleUi(bool enabled)
    {
        if (defenderToggleButton is null) return;
        if (enabled)
        {
            defenderToggleButton.Text = "DEFENDER  ON";
            defenderToggleButton.BackColor = Color.FromArgb(230, 247, 237);
            defenderToggleButton.ForeColor = Color.FromArgb(24, 120, 65);
            defenderToggleButton.FlatAppearance.BorderColor = Color.FromArgb(28, 140, 75);
        }
        else
        {
            defenderToggleButton.Text = "DEFENDER  OFF";
            defenderToggleButton.BackColor = Color.FromArgb(255, 235, 235);
            defenderToggleButton.ForeColor = Color.FromArgb(180, 45, 45);
            defenderToggleButton.FlatAppearance.BorderColor = Color.FromArgb(196, 55, 55);
        }
    }

    static void RunVisible(string exe, string args)
    {
        Process.Start(new ProcessStartInfo(exe,args){UseShellExecute=true});
    }

    static void OpenWindowsActivation() => Process.Start(new ProcessStartInfo("ms-settings:activation"){UseShellExecute=true});
    static void OpenMicrosoft365() => Process.Start(new ProcessStartInfo("https://www.microsoft365.com/"){UseShellExecute=true});

    static void PS(string command) =>
        Run("powershell.exe",$"-NoProfile -ExecutionPolicy Bypass -Command \"{command.Replace("\"","\\\"")}\"");

    static void DisableNewOutlook()
    {
        // Mantiene Outlook classico come scelta predefinita.
        SetCU(@"SOFTWARE\Microsoft\Office\16.0\Outlook\Preferences","UseNewOutlook",0);

        // Microsoft: 1 = nasconde il toggle "Prova il nuovo Outlook".
        SetCU(@"Software\Microsoft\Office\16.0\Outlook\Options\General","HideNewOutlookToggle",1);

        // Blocca sia la migrazione amministrata sia la migrazione automatica lato utente.
        SetCU(@"Software\Policies\Microsoft\Office\16.0\Outlook\Options\General","DoNewOutlookAutoMigration",0);
        SetCU(@"Software\Policies\Microsoft\Office\16.0\Outlook\Preferences","NewOutlookMigrationUserSetting",0);

        // Evita che la migrazione venga riproposta periodicamente.
        SetCU(@"Software\Policies\Microsoft\Office\16.0\Outlook\Options\General","NewOutlookAutoMigrationRetryIntervals",0);
    }
    static void ShowClassicDesktopIcons()
    {
        string[] paths = {
            @"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel",
            @"Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\ClassicStartMenu"
        };
        string[] icons = {
            "{20D04FE0-3AEA-1069-A2D8-08002B30309D}", // Questo PC
            "{59031A47-3F72-44A7-89C5-5595FE6B30EE}", // File utente
            "{5399E694-6CE5-4D6C-8FCE-1D8870FDCBA0}", // Pannello di controllo
            "{645FF040-5081-101B-9F08-00AA002F954E}", // Cestino
            "{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}"  // Rete
        };
        foreach (var path in paths)
            foreach (var icon in icons)
                SetCU(path, icon, 0);

        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "HideIcons", 0);

        // Aggiorna il desktop senza chiudere forzatamente Explorer.
        Run("ie4uinit.exe", "-show");
    }

    static void EnableNumLock()
    {
        SetCU(@"Control Panel\Keyboard","InitialKeyboardIndicators","2");
        using var users=Registry.Users.CreateSubKey(@".Default\Control Panel\Keyboard",true)!;
        users.SetValue("InitialKeyboardIndicators","2",RegistryValueKind.String);
    }
    static void ExplorerFolderType()
    {
        try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags",false); } catch {}
        try { Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU",false); } catch {}
        SetCU(@"Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell","FolderType","NotSpecified");
    }
    static void ServiceTweaks()
    {
        Run("sc.exe","config CscService start= disabled");
        Run("sc.exe","config StorSvc start= demand");
    }
    static void Telemetry()
    {
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo","Enabled",0);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Privacy","TailoredExperiencesWithDiagnosticDataEnabled",0);
        SetCU(@"Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy","HasAccepted",0);
        SetCU(@"Software\Microsoft\Input\TIPC","Enabled",0);
        SetCU(@"Software\Microsoft\InputPersonalization","RestrictImplicitInkCollection",1);
        SetCU(@"Software\Microsoft\InputPersonalization","RestrictImplicitTextCollection",1);
        SetCU(@"Software\Microsoft\InputPersonalization\TrainedDataStore","HarvestContacts",0);
        SetCU(@"Software\Microsoft\Personalization\Settings","AcceptedPrivacyPolicy",0);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced","Start_TrackProgs",0);
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\System","PublishUserActivities",0);
        SetCU(@"Software\Microsoft\Siuf\Rules","NumberOfSIUFInPeriod",0);

        // Percorso policy ufficiale DataCollection.
        // Telemetry=0 è supportato solo su Enterprise/Education/Server;
        // su Pro il minimo effettivo supportato è 1.
        string productName = "";
        try
        {
            using var cv = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            productName = cv?.GetValue("ProductName")?.ToString() ?? "";
        }
        catch { }

        bool supportsSecurityLevel =
            productName.Contains("Enterprise", StringComparison.OrdinalIgnoreCase) ||
            productName.Contains("Education", StringComparison.OrdinalIgnoreCase) ||
            productName.Contains("Server", StringComparison.OrdinalIgnoreCase);

        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\DataCollection",
              "AllowTelemetry",
              supportsSecurityLevel ? 0 : 1);
    }
    static void EnablePerformanceVisuals()
    {
        SetCU(@"Control Panel\Desktop\WindowMetrics", "MinAnimate", "0");
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", 0);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "TaskbarAnimations", 0);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "ListviewAlphaSelect", 0);
        Run("ie4uinit.exe", "-show");
    }

    static void RestorePerformanceVisuals()
    {
        SetCU(@"Control Panel\Desktop\WindowMetrics", "MinAnimate", "1");
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", 1);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "TaskbarAnimations", 1);
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", "ListviewAlphaSelect", 1);
        Run("ie4uinit.exe", "-show");
    }

    static void EnableHighPerformancePlan()
    {
        Run("powercfg.exe", "/setactive SCHEME_MIN");
    }

    static void RestoreBalancedPowerPlan()
    {
        Run("powercfg.exe", "/setactive SCHEME_BALANCED");
    }

    void OptimizeStartupPrograms()
    {
        // Approccio conservativo: disattiva SOLO applicazioni note e non essenziali.
        // Tutto ciò che non riconosciamo viene lasciato invariato.
        string[] disablePatterns =
        {
            "chrome", "google chrome", "msedge", "microsoft edge", "firefox", "brave", "opera", "vivaldi",
            "teams", "msteams", "discord", "skype", "zoom",
            "steam", "epicgameslauncher", "epic games", "eadesktop", "ea app", "origin",
            "ubisoft", "upc", "battle.net", "battlenet", "riotclient", "riot client", "gog galaxy",
            "spotify", "adobe creative cloud", "creative cloud", "adobe gc invoker", "adobegcinvoker",
            "adobe updater", "java update", "jusched"
        };

        string[] protectPatterns =
        {
            // Sicurezza / antivirus / EDR
            "defender", "securityhealth", "windows security", "antivirus", "avast", "avg", "bitdefender",
            "kaspersky", "eset", "norton", "mcafee", "malwarebytes", "sophos", "trend micro", "crowdstrike",
            // Cloud / download / utility Microsoft richieste
            "onedrive", "google drive", "googledrive", "dropbox", "icloud", "pc manager", "microsoft pc manager",
            "powertoys", "power toys", "internet download manager", "idman", "idm",
            // GPU / audio / chipset / input / OEM
            "nvidia", "nvcontainer", "amd", "radeon", "intel", "igfx", "realtek", "nahimic", "dolby",
            "synaptics", "elan", "touchpad", "hotkey", "hotkeys", "fnkey", "fn key", "driver support assistant",
            "supportassist", "lenovo utility", "lenovoutility", "myasus", "asus optimization", "hp system event",
            // VPN / password manager / backup
            "vpn", "openvpn", "wireguard", "nordvpn", "expressvpn", "surfshark", "protonvpn",
            "1password", "bitwarden", "keepass", "dashlane", "lastpass",
            "acronis", "veeam", "macrium", "backup"
        };

        bool Matches(string text, string[] patterns) =>
            patterns.Any(p => text.Contains(p, StringComparison.OrdinalIgnoreCase));

        string backupRoot = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SmartphonExpress", "StartupBackup");
        Directory.CreateDirectory(backupRoot);
        string backupFile = Path.Combine(backupRoot, "startup-registry.txt");
        string shortcutBackup = Path.Combine(backupRoot, "Shortcuts");
        Directory.CreateDirectory(shortcutBackup);

        var disabled = new List<string>();
        var protectedItems = new List<string>();
        var backupLines = new List<string>();

        void ProcessRunKey(RegistryKey root, string hive, string keyPath)
        {
            using var key = root.OpenSubKey(keyPath, writable: true);
            if (key == null) return;

            foreach (var name in key.GetValueNames())
            {
                object? value = key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
                if (value == null) continue;
                string data = value.ToString() ?? "";
                string searchable = name + " " + data;

                if (Matches(searchable, protectPatterns))
                {
                    protectedItems.Add(name);
                    continue;
                }
                if (!Matches(searchable, disablePatterns)) continue;

                var kind = key.GetValueKind(name);
                string encoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(data));
                backupLines.Add($"REG|{hive}|{keyPath}|{name}|{kind}|{encoded}");
                key.DeleteValue(name, false);
                disabled.Add(name);
            }
        }

        ProcessRunKey(Registry.CurrentUser, "HKCU", @"Software\Microsoft\Windows\CurrentVersion\Run");
        ProcessRunKey(Registry.LocalMachine, "HKLM", @"Software\Microsoft\Windows\CurrentVersion\Run");
        if (Environment.Is64BitOperatingSystem)
            ProcessRunKey(Registry.LocalMachine, "HKLM", @"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run");

        void ProcessStartupFolder(string folder, string tag)
        {
            if (!Directory.Exists(folder)) return;
            foreach (var file in Directory.GetFiles(folder))
            {
                string searchable = Path.GetFileNameWithoutExtension(file);
                if (Matches(searchable, protectPatterns))
                {
                    protectedItems.Add(searchable);
                    continue;
                }
                if (!Matches(searchable, disablePatterns)) continue;

                string tagDir = Path.Combine(shortcutBackup, tag);
                Directory.CreateDirectory(tagDir);
                string dest = Path.Combine(tagDir, Path.GetFileName(file));
                if (File.Exists(dest)) File.Delete(dest);
                File.Move(file, dest);
                disabled.Add(searchable);
            }
        }

        ProcessStartupFolder(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "USER");
        ProcessStartupFolder(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup), "COMMON");

        if (backupLines.Count > 0)
            File.AppendAllLines(backupFile, backupLines, Encoding.UTF8);

        string disabledText = disabled.Count == 0 ? "Nessun programma riconosciuto da disattivare." :
            string.Join(Environment.NewLine, disabled.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).Select(x => "• " + x));
        string protectedText = protectedItems.Count == 0 ? "Nessuna voce protetta rilevata tra quelle esaminate." :
            string.Join(Environment.NewLine, protectedItems.Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).Select(x => "• " + x));

        ShowDiagnosticReport("Avvio automatico ottimizzato",
            $"DISATTIVATI: {disabled.Distinct(StringComparer.OrdinalIgnoreCase).Count()}\r\n{disabledText}\r\n\r\n" +
            $"PROTETTI / LASCIATI ATTIVI: {protectedItems.Distinct(StringComparer.OrdinalIgnoreCase).Count()}\r\n{protectedText}\r\n\r\n" +
            "Nota: le voci non riconosciute non vengono modificate. Il ripristino ricrea le voci salvate e rimette gli elementi delle cartelle Esecuzione automatica.");
    }

    void RestoreStartupPrograms()
    {
        string backupRoot = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SmartphonExpress", "StartupBackup");
        string backupFile = Path.Combine(backupRoot, "startup-registry.txt");
        int restored = 0;

        if (File.Exists(backupFile))
        {
            foreach (var line in File.ReadAllLines(backupFile, Encoding.UTF8).Distinct())
            {
                var p = line.Split('|');
                if (p.Length != 6 || p[0] != "REG") continue;
                try
                {
                    RegistryKey root = p[1] == "HKLM" ? Registry.LocalMachine : Registry.CurrentUser;
                    using var key = root.CreateSubKey(p[2], writable: true);
                    string data = Encoding.UTF8.GetString(Convert.FromBase64String(p[5]));
                    if (!Enum.TryParse<RegistryValueKind>(p[4], out var kind)) kind = RegistryValueKind.String;
                    key?.SetValue(p[3], data, kind);
                    restored++;
                }
                catch { }
            }
            try { File.Delete(backupFile); } catch { }
        }

        string shortcutBackup = Path.Combine(backupRoot, "Shortcuts");
        void RestoreFolder(string tag, string target)
        {
            string src = Path.Combine(shortcutBackup, tag);
            if (!Directory.Exists(src)) return;
            Directory.CreateDirectory(target);
            foreach (var file in Directory.GetFiles(src))
            {
                try
                {
                    string dest = Path.Combine(target, Path.GetFileName(file));
                    if (!File.Exists(dest)) { File.Move(file, dest); restored++; }
                }
                catch { }
            }
        }
        RestoreFolder("USER", Environment.GetFolderPath(Environment.SpecialFolder.Startup));
        RestoreFolder("COMMON", Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup));

        ShowDiagnosticReport("Ripristino avvio automatico", $"Elementi ripristinati: {restored}.\r\nLe voci che non erano state modificate dal tool sono rimaste intatte.");
    }

    void OptimizeSystemDrive()
    {
        string drive = Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\";
        var r = RunCaptureWithTimeout("defrag.exe", $"{drive} /O /U /V", 120000);

        if (r.TimedOut)
        {
            currentRunTimeouts++;
            Log("PRESTAZIONI: ottimizzazione unità interrotta per timeout dopo 120 secondi.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(r.Output))
        {
            foreach (var line in r.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("PRESTAZIONI DISCO: " + line.Trim());
        }

        if (r.ExitCode != 0)
            throw new Exception($"Ottimizzazione unità terminata con codice {r.ExitCode}.");
    }

    void CheckTrimStatus()
    {
        var r = RunCaptureWithTimeout(
            "fsutil.exe",
            "behavior query DisableDeleteNotify",
            15000);

        if (r.TimedOut)
        {
            currentRunTimeouts++;
            Log("TRIM: timeout durante il controllo.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(r.Output))
        {
            foreach (var line in r.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("TRIM: " + line.Trim());
        }

        if (r.ExitCode != 0)
            throw new Exception($"Controllo TRIM terminato con codice {r.ExitCode}.");
    }

    void AuditStartupPrograms()
    {
        string ps = """
Get-CimInstance Win32_StartupCommand |
Sort-Object Name |
ForEach-Object {
    'NAME=' + $_.Name
    'COMMAND=' + $_.Command
    'LOCATION=' + $_.Location
    'USER=' + $_.User
    '---'
}
""";

        var r = RunCaptureWithTimeout(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"",
            20000);

        if (r.TimedOut)
        {
            currentRunTimeouts++;
            Log("AVVIO: analisi interrotta per timeout.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(r.Output))
        {
            foreach (var line in r.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("AVVIO: " + line.Trim());
        }

        if (r.ExitCode != 0)
            throw new Exception($"Analisi programmi in avvio terminata con codice {r.ExitCode}.");
    }

    void RunPerformanceCheck()
    {
        string ps = """
$ErrorActionPreference='SilentlyContinue'

$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$cs  = Get-CimInstance Win32_ComputerSystem
$os  = Get-CimInstance Win32_OperatingSystem
$batt = Get-CimInstance Win32_Battery | Select-Object -First 1

'CPU=' + $cpu.Name
'CPU_LOAD=' + $cpu.LoadPercentage + '%'
'RAM_TOTAL_GB=' + [math]::Round($cs.TotalPhysicalMemory/1GB,1)
'RAM_FREE_GB=' + [math]::Round(($os.FreePhysicalMemory*1KB)/1GB,1)

if ($batt) {
    'BATTERY_CARICA=' + $batt.EstimatedChargeRemaining + '%'
} else {
    'BATTERY=non presente'
}

Get-PhysicalDisk | ForEach-Object {
    'DISK=' + $_.FriendlyName + ' | Media=' + $_.MediaType + ' | Health=' + $_.HealthStatus + ' | SizeGB=' + [math]::Round($_.Size/1GB,0)
}

Get-Volume | Where-Object DriveLetter | ForEach-Object {
    'VOLUME=' + $_.DriveLetter + ': | FreeGB=' + [math]::Round($_.SizeRemaining/1GB,1) + ' | SizeGB=' + [math]::Round($_.Size/1GB,1)
}
""";

        var r = RunCaptureWithTimeout(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"",
            25000);

        if (r.TimedOut)
        {
            currentRunTimeouts++;
            Log("CHECK PRESTAZIONI: timeout dopo 25 secondi.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(r.Output))
            ShowDiagnosticReport("Prestazioni — hardware e software", r.Output);

        if (r.ExitCode != 0)
            throw new Exception($"Check prestazioni terminato con codice {r.ExitCode}.");
    }

    void ShowDiagnosticReport(string title, string report)
    {
        if (InvokeRequired)
        {
            Invoke(() => ShowDiagnosticReport(title, report));
            return;
        }

        // Il log resta completo anche quando il risultato viene mostrato nel report esterno.
        Log("REPORT: " + title);
        foreach (var line in (report ?? string.Empty).Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
            Log("  " + line.TrimEnd());

        if (collectDiagnosticReports)
        {
            diagnosticReports.Add((title, report ?? string.Empty));
            return;
        }

        ShowDiagnosticReportWindow(title, report ?? string.Empty);
    }

    void ShowDiagnosticReportWindow(string title, string report)
    {
        if (InvokeRequired)
        {
            Invoke(() => ShowDiagnosticReportWindow(title, report));
            return;
        }
        using var form = new Form
        {
            Text = title,
            StartPosition = FormStartPosition.CenterParent,
            Size = new Size(800, 600),
            MinimumSize = new Size(620, 440),
            BackColor = Color.White,
            Font = new Font("Segoe UI", 9.5f)
        };
        var box = new TextBox
        {
            Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both,
            WordWrap = false, Dock = DockStyle.Fill, Font = new Font("Consolas", 9.5f),
            Text = report.Replace("\n", Environment.NewLine)
        };
        var bar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 52, Padding = new Padding(8) };
        var copy = new Button { Text = "Copia", Width = 100, Height = 32 };
        var save = new Button { Text = "Salva TXT", Width = 100, Height = 32 };
        var close = new Button { Text = "Chiudi", Width = 100, Height = 32 };
        copy.Click += (_,__) => { if (!string.IsNullOrEmpty(box.Text)) Clipboard.SetText(box.Text); };
        save.Click += (_,__) =>
        {
            using var dlg = new SaveFileDialog { Filter = "File di testo (*.txt)|*.txt", FileName = "SmartphonExpress-Diagnostica.txt" };
            if (dlg.ShowDialog(form) == DialogResult.OK) File.WriteAllText(dlg.FileName, box.Text, Encoding.UTF8);
        };
        close.Click += (_,__) => form.Close();
        bar.Controls.Add(copy); bar.Controls.Add(save); bar.Controls.Add(close);
        form.Controls.Add(box); form.Controls.Add(bar);
        form.ShowDialog(this);
    }

    void RunSfcScan()
    {
        Log("SFC: avvio /scannow. L'operazione può richiedere diversi minuti...");
        var first = RunCaptureWithTimeout("sfc.exe", "/scannow", 45 * 60 * 1000);
        var report = new StringBuilder();
        report.AppendLine("SFC /SCANNOW");
        report.AppendLine($"Exit code: {first.ExitCode}");
        report.AppendLine($"Timeout: {(first.TimedOut ? "SI" : "NO")}");
        report.AppendLine();
        report.AppendLine(string.IsNullOrWhiteSpace(first.Output) ? "Nessun output restituito da SFC." : first.Output);

        if (first.TimedOut)
        {
            ShowDiagnosticReport("SFC — Controllo file di sistema", report.ToString());
            throw new Exception("SFC ha superato il timeout di 45 minuti.");
        }
        if (first.ExitCode < 0)
        {
            ShowDiagnosticReport("SFC — Controllo file di sistema", report.ToString());
            throw new Exception("Impossibile avviare SFC. Consulta il report.");
        }

        // Autoriparazione mirata solo per gli errori Windows Resource Protection noti.
        // Non disabilita WRP e non modifica altre protezioni di Windows.
        if (!IsWrpRepairError(first.Output))
        {
            ShowDiagnosticReport("SFC — Controllo file di sistema", report.ToString());
            Log($"SFC: terminato (exit code {first.ExitCode}). Consulta il report per l'esito dettagliato.");
            return;
        }

        Log("SFC: rilevato errore Windows Resource Protection. Avvio autoriparazione supportata...");
        report.AppendLine();
        report.AppendLine("=== AUTORIPARAZIONE WINDOWS RESOURCE PROTECTION ===");
        report.AppendLine("Rilevato: Windows Resource Protection non riesce a completare SFC.");
        report.AppendLine("La protezione NON viene disabilitata.");

        // Microsoft indica di verificare l'esistenza di queste due cartelle quando WRP
        // restituisce 'could not perform the requested operation'.
        string temp = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "WinSxS", "Temp");
        foreach (var folderName in new[] { "PendingDeletes", "PendingRenames" })
        {
            string folder = Path.Combine(temp, folderName);
            try
            {
                bool existed = Directory.Exists(folder);
                if (!existed) Directory.CreateDirectory(folder);
                report.AppendLine($"{folderName}: {(existed ? "presente" : "mancante - creata")}");
                Log($"SFC/WRP: {folderName} {(existed ? "presente" : "creata")}.");
            }
            catch (Exception ex)
            {
                report.AppendLine($"{folderName}: ERRORE - {ex.Message}");
                Log($"SFC/WRP: impossibile verificare/creare {folderName}: {ex.Message}");
            }
        }

        // Se il servizio di riparazione non parte, proviamo ad avviare TrustedInstaller.
        // Se era già attivo, l'eventuale codice non-zero di SC non è considerato un guasto.
        var tiQuery = RunCaptureWithTimeout("sc.exe", "query TrustedInstaller", 15000);
        report.AppendLine();
        report.AppendLine("Windows Modules Installer / TrustedInstaller:");
        report.AppendLine(string.IsNullOrWhiteSpace(tiQuery.Output) ? $"query exit code {tiQuery.ExitCode}" : tiQuery.Output);
        if (IsWrpRepairServiceError(first.Output) || !tiQuery.Output.Contains("RUNNING", StringComparison.OrdinalIgnoreCase))
        {
            Log("SFC/WRP: tentativo avvio Windows Modules Installer (TrustedInstaller)...");
            var tiStart = RunCaptureWithTimeout("sc.exe", "start TrustedInstaller", 20000);
            report.AppendLine("Tentativo avvio TrustedInstaller:");
            report.AppendLine(string.IsNullOrWhiteSpace(tiStart.Output) ? $"exit code {tiStart.ExitCode}" : tiStart.Output);
        }

        // Ripariamo il Component Store prima di rilanciare SFC.
        var dismSteps = new[]
        {
            (Name: "CheckHealth", Args: "/Online /Cleanup-Image /CheckHealth", Timeout: 10 * 60 * 1000),
            (Name: "ScanHealth", Args: "/Online /Cleanup-Image /ScanHealth", Timeout: 30 * 60 * 1000),
            (Name: "RestoreHealth", Args: "/Online /Cleanup-Image /RestoreHealth", Timeout: 60 * 60 * 1000)
        };

        bool dismFailed = false;
        foreach (var step in dismSteps)
        {
            Log($"SFC/WRP: DISM {step.Name}...");
            var d = RunCaptureWithTimeout("dism.exe", step.Args, step.Timeout);
            report.AppendLine();
            report.AppendLine($"=== DISM {step.Name.ToUpperInvariant()} ===");
            report.AppendLine($"Exit code: {d.ExitCode} | Timeout: {(d.TimedOut ? "SI" : "NO")}");
            report.AppendLine(string.IsNullOrWhiteSpace(d.Output) ? "Nessun output." : d.Output);
            if (d.TimedOut || d.ExitCode != 0)
            {
                dismFailed = true;
                Log($"SFC/WRP: DISM {step.Name} non riuscito (exit {d.ExitCode}, timeout={d.TimedOut}).");
                if (LooksLikeRpc1726(d.Output, d.ExitCode))
                {
                    Log("SFC/WRP: rilevato RPC 1726; aggiungo diagnostica conflitti servizi al report.");
                    report.AppendLine(BuildRpc1726DiagnosticReport());
                }
                // Se DISM non riesce, non ha senso proseguire con gli step successivi o ripetere SFC alla cieca.
                break;
            }
        }

        if (!dismFailed)
        {
            Log("SFC/WRP: DISM completato. Nuovo tentativo SFC /scannow...");
            var retry = RunCaptureWithTimeout("sfc.exe", "/scannow", 45 * 60 * 1000);
            report.AppendLine();
            report.AppendLine("=== SECONDO TENTATIVO SFC /SCANNOW ===");
            report.AppendLine($"Exit code: {retry.ExitCode} | Timeout: {(retry.TimedOut ? "SI" : "NO")}");
            report.AppendLine(string.IsNullOrWhiteSpace(retry.Output) ? "Nessun output." : retry.Output);

            if (retry.TimedOut)
                report.AppendLine("ESITO: SFC ha superato il timeout anche dopo l'autoriparazione.");
            else if (IsWrpRepairError(retry.Output))
            {
                report.AppendLine();
                report.AppendLine("ESITO: l'errore Windows Resource Protection persiste.");
                report.AppendLine("Passo successivo consigliato: eseguire SFC in Modalità provvisoria.");
                report.AppendLine("Il Tool non disabilita Windows Resource Protection e non applica forzature distruttive.");
            }
            else
                report.AppendLine("ESITO: secondo tentativo SFC completato. Verificare il messaggio SFC sopra per sapere se sono stati trovati/riparati file corrotti.");
        }
        else
        {
            report.AppendLine();
            report.AppendLine("ESITO: DISM non è riuscito a riparare/verificare il Component Store.");
            report.AppendLine("SFC non è stato rilanciato automaticamente per evitare tentativi inutili.");
            report.AppendLine("Consultare l'errore DISM sopra; può essere necessaria una sorgente di riparazione Windows compatibile.");
        }

        ShowDiagnosticReport("SFC — Controllo e autoriparazione WRP", report.ToString());
        Log("SFC/WRP: procedura terminata. Consulta il report per il risultato completo.");
    }

    static bool IsWrpRepairError(string? output)
    {
        if (string.IsNullOrWhiteSpace(output)) return false;
        string s = output.ToLowerInvariant();
        return s.Contains("windows resource protection could not perform the requested operation") ||
               s.Contains("protezione risorse di windows: impossibile eseguire l'operazione richiesta") ||
               s.Contains("protezione risorse di windows non è riuscita a eseguire l'operazione richiesta") ||
               IsWrpRepairServiceError(output);
    }

    static bool IsWrpRepairServiceError(string? output)
    {
        if (string.IsNullOrWhiteSpace(output)) return false;
        string s = output.ToLowerInvariant();
        return s.Contains("windows resource protection could not start the repair service") ||
               s.Contains("protezione risorse di windows: impossibile avviare il servizio di ripristino") ||
               s.Contains("protezione risorse di windows non è riuscita ad avviare il servizio di ripristino");
    }


    static bool LooksLikeRpc1726(string? output, int exitCode)
    {
        string t = (output ?? string.Empty).ToLowerInvariant();
        return exitCode == 1726 || t.Contains("1726") ||
               t.Contains("remote procedure call failed") ||
               t.Contains("procedura di chiamata remota non è riuscita") ||
               t.Contains("procedura di chiamata remota non e riuscita");
    }

    string BuildRpc1726DiagnosticReport()
    {
        var sb = new StringBuilder();
        sb.AppendLine("RPC / DISM — DIAGNOSTICA ERRORE 1726");
        sb.AppendLine(new string('-', 72));
        sb.AppendLine("I servizi RPC core vengono solo verificati: SmartphonExpress NON ne cambia configurazione o tipo di avvio.");
        sb.AppendLine();

        foreach (var name in new[] { "RpcSs", "DcomLaunch", "RpcEptMapper", "TrustedInstaller" })
        {
            var q = RunCaptureWithTimeout("sc.exe", "query " + name, 15000);
            sb.AppendLine("=== " + name + " ===");
            sb.AppendLine(q.Output.Trim());
            sb.AppendLine();
        }

        string ps = """
$ErrorActionPreference='SilentlyContinue'
function Get-ExeFromPathName([string]$p) {
  if([string]::IsNullOrWhiteSpace($p)){ return $null }
  $p=$p.Trim()
  if($p.StartsWith('"')) { $i=$p.IndexOf('"',1); if($i -gt 1){ return $p.Substring(1,$i-1) } }
  $m=[regex]::Match($p,'^(.+?\.exe)(?:\s|$)','IgnoreCase'); if($m.Success){ return $m.Groups[1].Value }
  return ($p -split ' ')[0]
}
'=== SERVIZI NON MICROSOFT ATTIVI / CANDIDATI AL CONFLITTO ==='
$items=@()
Get-CimInstance Win32_Service | Where-Object { $_.State -eq 'Running' } | ForEach-Object {
  $exe=Get-ExeFromPathName $_.PathName
  if(-not $exe -or -not (Test-Path $exe)){ return }
  $sig=Get-AuthenticodeSignature -FilePath $exe
  $sub=''; if($sig.SignerCertificate){ $sub=$sig.SignerCertificate.Subject }
  $isMs=($sig.Status -eq 'Valid' -and $sub -match 'Microsoft')
  if(-not $isMs){
    $items += [pscustomobject]@{Name=$_.Name; Display=$_.DisplayName; StartMode=$_.StartMode; Path=$exe; Signature=$sig.Status; Signer=$sub}
  }
}
if($items.Count -eq 0){ 'Nessun servizio di terze parti attivo identificato con questo criterio.' }
else { $items | Sort-Object Display | Format-Table -AutoSize | Out-String -Width 220 }
""";
        string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(ps));
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc, 120000);
        sb.AppendLine(r.Output.Trim());
        sb.AppendLine();
        sb.AppendLine("Interpretazione:");
        sb.AppendLine("• Se SFC/DISM funzionano in Modalità provvisoria ma falliscono nell'avvio normale, un servizio/driver/componente caricato solo nell'avvio normale è un candidato concreto.");
        sb.AppendLine("• L'elenco sopra è diagnostico: non dimostra da solo quale sia il colpevole.");
        sb.AppendLine("• Per un test controllato usa 'Ripristino: isola servizi non Microsoft (test)' e poi riavvia Windows normalmente.");
        sb.AppendLine("• Dopo il test usa RIPRISTINO sulla stessa voce per rimettere esattamente i servizi salvati.");
        return sb.ToString();
    }

    void RunRpcServiceConflictDiagnostics()
    {
        Log("RPC 1726: raccolta diagnostica servizi e possibili conflitti...");
        ShowDiagnosticReport("RPC / DISM — Diagnostica conflitti servizi", BuildRpc1726DiagnosticReport());
    }

    static string CleanBootSnapshotPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
        "SmartphonExpress", "thirdparty-service-isolation.tsv");

    void PrepareThirdPartyServiceIsolation()
    {
        var confirm = MessageBox.Show(
            "Test diagnostico: SmartphonExpress salverà lo stato dei servizi di terze parti ATTIVI e, solo se l'eseguibile del servizio ha una firma digitale valida NON Microsoft, imposterà il servizio su Disabilitato per il riavvio successivo.\n\n" +
            "Non verranno modificati servizi Microsoft, driver, Firewall, Defender, RPC core o voci di avvio.\n\n" +
            "Dopo l'operazione riavvia Windows normalmente e prova SFC/DISM. Usa poi RIPRISTINO sulla stessa voce per riportare i servizi allo stato precedente.\n\nContinuare?",
            "SmartphonExpress — Isolamento servizi diagnostico",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
        if (confirm != DialogResult.Yes) return;

        Directory.CreateDirectory(Path.GetDirectoryName(CleanBootSnapshotPath)!);
        string ps = """
$ErrorActionPreference='Continue'
$snapshot=$env:ProgramData+'\SmartphonExpress\thirdparty-service-isolation.tsv'
function Get-ExeFromPathName([string]$p) {
  if([string]::IsNullOrWhiteSpace($p)){ return $null }
  $p=$p.Trim()
  if($p.StartsWith('"')) { $i=$p.IndexOf('"',1); if($i -gt 1){ return $p.Substring(1,$i-1) } }
  $m=[regex]::Match($p,'^(.+?\.exe)(?:\s|$)','IgnoreCase'); if($m.Success){ return $m.Groups[1].Value }
  return ($p -split ' ')[0]
}
$rows=@(); $changed=@()
Get-CimInstance Win32_Service | Where-Object { $_.State -eq 'Running' } | ForEach-Object {
  $svc=$_; $exe=Get-ExeFromPathName $svc.PathName
  if(-not $exe -or -not (Test-Path $exe)){ return }
  $sig=Get-AuthenticodeSignature -FilePath $exe
  $sub=''; if($sig.SignerCertificate){ $sub=$sig.SignerCertificate.Subject }
  if($sig.Status -ne 'Valid' -or $sub -match 'Microsoft'){ return }
  if($svc.Name -in @('RpcSs','DcomLaunch','RpcEptMapper','TrustedInstaller','WinDefend','mpssvc')){ return }
  $rows += [pscustomobject]@{Name=$svc.Name; StartMode=$svc.StartMode; WasRunning='True'}
  try {
    Set-Service -Name $svc.Name -StartupType Disabled -ErrorAction Stop
    $changed += $svc.DisplayName+' ['+$svc.Name+']'
  } catch { Write-Output ('ERRORE '+$svc.Name+': '+$_.Exception.Message) }
}
$rows | ForEach-Object { $_.Name+"`t"+$_.StartMode+"`t"+$_.WasRunning } | Set-Content -LiteralPath $snapshot -Encoding UTF8
'=== SERVIZI ISOLATI ==='
if($changed.Count){ $changed } else { 'Nessun servizio modificato.' }
'Snapshot: '+$snapshot
""";
        string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(ps));
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc, 180000);
        ShowDiagnosticReport("Isolamento servizi non Microsoft — Preparazione", r.Output +
            "\r\n\r\nRIAVVIO RICHIESTO PER IL TEST. Dopo il riavvio prova DISM /RestoreHealth e SFC /scannow. Poi usa RIPRISTINO sulla stessa voce.");
        Log("Isolamento servizi: preparazione completata. Riavviare Windows per il test.");
    }

    void RestoreThirdPartyServiceIsolation()
    {
        if (!File.Exists(CleanBootSnapshotPath))
        {
            MessageBox.Show("Nessuno snapshot di isolamento servizi trovato.", "SmartphonExpress", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        string ps = """
$ErrorActionPreference='Continue'
$snapshot=$env:ProgramData+'\SmartphonExpress\thirdparty-service-isolation.tsv'
function Convert-Mode([string]$m){ switch($m){ 'Auto' {'Automatic'} 'Automatic' {'Automatic'} 'Manual' {'Manual'} 'Disabled' {'Disabled'} default {'Manual'} } }
$restored=@()
Get-Content -LiteralPath $snapshot | ForEach-Object {
  if([string]::IsNullOrWhiteSpace($_)){ return }
  $p=$_ -split "`t"; if($p.Count -lt 3){ return }
  $name=$p[0]; $mode=Convert-Mode $p[1]; $wasRunning=$p[2]
  try {
    Set-Service -Name $name -StartupType $mode -ErrorAction Stop
    if($wasRunning -eq 'True'){ Start-Service -Name $name -ErrorAction SilentlyContinue }
    $restored += $name+' -> '+$mode
  } catch { Write-Output ('ERRORE '+$name+': '+$_.Exception.Message) }
}
'=== SERVIZI RIPRISTINATI ==='
if($restored.Count){ $restored } else { 'Nessun servizio ripristinato.' }
Remove-Item -LiteralPath $snapshot -Force -ErrorAction SilentlyContinue
""";
        string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(ps));
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc, 180000);
        ShowDiagnosticReport("Isolamento servizi non Microsoft — Ripristino", r.Output + "\r\n\r\nRiavvia Windows per completare il ritorno alla configurazione precedente.");
        Log("Isolamento servizi: configurazione precedente ripristinata.");
    }

    void RunDismRestoreHealth()
    {
        Log("DISM: avvio /Online /Cleanup-Image /RestoreHealth. L'operazione può richiedere diversi minuti...");
        var r = RunCaptureWithTimeout("dism.exe", "/Online /Cleanup-Image /RestoreHealth", 60 * 60 * 1000);
        string report = "DISM /ONLINE /CLEANUP-IMAGE /RESTOREHEALTH\r\n" +
                        $"Exit code: {r.ExitCode}\r\n" +
                        $"Timeout: {(r.TimedOut ? "SI" : "NO")}\r\n\r\n" +
                        (string.IsNullOrWhiteSpace(r.Output) ? "Nessun output restituito da DISM." : r.Output);
        if (LooksLikeRpc1726(r.Output, r.ExitCode))
        {
            report += "\r\n\r\n" + BuildRpc1726DiagnosticReport();
            Log("DISM: rilevato errore RPC 1726. I servizi RPC core vengono solo verificati, non modificati.");
        }
        ShowDiagnosticReport("DISM — Riparazione immagine Windows", report);
        if (r.TimedOut) throw new Exception("DISM ha superato il timeout di 60 minuti.");
        if (r.ExitCode != 0)
        {
            if (LooksLikeRpc1726(r.Output, r.ExitCode))
                throw new Exception("DISM: errore RPC 1726. Consulta il report e prova l'isolamento servizi non Microsoft se in Modalità provvisoria funziona.");
            throw new Exception($"DISM terminato con codice {r.ExitCode}. Consulta il report.");
        }
        Log("DISM: RestoreHealth completato correttamente.");
    }

    void ResetWindowsUpdateComponents()
    {
        string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        string ps = $@"
$ErrorActionPreference='Stop'
$services='bits','wuauserv','cryptsvc','msiserver'
foreach($s in $services) {{ Stop-Service $s -Force -ErrorAction SilentlyContinue }}
$sd=Join-Path $env:windir 'SoftwareDistribution'
$cr=Join-Path $env:windir 'System32\\catroot2'
if(Test-Path $sd) {{ Rename-Item $sd ('SoftwareDistribution.old-{stamp}') -ErrorAction Stop }}
if(Test-Path $cr) {{ Rename-Item $cr ('catroot2.old-{stamp}') -ErrorAction Stop }}
foreach($s in $services) {{ Start-Service $s -ErrorAction SilentlyContinue }}
'Windows Update ripristinato. Cache ricreata; le cartelle precedenti sono state conservate con suffisso .old.'";
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"", 120000);
        ShowDiagnosticReport("Windows Update — Ripristino componenti", r.Output);
        if (r.TimedOut) throw new Exception("Reset Windows Update: timeout.");
        if (r.ExitCode != 0) throw new Exception($"Reset Windows Update terminato con codice {r.ExitCode}.");
    }

    void CheckWinReStatus()
    {
        var r = RunCaptureWithTimeout("reagentc.exe", "/info", 30000);
        ShowDiagnosticReport("WinRE — Stato ambiente di ripristino", r.Output);
        if (r.TimedOut) throw new Exception("Controllo WinRE: timeout.");
        if (r.ExitCode != 0) throw new Exception($"REAgentC terminato con codice {r.ExitCode}.");
    }

    void RunDriverDiagnostics()
    {
        string report = BuildDriverDiagnosticReport();
        // Nei batch confluisce nel report diagnostico unico. Se eseguita da sola apre invece
        // la finestra dedicata con gli strumenti di intervento, senza duplicare i popup.
        if (collectDiagnosticReports)
        {
            ShowDiagnosticReport("Periferiche e driver — Diagnostica", report);
            return;
        }
        Log("REPORT: Periferiche e driver — Diagnostica");
        foreach (var line in report.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries)) Log("  " + line.TrimEnd());
        ShowDriverActionsWindow(report);
    }

    string BuildDriverDiagnosticReport()
    {
        string ps = @"
$ErrorActionPreference='SilentlyContinue'
$os = Get-CimInstance Win32_OperatingSystem
'=== PERIFERICHE CON PROBLEMI ==='
'Windows: ' + $os.Caption + ' | Build ' + $os.BuildNumber
$bad = @(Get-CimInstance Win32_PnPEntity | Where-Object { $_.ConfigManagerErrorCode -ne 0 })
if($bad.Count -eq 0) {
  'OK: nessuna periferica con codice problema rilevata.'
} else {
  foreach($d in $bad) {
    '---'
    'NOME=' + $d.Name
    'CODICE=' + $d.ConfigManagerErrorCode
    'PNP_ID=' + $d.PNPDeviceID
    'PRODUTTORE=' + $d.Manufacturer
    'CLASSE=' + $d.PNPClass
  }
}
''
'=== DRIVER / PNPUTIL ==='
$build=[int]$os.BuildNumber
if($build -ge 22000) { pnputil /enum-devices /problem /deviceids /drivers }
else { pnputil /enum-devices /problem /drivers }
''
'=== COMPATIBILITA WINDOWS ==='
$hotfix = @(Get-HotFix | Select-Object -ExpandProperty HotFixID)
$usbAudio10 = @($bad | Where-Object { $_.ConfigManagerErrorCode -eq 10 -and ($_.PNPClass -eq 'MEDIA' -or $_.PNPDeviceID -like 'USB*') })
if($usbAudio10.Count -gt 0 -and (($build -eq 26100 -or $build -eq 26200) -and $hotfix -contains 'KB5124008')) {
  'ATTENZIONE: rilevato Codice 10 compatibile con il problema noto Microsoft di settembre 2026 per alcuni dispositivi USB Audio Class 1.0.'
  'KB5124008 / build 26100.9445 o 26200.9445: il fix OOB KB5129195 risolve solo parte dei sintomi audio USB; verificare Windows Update prima di sostituire driver o hardware.'
}
try {
  $mp=Get-MpComputerStatus -ErrorAction Stop
  'Defender piattaforma: ' + $mp.AMProductVersion
  if([version]$mp.AMProductVersion -lt [version]'4.18.26080.4') {
    'NOTA: piattaforma Defender precedente a 4.18.26080.4; Microsoft ha corretto in questa versione notifiche errate di Defender disattivato.'
  }
} catch {}
";
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"", 45000);
        if (r.TimedOut) return "Diagnostica periferiche interrotta per timeout dopo 45 secondi.\r\n" + r.Output;
        return r.Output + (r.ExitCode == 0 ? "" : $"\r\nPnP/PowerShell exit code: {r.ExitCode}");
    }

    void ShowDriverActionsWindow(string initialReport)
    {
        if (InvokeRequired) { Invoke(() => ShowDriverActionsWindow(initialReport)); return; }
        using var form = new Form
        {
            Text = "SmartphonExpress — Periferiche e driver",
            StartPosition = FormStartPosition.CenterParent,
            Size = new Size(860, 640), MinimumSize = new Size(700, 480),
            BackColor = Color.White, Font = new Font("Segoe UI", 9.5f)
        };
        var box = new TextBox { Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Both, WordWrap=false, Dock=DockStyle.Fill, Font=new Font("Consolas",9.2f), Text=initialReport.Replace("\n", Environment.NewLine) };
        var bar = new FlowLayoutPanel { Dock=DockStyle.Bottom, Height=58, Padding=new Padding(8), WrapContents=false };
        var scan = new Button { Text="Rileva / tenta riparazione", Width=190, Height=34 };
        var folder = new Button { Text="Installa driver da cartella…", Width=190, Height=34 };
        var copy = new Button { Text="Copia", Width=80, Height=34 };
        var save = new Button { Text="Salva TXT", Width=90, Height=34 };
        var close = new Button { Text="Chiudi", Width=80, Height=34 };
        scan.Click += (_,__) =>
        {
            scan.Enabled=false;
            try
            {
                Log("DRIVER: nuovo rilevamento hardware e associazione dei driver gia' disponibili...");
                var rr=RunCaptureWithTimeout("pnputil.exe", "/scan-devices", 60000);
                string refreshed=BuildDriverDiagnosticReport();
                box.Text=("=== TENTATIVO RIPARAZIONE ===\r\n" + rr.Output + "\r\n\r\n" + refreshed).Replace("\n", Environment.NewLine);
                foreach(var line in rr.Output.Split(new[]{"\r\n","\n"},StringSplitOptions.RemoveEmptyEntries)) Log("DRIVER: "+line.Trim());
            }
            finally { scan.Enabled=true; }
        };
        folder.Click += (_,__) =>
        {
            using var dlg=new FolderBrowserDialog { Description="Seleziona la cartella contenente i driver INF del produttore", UseDescriptionForTitle=true };
            if(dlg.ShowDialog(form)!=DialogResult.OK) return;
            var confirm=MessageBox.Show(form, "Verranno aggiunti al Driver Store e installati solo i pacchetti INF che Windows considera applicabili.\n\nContinuare?", "Installa driver da cartella", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(confirm!=DialogResult.Yes) return;
            folder.Enabled=false;
            try
            {
                string pattern=Path.Combine(dlg.SelectedPath,"*.inf");
                Log("DRIVER: installazione INF dalla cartella " + dlg.SelectedPath);
                var rr=RunCaptureWithTimeout("pnputil.exe", $"/add-driver \"{pattern}\" /subdirs /install", 10*60*1000);
                string refreshed=BuildDriverDiagnosticReport();
                box.Text=("=== INSTALLAZIONE DRIVER DA CARTELLA ===\r\n" + rr.Output + "\r\n\r\n" + refreshed).Replace("\n", Environment.NewLine);
                foreach(var line in rr.Output.Split(new[]{"\r\n","\n"},StringSplitOptions.RemoveEmptyEntries)) Log("DRIVER: "+line.Trim());
                if(rr.ExitCode==3010) MessageBox.Show(form,"Driver installati. Windows richiede un riavvio.","Driver",MessageBoxButtons.OK,MessageBoxIcon.Information);
                else if(rr.ExitCode!=0) MessageBox.Show(form,$"PnPUtil ha restituito il codice {rr.ExitCode}. Consulta il report.","Driver",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            finally { folder.Enabled=true; }
        };
        copy.Click += (_,__) => { if(!string.IsNullOrEmpty(box.Text)) Clipboard.SetText(box.Text); };
        save.Click += (_,__) =>
        {
            using var dlg = new SaveFileDialog { Filter="File di testo (*.txt)|*.txt", FileName="SmartphonExpress-Driver-Diagnostics.txt" };
            if(dlg.ShowDialog(form)==DialogResult.OK) File.WriteAllText(dlg.FileName, box.Text, Encoding.UTF8);
        };
        close.Click += (_,__) => form.Close();
        bar.Controls.Add(scan); bar.Controls.Add(folder); bar.Controls.Add(copy); bar.Controls.Add(save); bar.Controls.Add(close);
        form.Controls.Add(box); form.Controls.Add(bar);
        form.ShowDialog(this);
    }

    void RunBatteryHealthCheck()
    {
        // Legge i dati esposti dal driver batteria tramite le classi WMI native di Windows.
        // Nessuna dipendenza da software esterno e nessuna modifica alla configurazione del PC.
        string ps = @"
$ErrorActionPreference='SilentlyContinue'

function FmtMWh($v) {
  if($null -eq $v -or [double]$v -le 0) { return 'Non disponibile' }
  return ('{0:N0} mWh' -f [double]$v)
}
function FmtMv($v) {
  if($null -eq $v -or [double]$v -le 0) { return 'Non disponibile' }
  return ('{0:N0} mV' -f [double]$v)
}
function Prop($o,$name) {
  if($null -eq $o) { return $null }
  $p=$o.PSObject.Properties[$name]
  if($null -ne $p) { return $p.Value }
  return $null
}

$b = Get-CimInstance Win32_Battery | Select-Object -First 1
$static = Get-CimInstance -Namespace root/wmi -ClassName BatteryStaticData | Select-Object -First 1
$fullObj = Get-CimInstance -Namespace root/wmi -ClassName BatteryFullChargedCapacity | Select-Object -First 1
$statusObj = Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select-Object -First 1
$cycleObj = Get-CimInstance -Namespace root/wmi -ClassName BatteryCycleCount | Select-Object -First 1

if(-not $b -and -not $static -and -not $statusObj) {
  'BATTERIA: non presente o dati non esposti dal driver'
  exit 0
}

$design = Prop $static 'DesignedCapacity'
# Alcuni driver espongono DesignedCapacity via il vecchio provider WMI ma non tramite CIM.
# BatteryInfoView interroga direttamente il battery miniport; questo fallback copre molti di quei casi.
if($null -eq $design -or [double]$design -le 0) {
  try {
    $staticWmi = Get-WmiObject -Namespace root\wmi -Class BatteryStaticData -ErrorAction SilentlyContinue | Select-Object -First 1
    $designWmi = Prop $staticWmi 'DesignedCapacity'
    if($null -ne $designWmi -and [double]$designWmi -gt 0) { $design = $designWmi }
  } catch {}
}
$full = Prop $fullObj 'FullChargedCapacity'

# Ultimo fallback: il report batteria di Windows usa lo stesso stack batteria e spesso
# contiene la Design Capacity anche quando root/wmi la restituisce a zero.
if($null -eq $design -or [double]$design -le 0) {
  try {
    $br = Join-Path $env:TEMP ('spex-battery-' + [guid]::NewGuid().ToString('N') + '.html')
    & powercfg.exe /batteryreport /output $br | Out-Null
    if(Test-Path $br) {
      $html = Get-Content -LiteralPath $br -Raw -ErrorAction SilentlyContinue
      # Cerca la riga/cella che contiene DESIGN CAPACITY / capacità di progetto e il primo valore mWh successivo.
      $m = [regex]::Match($html, '(?is)(DESIGN\s*CAPACITY|CAPACIT.{0,8}(DI\s*)?(PROGETTO|FABBRICA)).{0,800}?([0-9][0-9\.\,\s]*)\s*mWh')
      if($m.Success) {
        $raw = $m.Groups[4].Value -replace '[^0-9]',''
        if($raw) { $design = [double]$raw }
      }
      Remove-Item -LiteralPath $br -Force -ErrorAction SilentlyContinue
    }
  } catch {}
}
$remaining = Prop $statusObj 'RemainingCapacity'
$voltage = Prop $statusObj 'Voltage'
$rate = Prop $statusObj 'Rate'
$chargeRate = Prop $statusObj 'ChargeRate'
$dischargeRate = Prop $statusObj 'DischargeRate'
$cycles = Prop $cycleObj 'CycleCount'

$name = Prop $static 'DeviceName'
if([string]::IsNullOrWhiteSpace([string]$name)) { $name = Prop $b 'Name' }
$maker = Prop $static 'ManufactureName'
if([string]::IsNullOrWhiteSpace([string]$maker)) { $maker = Prop $b 'Manufacturer' }
$serial = Prop $static 'SerialNumber'

$chemRaw = Prop $static 'Chemistry'
if([string]::IsNullOrWhiteSpace([string]$chemRaw)) { $chemRaw = Prop $b 'Chemistry' }
$chem = switch([int]$chemRaw) {
  3 {'Piombo-acido'} 4 {'NiCd'} 5 {'NiMH'} 6 {'Litio'} 7 {'Zinco-aria'} 8 {'Litio-polimero'} default { if($chemRaw){[string]$chemRaw}else{'Non disponibile'} }
}

$chargePct = Prop $b 'EstimatedChargeRemaining'
if(($null -eq $chargePct -or [double]$chargePct -lt 0) -and $remaining -and $full) {
  $chargePct=[math]::Round(([double]$remaining/[double]$full)*100,1)
}

'=== BATTERIA ==='
if($name)   { 'Modello: ' + $name }
if($maker)  { 'Produttore: ' + $maker }
if($serial) { 'Seriale: ' + $serial }
'Chimica: ' + $chem
''
'=== CAPACITA E SALUTE ==='
if($null -ne $chargePct) { 'Carica attuale: ' + $chargePct + '%' }
'Capacita attuale: ' + (FmtMWh $remaining)
'Capacita di fabbrica: ' + (FmtMWh $design)
'Capacita massima attuale: ' + (FmtMWh $full)

if($design -and $full -and [double]$design -gt 0) {
  $health=[math]::Round(([double]$full/[double]$design)*100,1)
  if($health -gt 100) { $health=100 }
  $wear=[math]::Round(100-$health,1)
  'SALUTE BATTERIA: ' + $health + '%'
  'Usura stimata: ' + $wear + '%'
  if($health -ge 90){$rating='Ottima'} elseif($health -ge 80){$rating='Buona'} elseif($health -ge 65){$rating='Usurata'} else {$rating='Molto usurata / da valutare'}
  'Valutazione: ' + $rating
} else {
  'SALUTE BATTERIA: non calcolabile (capacita non esposte dal firmware/driver)'
}

''
'=== UTILIZZO ==='
if($null -ne $cycles) { 'Cicli di carica/scarica: ' + $cycles } else { 'Cicli di carica/scarica: Non disponibile' }
'Voltaggio: ' + (FmtMv $voltage)

$online = Prop $statusObj 'PowerOnline'
$charging = Prop $statusObj 'Charging'
$discharging = Prop $statusObj 'Discharging'
if($charging -eq $true) {$powerState='In carica'} elseif($discharging -eq $true) {$powerState='In uso / scarica'} elseif($online -eq $true) {$powerState='Alimentazione AC'} else {$powerState='Non determinato'}
'Stato alimentazione: ' + $powerState

if($null -ne $rate) {
  if([double]$rate -gt 0) {
    'Potenza istantanea: +' + ('{0:N0} mW' -f [math]::Abs([double]$rate)) + ' (carica)'
  } elseif([double]$rate -lt 0) {
    'Potenza istantanea: -' + ('{0:N0} mW' -f [math]::Abs([double]$rate)) + ' (scarica)'
  } else {
    'Potenza istantanea: 0 mW'
  }
} elseif($charging -eq $true -and $chargeRate) {
  'Potenza di carica: ' + ('{0:N0} mW' -f [double]$chargeRate)
} elseif($discharging -eq $true -and $dischargeRate) {
  'Potenza di scarica: ' + ('{0:N0} mW' -f [double]$dischargeRate)
} else {
  'Potenza istantanea: Non disponibile'
}

''
'Nota: alcuni valori dipendono da cio che firmware e driver della batteria espongono a Windows.'
";
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"", 30000);
        ShowDiagnosticReport("Batteria — Diagnostica avanzata", r.Output);
        if (r.TimedOut) throw new Exception("Diagnostica batteria: timeout.");
        if (r.ExitCode != 0) throw new Exception($"Diagnostica batteria terminata con codice {r.ExitCode}.");
    }

    static void EnableSafeStorageSense()
    {
        const string p = @"SOFTWARE\Policies\Microsoft\Windows\StorageSense";

        // Policy ufficiali Windows 10/11 Pro+.
        SetLM(p, "AllowStorageSenseGlobal", 1);
        SetLM(p, "AllowStorageSenseTemporaryFilesCleanup", 1);
        SetLM(p, "ConfigStorageSenseGlobalCadence", 7); // settimanale

        // Sicurezza: NON eliminare contenuti personali da Download o Cestino.
        SetLM(p, "ConfigStorageSenseDownloadsCleanupThreshold", 0);
        SetLM(p, "ConfigStorageSenseRecycleBinCleanupThreshold", 0);
    }

    static void RestoreStorageSense()
    {
        const string p = @"SOFTWARE\Policies\Microsoft\Windows\StorageSense";

        DelLM(p, "AllowStorageSenseGlobal");
        DelLM(p, "AllowStorageSenseTemporaryFilesCleanup");
        DelLM(p, "ConfigStorageSenseGlobalCadence");
        DelLM(p, "ConfigStorageSenseDownloadsCleanupThreshold");
        DelLM(p, "ConfigStorageSenseRecycleBinCleanupThreshold");
    }

    static void DeleteTemp()
    {
        foreach(var p in new[]{Path.GetTempPath(), Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"Temp")})
            try { foreach(var f in Directory.EnumerateFiles(p,"*",SearchOption.TopDirectoryOnly)) try{File.Delete(f);}catch{} } catch {}
    }
    static void DisableHibernate()
    {
        SetLM(@"System\CurrentControlSet\Control\Session Manager\Power","HibernateEnabled",0);
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FlyoutMenuSettings","ShowHibernateOption",0);
        Run("powercfg.exe","/hibernate off");
    }
    static void DisableBackgroundApps()
    {
        // Policy ufficiale: 2 = Force deny.
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy","LetAppsRunInBackground",2);

        // Mantiene anche il vecchio flag utente per compatibilità con build meno recenti.
        SetCU(@"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications","GlobalUserDisabled",1);
    }

    static void RestoreBackgroundApps()
    {
        DelLM(@"SOFTWARE\Policies\Microsoft\Windows\AppPrivacy","LetAppsRunInBackground");
        DelCU(@"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications","GlobalUserDisabled");
    }

    static void EdgeDebloat()
    {
        SetLM(@"SOFTWARE\Policies\Microsoft\EdgeUpdate","CreateDesktopShortcutDefault",0);
        string p=@"SOFTWARE\Policies\Microsoft\Edge";
        SetLM(p,"PersonalizationReportingEnabled",0); SetLM(p,"ShowRecommendationsEnabled",0);
        SetLM(p,"HideFirstRunExperience",1); SetLM(p,"UserFeedbackAllowed",0); SetLM(p,"ConfigureDoNotTrack",1);
        SetLM(p,"AlternateErrorPagesEnabled",0); SetLM(p,"EdgeCollectionsEnabled",0); SetLM(p,"EdgeShoppingAssistantEnabled",0);
        SetLM(p,"MicrosoftEdgeInsiderPromotionEnabled",0); SetLM(p,"ShowMicrosoftRewards",0); SetLM(p,"WebWidgetAllowed",0);
        SetLM(p,"DiagnosticData",0); SetLM(p,"EdgeAssetDeliveryServiceEnabled",0); SetLM(p,"WalletDonationEnabled",0);
        SetLM(p,"DefaultBrowserSettingsCampaignEnabled",0);
        SetLM(p+@"\ExtensionInstallBlocklist","1","ofefcgjbeghpigppfmkologfjadafddi");
    }
    static void RdpWarning()
    {
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services\Client","RedirectionWarningDialogVersion",1);
        SetCU(@"SOFTWARE\Microsoft\Terminal Server Client","RdpLaunchConsentAccepted",1);
    }
    static void ClassicContextMenu()
    {
        using var k=Registry.CurrentUser.CreateSubKey(@"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32",true)!;
        k.SetValue("","",RegistryValueKind.String);
    }
    static void WindowsAI()
    {
        SetLM(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer","SettingsPageVisibility","hide:aicomponents");
        SetLM(@"SOFTWARE\Policies\WindowsNotepad","DisableAIFeatures",1);

        // Policy moderna Windows AI / Recall.
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\WindowsAI","DisableAIDataAnalysis",1);
        SetCU(@"SOFTWARE\Policies\Microsoft\Windows\WindowsAI","DisableAIDataAnalysis",1);

        // Compatibilità con build meno recenti: questa policy Copilot è deprecata,
        // ma resta utile come fallback dove ancora interpretata.
        SetLM(@"SOFTWARE\Policies\Microsoft\Windows\WindowsAI","TurnOffWindowsCopilot",1);
        SetCU(@"Software\Policies\Microsoft\Windows\WindowsCopilot","TurnOffWindowsCopilot",1);
    }
    static void RemoveWidgets()
    {
        // Policy ufficiale "Allow widgets" = 0.
        SetLM(@"SOFTWARE\Policies\Microsoft\Dsh","AllowNewsAndInterests",0);

        // Rimuove il Windows Web Experience Pack per l'utente corrente.
        PS("Get-AppxPackage *WebExperience* | Remove-AppxPackage -ErrorAction SilentlyContinue");
    }
    static void RemoveAppx()
    {
        string[] pkgs = {
            "Microsoft.GetHelp","Microsoft.WindowsFeedbackHub","Microsoft.GamingApp","Microsoft.XboxGamingOverlay",
            "Microsoft.XboxIdentityProvider","Microsoft.XboxSpeechToTextOverlay","Microsoft.Xbox.TCUI",
            "Microsoft.BingSearch","Microsoft.BingNews","Microsoft.StartExperiencesApp","Microsoft.BingWeather"
        };
        foreach(var x in pkgs)
        {
            PS($"Get-AppxPackage -AllUsers '{x}' | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue; " +
               $"Get-AppxProvisionedPackage -Online | Where-Object {{$_.DisplayName -like '{x}'}} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue");
        }
    }
    static void InstallChrome() =>
        DownloadAndInstallMsi(
            "Google Chrome",
            "https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi",
            "googlechromestandaloneenterprise64.msi");

    static void InstallFirefox() =>
        DownloadAndInstall(
            "Mozilla Firefox",
            "https://download.mozilla.org/?product=firefox-latest&os=win64&lang=it",
            "firefox_installer.exe",
            "-ms");

    static void Install7Zip() =>
        DownloadAndInstall(
            "7-Zip",
            "https://www.7-zip.org/a/7z2603-x64.exe",
            "7zip_installer.exe",
            "/S");

    static void InstallVlc() =>
        DownloadAndInstall(
            "VLC Media Player",
            "https://mirror.solnet.ch/videolan/vlc/3.0.23/win64/vlc-3.0.23-win64.exe",
            "vlc_installer.exe",
            "/S");

    static void DownloadAndInstallMsi(string displayName, string url, string fileName)
    {
        string dir = Path.Combine(Path.GetTempPath(), "SmartphonExpress-Apps");
        Directory.CreateDirectory(dir);
        string installer = Path.Combine(dir, fileName);

        try
        {
            using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = true });
            http.Timeout = TimeSpan.FromMinutes(10);
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpressWindowsTool/3.0");
            using var response = http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            using (var input = response.Content.ReadAsStream())
            using (var output = new FileStream(installer, FileMode.Create, FileAccess.Write, FileShare.None))
                input.CopyTo(output);

            if (!File.Exists(installer) || new FileInfo(installer).Length < 1_000_000)
                throw new Exception("Il file MSI scaricato non sembra valido.");

            using var proc = Process.Start(new ProcessStartInfo(
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "msiexec.exe"),
                $"/i \"{installer}\" /qn /norestart")
            {
                UseShellExecute = true,
                WorkingDirectory = dir
            });
            if (proc is null) throw new Exception("Impossibile avviare Windows Installer.");
            proc.WaitForExit();

            if (proc.ExitCode != 0 && proc.ExitCode != 3010 && proc.ExitCode != 1641)
                throw new Exception($"Windows Installer terminato con codice {proc.ExitCode}.");
        }
        catch (Exception ex)
        {
            throw new Exception($"{displayName}: {ex.Message}", ex);
        }
        finally
        {
            try { if (File.Exists(installer)) File.Delete(installer); } catch { }
        }
    }

    static void DownloadAndInstall(string displayName, string url, string fileName, string arguments)
    {
        string dir = Path.Combine(Path.GetTempPath(), "SmartphonExpress-Apps");
        Directory.CreateDirectory(dir);
        string installer = Path.Combine(dir, fileName);

        try
        {
            using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = true });
            http.Timeout = TimeSpan.FromMinutes(10);
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpressWindowsTool/3.0");
            using var response = http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            using (var input = response.Content.ReadAsStream())
            using (var output = new FileStream(installer, FileMode.Create, FileAccess.Write, FileShare.None))
                input.CopyTo(output);

            if (!File.Exists(installer) || new FileInfo(installer).Length < 100_000)
                throw new Exception("Il file scaricato non sembra essere un installer valido.");

            using var proc = Process.Start(new ProcessStartInfo(installer, arguments)
            {
                UseShellExecute = true,
                WorkingDirectory = dir
            });
            if (proc is null) throw new Exception("Impossibile avviare l'installer.");
            proc.WaitForExit();

            // 0 = success; some installers use 3010 for success + reboot required.
            if (proc.ExitCode != 0 && proc.ExitCode != 3010)
                throw new Exception($"Installer terminato con codice {proc.ExitCode}.");
        }
        catch (Exception ex)
        {
            throw new Exception($"{displayName}: {ex.Message}", ex);
        }
        finally
        {
            try { if (File.Exists(installer)) File.Delete(installer); } catch { }
        }
    }


    void DisableControlledFolderAccess()
    {
        var result = RunCapture(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"Set-MpPreference -EnableControlledFolderAccess Disabled; $v=(Get-MpPreference).EnableControlledFolderAccess; Write-Output ('ControlledFolderAccess=' + $v)\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
            Log("DEFENDER CFA: " + result.Output.Replace("\r", " ").Replace("\n", " ").Trim());

        if (result.ExitCode != 0)
            throw new Exception("Impossibile disattivare Accesso controllato alle cartelle. " + result.Output);

        Log("DEFENDER CFA: Accesso controllato alle cartelle disattivato.");
    }

    void EnableControlledFolderAccess()
    {
        var result = RunCapture(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"Set-MpPreference -EnableControlledFolderAccess Enabled; $v=(Get-MpPreference).EnableControlledFolderAccess; Write-Output ('ControlledFolderAccess=' + $v)\"");

        if (!string.IsNullOrWhiteSpace(result.Output))
            Log("DEFENDER CFA: " + result.Output.Replace("\r", " ").Replace("\n", " ").Trim());

        if (result.ExitCode != 0)
            throw new Exception("Impossibile riattivare Accesso controllato alle cartelle. " + result.Output);

        Log("DEFENDER CFA: Accesso controllato alle cartelle riattivato.");
    }

    void DisableNotepadSessionRestore()
    {
        string packageRoot = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            @"Packages\Microsoft.WindowsNotepad_8wekyb3d8bbwe");

        string settingsFile = Path.Combine(packageRoot, "Settings", "settings.dat");
        string tabState = Path.Combine(packageRoot, "LocalState", "TabState");
        string windowState = Path.Combine(packageRoot, "LocalState", "WindowState");

        Log("BLOCCO NOTE: imposto avvio in nuova sessione e apertura file in nuova finestra.");

        // settings.dat viene bloccato da Notepad mentre l'app è aperta.
        // Proviamo una chiusura normale; NON forziamo mai il processo per non perdere note non salvate.
        var running = Process.GetProcessesByName("Notepad");
        if (running.Length > 0)
        {
            Log("BLOCCO NOTE: Blocco note è aperto; provo a chiuderlo normalmente.");

            foreach (var p in running)
            {
                try { p.CloseMainWindow(); } catch { }
            }

            var until = DateTime.UtcNow.AddSeconds(5);
            while (DateTime.UtcNow < until &&
                   Process.GetProcessesByName("Notepad").Length > 0)
            {
                Thread.Sleep(250);
            }

            if (Process.GetProcessesByName("Notepad").Length > 0)
                throw new Exception(
                    "Blocco note è ancora aperto. Salva/chiudi eventuali note e riesegui questa voce; " +
                    "il tool non forza la chiusura per evitare perdita di dati.");
        }

        // Su un profilo che non ha mai aperto Notepad, inizializziamo l'app una volta
        // così Windows crea settings.dat.
        if (!File.Exists(settingsFile))
        {
            Log("BLOCCO NOTE: settings.dat non presente; inizializzo Blocco note.");

            using var p = Process.Start(new ProcessStartInfo
            {
                FileName = "notepad.exe",
                UseShellExecute = true
            });

            if (p is null)
                throw new Exception("Impossibile inizializzare Blocco note.");

            Thread.Sleep(1800);

            try { p.CloseMainWindow(); } catch { }

            try
            {
                if (!p.WaitForExit(5000))
                    throw new Exception("Chiudi Blocco note e riesegui la voce per completare la configurazione.");
            }
            catch (InvalidOperationException) { }

            // Piccolo margine per il flush delle impostazioni.
            Thread.Sleep(500);
        }

        if (!File.Exists(settingsFile))
            throw new Exception("settings.dat di Blocco note non trovato.");

        IntPtr appKey = IntPtr.Zero;

        try
        {
            int rc = RegLoadAppKey(
                settingsFile,
                out appKey,
                KEY_QUERY_VALUE | KEY_SET_VALUE,
                REG_PROCESS_APPKEY,
                0);

            if (rc != ERROR_SUCCESS || appKey == IntPtr.Zero)
                throw new Exception($"Impossibile aprire settings.dat (RegLoadAppKey={rc}).");

            // GhostFile:
            //   0 = Start new session / Open in a new window
            //   1 = Continue previous session
            WriteNotepadBoolSetting(appKey, "GhostFile", false);

            // OpenFile:
            //   0 = New Tab
            //   1 = New Window
            WriteNotepadUInt32Setting(appKey, "OpenFile", 1);

            Log("BLOCCO NOTE: 'Quando si avvia' = nuova sessione / scarta sessione precedente.");
            Log("BLOCCO NOTE: apertura file = nuova finestra, non nuova scheda.");
        }
        finally
        {
            if (appKey != IntPtr.Zero)
                RegCloseKey(appKey);
        }

        // Rimuoviamo il vecchio stato SOLO dopo aver configurato il comportamento futuro.
        // A questo punto Notepad è chiuso, quindi non perdiamo contenuti attualmente in modifica.
        try
        {
            if (Directory.Exists(tabState))
            {
                Directory.Delete(tabState, true);
                Directory.CreateDirectory(tabState);
                Log("BLOCCO NOTE: vecchio TabState eliminato.");
            }

            if (Directory.Exists(windowState))
            {
                Directory.Delete(windowState, true);
                Directory.CreateDirectory(windowState);
                Log("BLOCCO NOTE: vecchio WindowState eliminato.");
            }
        }
        catch (Exception ex)
        {
            Log("BLOCCO NOTE: impostazione salvata, ma pulizia stato precedente non completa: " + ex.Message);
        }

        Log("BLOCCO NOTE: configurazione completata.");
    }

    static void WriteNotepadBoolSetting(IntPtr appKey, string name, bool value)
    {
        byte[] data = new byte[9];
        data[0] = value ? (byte)1 : (byte)0;

        byte[] timestamp = BitConverter.GetBytes(DateTime.UtcNow.ToFileTimeUtc());
        Buffer.BlockCopy(timestamp, 0, data, 1, 8);

        int rc = RegSetValueEx(
            appKey,
            name,
            0,
            NOTEPAD_SETTING_BOOL,
            data,
            data.Length);

        if (rc != ERROR_SUCCESS)
            throw new Exception($"Errore scrittura impostazione Blocco note '{name}' ({rc}).");
    }

    static void WriteNotepadUInt32Setting(IntPtr appKey, string name, uint value)
    {
        byte[] data = new byte[12];

        byte[] number = BitConverter.GetBytes(value);
        Buffer.BlockCopy(number, 0, data, 0, 4);

        byte[] timestamp = BitConverter.GetBytes(DateTime.UtcNow.ToFileTimeUtc());
        Buffer.BlockCopy(timestamp, 0, data, 4, 8);

        int rc = RegSetValueEx(
            appKey,
            name,
            0,
            NOTEPAD_SETTING_UINT32,
            data,
            data.Length);

        if (rc != ERROR_SUCCESS)
            throw new Exception($"Errore scrittura impostazione Blocco note '{name}' ({rc}).");
    }

    void ConfigureStartOfficePins()
    {
        int build = Environment.OSVersion.Version.Build;
        int ubr = 0;
        try
        {
            using var cv = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
            if (cv?.GetValue("UBR") is int u) ubr = u;
        }
        catch { }

        Log($"START: Windows build completa = {build}.{ubr}");

        var commonPrograms = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu), "Programs");
        var userPrograms = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs");

        string[] wanted =
        {
            "Word", "Excel", "PowerPoint", "Outlook", "OneNote", "Access", "Publisher",
            "Google Chrome", "Firefox"
        };

        var found = new List<string>();
        foreach (var app in wanted)
        {
            string? chosen = null;
            foreach (var root in new[] { commonPrograms, userPrograms })
            {
                if (!Directory.Exists(root)) continue;
                try
                {
                    var links = Directory.EnumerateFiles(root, "*.lnk", SearchOption.AllDirectories).ToList();

                    bool IsPrivateShortcut(string n) =>
                        n.Contains("anonima", StringComparison.OrdinalIgnoreCase) ||
                        n.Contains("privata", StringComparison.OrdinalIgnoreCase) ||
                        n.Contains("private", StringComparison.OrdinalIgnoreCase) ||
                        n.Contains("incognito", StringComparison.OrdinalIgnoreCase);

                    chosen = links.FirstOrDefault(x =>
                    {
                        var n = Path.GetFileNameWithoutExtension(x);
                        if (IsPrivateShortcut(n)) return false;

                        if (app == "Firefox")
                            return n.Equals("Firefox", StringComparison.OrdinalIgnoreCase)
                                || n.Equals("Mozilla Firefox", StringComparison.OrdinalIgnoreCase)
                                || (n.Contains("Firefox", StringComparison.OrdinalIgnoreCase) && !IsPrivateShortcut(n));

                        if (app == "Google Chrome")
                            return n.Equals("Google Chrome", StringComparison.OrdinalIgnoreCase)
                                || (n.Contains("Chrome", StringComparison.OrdinalIgnoreCase) && !IsPrivateShortcut(n));

                        return n.Equals(app, StringComparison.OrdinalIgnoreCase)
                            || n.StartsWith(app + " ", StringComparison.OrdinalIgnoreCase)
                            || n.StartsWith("Microsoft " + app, StringComparison.OrdinalIgnoreCase);
                    });
                }
                catch { }

                if (chosen != null) break;
            }

            if (chosen != null)
            {
                found.Add(chosen);
                Log($"START: trovato {app} -> {chosen}");
            }
            else
            {
                Log($"START: {app} non trovato, salto.");
            }
        }

        var pinned = new List<Dictionary<string, string>>
        {
            new()
            {
                ["packagedAppId"] =
                    "windows.immersivecontrolpanel_cw5n1h2txyewy!microsoft.windows.immersivecontrolpanel"
            }
        };

        foreach (var link in found)
            pinned.Add(new Dictionary<string, string> { ["desktopAppLink"] = link });

        var payload = new Dictionary<string, object>
        {
            ["applyOnce"] = true,
            ["pinnedList"] = pinned
        };

        var json = System.Text.Json.JsonSerializer.Serialize(payload);
        var baseDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
            "SmartphonExpress", "StartPins");
        Directory.CreateDirectory(baseDir);
        var jsonPath = Path.Combine(baseDir, "LayoutModification.json");
        File.WriteAllText(jsonPath, json, new System.Text.UTF8Encoding(false));
        Log($"START: JSON pin -> {jsonPath}");

        // Windows 11 24H2 con KB5062660 o successivo: usa la GPO ConfigureStartPins.
        // KB5062660 corrisponde alla build 26100.4770.
        bool gpoSupported = build > 26100 || (build == 26100 && ubr >= 4770);

        if (gpoSupported)
        {
            using var key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
                @"Software\Policies\Microsoft\Windows\Explorer", true);
            if (key == null)
                throw new Exception("Impossibile aprire la chiave policy Explorer.");

            key.SetValue(
                "ConfigureStartPins",
                jsonPath,
                Microsoft.Win32.RegistryValueKind.String);

            key.DeleteValue("ConfigureStartPinsJSON", false);

            Log($"START: ConfigureStartPins applicabile su {build}.{ubr}; REG_SZ scritto.");
            var gp = RunCapture("gpupdate.exe", "/target:user /force");
            Log($"START: gpupdate exit code = {gp.ExitCode}");
        }
        else
        {
            Log($"START: ConfigureStartPins GPO non disponibile su {build}.{ubr} (serve almeno 26100.4770).");
            Log("START: attivo comunque StartPinAppsWhenInstalled PRIMA delle installazioni.");
        }

        // Fallback per PC appena preparati: pin delle app quando vengono installate.
        string[] appIds =
        {
            "Microsoft.Office.WINWORD.EXE.15",
            "Microsoft.Office.EXCEL.EXE.15",
            "Microsoft.Office.POWERPNT.EXE.15",
            "Microsoft.Office.OUTLOOK.EXE.15",
            "Microsoft.Office.ONENOTE.EXE.15",
            "Microsoft.Office.MSACCESS.EXE.15",
            "Microsoft.Office.MSPUB.EXE.15",
            "Chrome",
            "Firefox"
        };

        using (var root = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
            @"Software\Policies\Microsoft\Windows\Explorer", true))
        {
            root?.SetValue("StartPinAppsWhenInstalled", 1, Microsoft.Win32.RegistryValueKind.DWord);
        }

        using (var list = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(
            @"Software\Policies\Microsoft\Windows\Explorer\StartPinAppsWhenInstalled", true))
        {
            if (list != null)
            {
                int n = 1;
                foreach (var appId in appIds)
                    list.SetValue((n++).ToString(), appId, Microsoft.Win32.RegistryValueKind.String);
            }
        }

        // Impostazioni: usa il WMI Bridge come SYSTEM.
        // Se l'istanza non esiste, la crea invece di fallire.
        var psPath = Path.Combine(baseDir, "Enable-Settings-Pin.ps1");
        var resultPath = Path.Combine(baseDir, "SettingsPinResult.txt");

        string ps = """
$ErrorActionPreference = 'Stop'
$ns = 'root\cimv2\mdm\dmmap'
$result = '__RESULTPATH__'

try {
    $x = Get-CimInstance -Namespace $ns -ClassName MDM_Policy_Config01_Start02 -Filter "InstanceID='Start'" -ErrorAction SilentlyContinue

    if ($null -eq $x) {
        $props = @{
            ParentID = './Vendor/MSFT/Policy/Config'
            InstanceID = 'Start'
            AllowPinnedFolderSettings = 1
        }

        $x = New-CimInstance -Namespace $ns -ClassName MDM_Policy_Config01_Start02 -Property $props -ErrorAction Stop
        "CREATED InstanceID=Start" | Set-Content -Path $result -Encoding UTF8
    }
    else {
        $x.AllowPinnedFolderSettings = 1
        Set-CimInstance -CimInstance $x -ErrorAction Stop | Out-Null
        "UPDATED InstanceID=Start" | Set-Content -Path $result -Encoding UTF8
    }

    $verify = Get-CimInstance -Namespace $ns -ClassName MDM_Policy_Result01_Start02 -Filter "InstanceID='Start'" -ErrorAction SilentlyContinue
    if ($verify) {
        ("OK AllowPinnedFolderSettings=" + $verify.AllowPinnedFolderSettings) | Add-Content -Path $result -Encoding UTF8
    }
    else {
        "OK Config written; Result instance not yet available" | Add-Content -Path $result -Encoding UTF8
    }
}
catch {
    ("ERROR " + $_.Exception.Message) | Set-Content -Path $result -Encoding UTF8
    exit 1
}
""";
        ps = ps.Replace("__RESULTPATH__", resultPath.Replace("'", "''"));

        File.WriteAllText(psPath, ps, new System.Text.UTF8Encoding(false));
        try { if (File.Exists(resultPath)) File.Delete(resultPath); } catch { }

        string taskName = "SmartphonExpress_StartSettingsPin_" + Guid.NewGuid().ToString("N");
        string tr = $"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"{psPath}\"";

        var create = RunCapture(
            "schtasks.exe",
            $"/Create /TN \"{taskName}\" /TR \"{tr.Replace("\"", "\\\"")}\" /SC ONCE /ST 23:59 /RU SYSTEM /RL HIGHEST /F");

        if (create.ExitCode == 0)
        {
            var run = RunCapture("schtasks.exe", $"/Run /TN \"{taskName}\"");
            Log($"START: task SYSTEM Impostazioni avviato, exit code={run.ExitCode}");

            for (int i = 0; i < 40 && !File.Exists(resultPath); i++)
                System.Threading.Thread.Sleep(250);

            if (File.Exists(resultPath))
            {
                foreach (var line in File.ReadAllLines(resultPath))
                    Log("START: " + line);
            }
            else
            {
                Log("START: nessun risultato WMI ricevuto entro il timeout.");
            }

            RunCapture("schtasks.exe", $"/Delete /TN \"{taskName}\" /F");
        }
        else
        {
            Log("START: impossibile creare task SYSTEM per Impostazioni.");
            if (!string.IsNullOrWhiteSpace(create.Output))
                Log("START: " + create.Output.Replace("\r", " ").Replace("\n", " "));
        }

        if (gpoSupported)
        {
            Log("START: layout completo predisposto. DISCONNETTI e accedi di nuovo.");
            Log("START: con applyOnce=true potrai modificare i pin dopo la prima applicazione.");
        }
        else
        {
            Log("START: su questa build i pin delle app dipendono da StartPinAppsWhenInstalled.");
            Log("START: ora la voce START viene eseguita prima di Chrome/Firefox/Office quando selezioni tutto.");
            Log("START: per applicazione retroattiva dei pin già installati aggiorna Windows almeno a 26100.4770.");
        }
    }

    static void RemoveOldStartPinRegistryPolicy()
    {
        foreach (var hive in new[] { Microsoft.Win32.Registry.CurrentUser, Microsoft.Win32.Registry.LocalMachine })
        {
            try
            {
                using var key = hive.OpenSubKey(
                    @"Software\Policies\Microsoft\Windows\Explorer", writable: true);
                if (key == null) continue;
                key.DeleteValue("ConfigureStartPins", false);
                key.DeleteValue("ConfigureStartPinsJSON", false);
            }
            catch { }
        }
    }

    static string? FindExecutable(string name)
    {
        try
        {
            var path = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (var dir in path.Split(';', StringSplitOptions.RemoveEmptyEntries))
            {
                try
                {
                    var candidate = Path.Combine(dir.Trim(), name);
                    if (File.Exists(candidate)) return candidate;
                }
                catch { }
            }
        }
        catch { }
        return null;
    }

    static string? FindIcdExe()
    {
        string[] known =
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                @"Windows Kits\10\Assessment and Deployment Kit\Imaging and Configuration Designer\x86\ICD.exe"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                @"Windows Kits\10\Assessment and Deployment Kit\Imaging and Configuration Designer\amd64\ICD.exe")
        };

        foreach (var p in known)
            if (File.Exists(p)) return p;

        var fromPath = FindExecutable("ICD.exe");
        if (fromPath != null) return fromPath;

        try
        {
            var q = RunCapture(
                "powershell.exe",
                "-NoProfile -Command \"$p=Get-AppxPackage -Name Microsoft.WindowsConfigurationDesigner | Select-Object -First 1 -ExpandProperty InstallLocation; if($p){Write-Output $p}\"");
            var installLocation = q.Output.Trim();
            if (Directory.Exists(installLocation))
            {
                var found = Directory.EnumerateFiles(
                    installLocation, "ICD.exe", SearchOption.AllDirectories).FirstOrDefault();
                if (found != null) return found;
            }
        }
        catch { }

        return null;
    }

    static (int ExitCode, string Output) RunCapture(string file, string args)
    {
        var r = RunCaptureWithTimeout(file, args, Timeout.Infinite);
        return (r.ExitCode, r.Output);
    }

    static (int ExitCode, string Output, bool TimedOut) RunCaptureWithTimeout(
        string file,
        string args,
        int timeoutMs)
    {
        using var p = new Process();
        p.StartInfo = new ProcessStartInfo(file, args)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };

        var stdout = new StringBuilder();
        var stderr = new StringBuilder();
        object syncOut = new();
        object syncErr = new();

        p.OutputDataReceived += (_, e) =>
        {
            if (e.Data is null) return;
            lock (syncOut) stdout.AppendLine(e.Data);
        };
        p.ErrorDataReceived += (_, e) =>
        {
            if (e.Data is null) return;
            lock (syncErr) stderr.AppendLine(e.Data);
        };

        try
        {
            if (!p.Start()) return (-1, "Impossibile avviare il processo.", false);
        }
        catch (Exception ex)
        {
            return (-1, "Impossibile avviare il processo: " + ex.Message, false);
        }

        p.BeginOutputReadLine();
        p.BeginErrorReadLine();

        bool exited = timeoutMs == Timeout.Infinite ? p.WaitForExit(int.MaxValue) : p.WaitForExit(timeoutMs);
        if (!exited)
        {
            try { p.Kill(true); } catch { }
            try { p.WaitForExit(5000); } catch { }
            string partial;
            lock (syncOut) lock (syncErr)
                partial = (stdout.ToString() + Environment.NewLine + stderr.ToString()).Trim();
            if (string.IsNullOrWhiteSpace(partial)) partial = $"Timeout dopo {timeoutMs / 1000} secondi.";
            return (-2, partial, true);
        }

        // Necessario dopo la lettura asincrona per attendere gli ultimi eventi OutputDataReceived/ErrorDataReceived.
        p.WaitForExit();
        string output;
        lock (syncOut) lock (syncErr)
            output = (stdout.ToString() + Environment.NewLine + stderr.ToString()).Trim();
        return (p.ExitCode, output, false);
    }

    static string? FindStartShortcut(string root, string appName)
    {
        if (string.IsNullOrWhiteSpace(root) || !Directory.Exists(root)) return null;
        try
        {
            return Directory.EnumerateFiles(root, "*.lnk", SearchOption.AllDirectories)
                .FirstOrDefault(f => string.Equals(Path.GetFileNameWithoutExtension(f), appName, StringComparison.OrdinalIgnoreCase)
                                  || Path.GetFileNameWithoutExtension(f).StartsWith(appName + " ", StringComparison.OrdinalIgnoreCase));
        }
        catch { return null; }
    }

    static void InstallOffice2024CompleteItalian()
    {
        // Office LTSC 2024 completo:
        // Professional Plus + Project Professional + Visio LTSC Professional,
        // 64-bit, Italiano, canale PerpetualVL2024.
        // L'installazione NON forza alcun metodo di attivazione: serve una licenza valida.
        string work = Path.Combine(Path.GetTempPath(), "SmartphonExpress-ODT-2024");
        Directory.CreateDirectory(work);

        string odt = Path.Combine(work, "officedeploymenttool.exe");
        string setup = Path.Combine(work, "setup.exe");
        string xml = Path.Combine(work, "configuration-2024.xml");
        string page = Path.Combine(work, "odt-page.html");

        // Scarica l'Office Deployment Tool esclusivamente da Microsoft.
        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.0");
            byte[] data = http.GetByteArrayAsync("https://www.microsoft.com/en-us/download/details.aspx?id=49117").GetAwaiter().GetResult();
            File.WriteAllBytes(page, data);
        }

        string html = File.ReadAllText(page);
        var m = System.Text.RegularExpressions.Regex.Match(
            html,
                "https://download\\.microsoft\\.com/download/[^\"']+officedeploymenttool[^\"']+\\.exe",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

        if (!m.Success)
            throw new Exception("Impossibile trovare il download ufficiale corrente di Office Deployment Tool.");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.0");
            byte[] data = http.GetByteArrayAsync(System.Net.WebUtility.HtmlDecode(m.Value)).GetAwaiter().GetResult();
            File.WriteAllBytes(odt, data);
        }

        Run(odt, $"/quiet /extract:{Quote(work)}");

        if (!File.Exists(setup))
            throw new Exception("Office Deployment Tool: setup.exe non estratto.");

        string config = """
<Configuration>
  <Remove All="TRUE" />
  <Add OfficeClientEdition="64" Channel="PerpetualVL2024" AllowCdnFallback="TRUE">
    <Product ID="ProPlus2024Volume">
      <Language ID="it-it" />
    </Product>
    <Product ID="ProjectPro2024Volume">
      <Language ID="it-it" />
    </Product>
    <Product ID="VisioPro2024Volume">
      <Language ID="it-it" />
    </Product>
  </Add>
  <RemoveMSI />
  <Updates Enabled="TRUE" />
  <Display Level="Full" AcceptEULA="TRUE" />
</Configuration>
""";

        File.WriteAllText(xml, config, new System.Text.UTF8Encoding(false));
        Run(setup, $"/configure {Quote(xml)}");
    }

    static void InstallOffice365Italian()
    {
        // Microsoft 365 Apps for enterprise, Current Channel, 64-bit, Italian.
        // Uses Microsoft's Office Deployment Tool downloaded at runtime.
        string work = Path.Combine(Path.GetTempPath(), "SmartphonExpress-ODT");
        Directory.CreateDirectory(work);
        string odt = Path.Combine(work, "officedeploymenttool.exe");
        string setup = Path.Combine(work, "setup.exe");
        string xml = Path.Combine(work, "configuration.xml");

        // Official Microsoft Download Center short link for the current Office Deployment Tool.
        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.0");
            byte[] data = http.GetByteArrayAsync("https://www.microsoft.com/en-us/download/details.aspx?id=49117").GetAwaiter().GetResult();
            File.WriteAllBytes(Path.Combine(work, "odt-page.html"), data);
        }

        // Resolve the current Microsoft-hosted ODT executable URL from the official page.
        string html = File.ReadAllText(Path.Combine(work, "odt-page.html"));
        var m = System.Text.RegularExpressions.Regex.Match(
            html,
                "https://download\\.microsoft\\.com/download/[^\"']+officedeploymenttool[^\"']+\\.exe",
            System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        if (!m.Success) throw new Exception("Impossibile trovare il download ufficiale corrente di Office Deployment Tool.");
        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.0");
            byte[] data = http.GetByteArrayAsync(System.Net.WebUtility.HtmlDecode(m.Value)).GetAwaiter().GetResult();
            File.WriteAllBytes(odt, data);
        }

        Run(odt, $"/quiet /extract:{Quote(work)}");
        if (!File.Exists(setup)) throw new Exception("Office Deployment Tool: setup.exe non estratto.");

        string config = """
<Configuration>
  <Add OfficeClientEdition="64" Channel="Current" AllowCdnFallback="TRUE">
    <Product ID="O365ProPlusRetail">
      <Language ID="it-it" />
    </Product>
  </Add>
  <Updates Enabled="TRUE" />
  <Display Level="Full" AcceptEULA="TRUE" />
</Configuration>
""";
        File.WriteAllText(xml, config, new System.Text.UTF8Encoding(false));

        Run(setup, $"/configure {Quote(xml)}");
    }

    static void InstallOffice365CompleteItalian()
    {
        // Microsoft 365 Apps + Visio + Project. L'installazione non concede licenze:
        // Visio e Project richiedono una licenza/account idoneo del cliente.
        string work = Path.Combine(Path.GetTempPath(), "SmartphonExpress-ODT-Complete");
        Directory.CreateDirectory(work);
        string odt = Path.Combine(work, "officedeploymenttool.exe");
        string setup = Path.Combine(work, "setup.exe");
        string xml = Path.Combine(work, "configuration-complete.xml");

        using (var http = new System.Net.Http.HttpClient())
        {
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.7.5");
            byte[] page = http.GetByteArrayAsync("https://www.microsoft.com/en-us/download/details.aspx?id=49117").GetAwaiter().GetResult();
            string html = Encoding.UTF8.GetString(page);
            var m = System.Text.RegularExpressions.Regex.Match(html,
                "https://download\\.microsoft\\.com/download/[^\"']+officedeploymenttool[^\"']+\\.exe",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (!m.Success) throw new Exception("Impossibile trovare il download ufficiale corrente di Office Deployment Tool.");
            byte[] data = http.GetByteArrayAsync(System.Net.WebUtility.HtmlDecode(m.Value)).GetAwaiter().GetResult();
            File.WriteAllBytes(odt, data);
        }
        Run(odt, $"/quiet /extract:{Quote(work)}");
        if (!File.Exists(setup)) throw new Exception("Office Deployment Tool: setup.exe non estratto.");

        string config = """
<Configuration>
  <Add OfficeClientEdition="64" Channel="Current" AllowCdnFallback="TRUE">
    <Product ID="O365ProPlusRetail"><Language ID="it-it" /></Product>
    <Product ID="VisioProRetail"><Language ID="it-it" /></Product>
    <Product ID="ProjectProRetail"><Language ID="it-it" /></Product>
  </Add>
  <Updates Enabled="TRUE" />
  <Display Level="Full" AcceptEULA="TRUE" />
</Configuration>
""";
        File.WriteAllText(xml, config, new UTF8Encoding(false));
        Run(setup, $"/configure {Quote(xml)}");
    }

    static void UninstallAllOffice()
    {
        var before = GetOfficeInstalledProducts();
        bool detected = IsOfficeInstalled();
        if (!detected)
        {
            MessageBox.Show("Non risultano installazioni Microsoft Office / Microsoft 365 / Visio / Project da rimuovere.",
                "SmartphonExpress - Rimozione Office", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        string detectedText = before.Count > 0 ? "\n\nRilevato:\n• " + string.Join("\n• ", before) : string.Empty;
        var answer = MessageBox.Show(
            "Questa operazione rimuoverà tutte le versioni di Microsoft Office rilevate, incluse Microsoft 365, Office, Visio e Project." +
            detectedText +
            "\n\nChiudi prima tutte le applicazioni Office. Al termine può essere necessario riavviare Windows.\n\nContinuare?",
            "SmartphonExpress - Rimozione completa Office",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
        if (answer != DialogResult.Yes) return;

        string work = Path.Combine(Path.GetTempPath(), "SmartphonExpress-OfficeScrub");
        if (Directory.Exists(work)) { try { Directory.Delete(work, true); } catch { } }
        Directory.CreateDirectory(work);
        string zip = Path.Combine(work, "GetHelpCmd.zip");

        using (var http = new System.Net.Http.HttpClient(new System.Net.Http.HttpClientHandler { AllowAutoRedirect = true }))
        {
            http.Timeout = TimeSpan.FromMinutes(5);
            http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.8.3");
            byte[] data = http.GetByteArrayAsync("https://aka.ms/SaRA_EnterpriseVersionFiles").GetAwaiter().GetResult();
            File.WriteAllBytes(zip, data);
        }
        ZipFile.ExtractToDirectory(zip, work, true);
        string? exe = Directory.EnumerateFiles(work, "GetHelpCmd.exe", SearchOption.AllDirectories).FirstOrDefault();
        if (exe is null) throw new Exception("Strumento Microsoft Get Help non trovato nel pacchetto scaricato.");

        var result = RunCaptureWithTimeout(exe, "-S OfficeScrubScenario -AcceptEula -OfficeVersion All", 45 * 60 * 1000);
        if (result.TimedOut)
            throw new Exception("La procedura Microsoft di rimozione Office ha superato il timeout di 45 minuti.");
        if (result.ExitCode != 0)
            throw new Exception("La procedura Microsoft di rimozione Office non è terminata correttamente (codice " + result.ExitCode + ").\n\n" + result.Output);

        // Non dichiariamo successo solo perche' GetHelpCmd e' terminato: ricontrolliamo realmente il PC.
        Thread.Sleep(2000);
        var after = GetOfficeInstalledProducts();
        bool stillInstalled = IsOfficeInstalled();
        if (stillInstalled)
        {
            string leftovers = after.Count > 0 ? "\n\nAncora rilevato:\n• " + string.Join("\n• ", after) :
                "\n\nSono ancora presenti componenti/eseguibili Office rilevati dal sistema.";
            MessageBox.Show(
                "La procedura Microsoft è terminata, ma SmartphonExpress rileva ancora componenti Office." + leftovers +
                "\n\nRiavvia Windows e ripeti il controllo. Se restano presenti, sarà necessario verificare il tipo di installazione/residuo prima di reinstallare.",
                "SmartphonExpress - Office non completamente rimosso",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        MessageBox.Show(
            "Rimozione Office completata e verificata: non risultano più installazioni Office/Visio/Project rilevabili.\n\nÈ comunque consigliato riavviare Windows prima di reinstallare Office.",
            "SmartphonExpress", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    static string Quote(string value) => "\"" + value.Replace("\"", "\\\"") + "\"";
}
