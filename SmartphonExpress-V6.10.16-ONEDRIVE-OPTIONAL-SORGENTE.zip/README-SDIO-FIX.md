# Correzione SDIO: cartella incompleta dopo estrazione

Il messaggio mostrato dall'utente nasce da `SdioInstaller.EnsureInstalledAsync`: dopo aver scaricato e verificato il nuovo archivio, il codice precedente interrompeva l'installazione se la cartella `AppData\\Local\\SmartphonExpress\\Tools\\SDIO` esisteva già, anche se era vuota o lasciata da un tentativo fallito.

La modifica in `source/SdioInstaller.cs` conserva la vecchia cartella rinominandola con suffisso `-backup-...` e sposta al suo posto la nuova installazione verificata. Non elimina file esistenti. Se lo spostamento fallisce, tenta di ripristinare la cartella precedente. Nessun driver viene installato automaticamente.

Test richiesto su Windows: 1) cartella SDIO vuota, 2) cartella con file incompleti, 3) SDIO già valido, 4) archivio remoto non valido, 5) permessi insufficienti, 6) secondo avvio diretto. Il sorgente non è stato compilato né eseguito in Windows in questo ambiente.
