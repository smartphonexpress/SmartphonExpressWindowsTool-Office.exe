# SmartphonExpress V6.10.12 — Fix avvio SDIO

## Causa individuata nel sorgente V6.10.11
La voce gestione driver viene eseguita da ApplySelected tramite Task.Run (thread MTA).
OpenDriverManager creava direttamente la finestra su quel thread, senza inoltrarla al thread grafico STA. Il successivo OpenFileDialog per SDIO richiede STA: questo percorso può causare un errore o un'apparente attesa/blocco della finestra di selezione. L'accesso dalla finestra driver già sul thread UI non presentava lo stesso difetto.
Inoltre i callback di scansione, backup e Process.Start erano sincroni sul thread della finestra.

## Correzione limitata al modulo driver
- Finestra e dialoghi aperti sul thread grafico STA, anche da Esegui selezionati.
- Scansione e backup eseguiti in background con i timeout preesistenti (120/300 secondi).
- Process.Start su thread STA dedicato, atteso asincronamente, senza WaitForExit.
- Percorso assoluto, controllo nome/file esistente e WorkingDirectory uguale alla cartella SDIO; percorsi con spazi supportati.
- Handle Process rilasciato senza terminare SDIO.
- Stato visibile, protezione dai clic concorrenti e ripristino pulsanti nel finally.
- Errori dettagliati nel log, messaggio a video e gestione annullamento UAC.
- Chiusura della finestra driver rinviata finché l'operazione corrente termina, per evitare callback su controlli eliminati.

Il modulo SDIO non scarica né estrae archivi: seleziona un eseguibile locale.
Estrarre manualmente l'intero pacchetto ufficiale, mantenendo le relative cartelle, poi scegliere SDIO.exe o SDIO_x64*.exe. Il nome del file non certifica la sua provenienza.
Nessun download, installazione automatica driver o modifica agli altri tweak è stato aggiunto.

## Verifiche effettuate
.NET SDK 8.0.428 su Windows:
- dotnet build -c Release: 0 errori, 0 avvisi.
- dotnet publish -c Release: riuscito, eseguibile portatile generato per verifica.
- Smoke test launcher: nome non valido, file mancante, percorso con spazi, directory di lavoro corretta, ritorno prima della chiusura del processo, processo indipendente dopo il rilascio dell'handle: superati.
Il test usa un programma innocuo di prova; SDIO reale e i dialoghi interattivi non sono stati collaudati end-to-end. Nessun driver è stato installato.

## Compilazione e verifica manuale
Aprire source ed eseguire BUILD-EXE.cmd (SDK .NET 8 e accesso NuGet richiesti).
Per ripetere gli smoke test: dotnet run --project tests/SdioSmoke.csproj -c Release.
Verificare Avvia SDIO sia da Esegui selezionati sia dalla finestra Periferiche e driver; provare Annulla, file valido, file rimosso, errore di avvio e successivo nuovo tentativo. Verificare scansione/backup e aggiornamento della finestra durante l'attesa.
