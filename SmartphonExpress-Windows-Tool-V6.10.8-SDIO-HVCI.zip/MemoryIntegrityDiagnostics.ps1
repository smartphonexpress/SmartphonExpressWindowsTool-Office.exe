$ErrorActionPreference = 'Stop'
function Get-CiClassification([int]$Id) {
    switch ($Id) {
        3087 { 'Compatibilita Integrita memoria: verificare dettagli; non prova da sola un blocco attuale.' }
        3077 { 'Blocco App Control applicato; NON attribuibile automaticamente a HVCI.' }
        3076 { 'Audit App Control: blocco ipotetico, NON applicato da questa policy.' }
        3034 { 'Audit firma/integrita: NON prova di blocco.' }
        3033 { 'Requisiti firma/integrita non soddisfatti; causa HVCI non dimostrata.' }
        3004 { 'Problema firma/integrita; causa HVCI non dimostrata.' }
        default { 'Evento Code Integrity: consultare dettagli.' }
    }
}
function Resolve-CiPath([string]$Value) {
    $p = [Environment]::ExpandEnvironmentVariables($Value.Trim().Trim('"'))
    if ($p.StartsWith('\??\')) { $p = $p.Substring(4) }
    if ($p -match '^\\SystemRoot\\') { $p = $env:SystemRoot + $p.Substring(11) }
    if ($p -match '^(?i)System32\\') { $p = Join-Path $env:SystemRoot $p }
    if ($p -match '^\\Device\\') {
        try {
            if (-not ('SmartphonExpress.CiNative' -as [type])) {
                Add-Type -TypeDefinition 'using System; using System.Text; using System.Runtime.InteropServices; namespace SmartphonExpress { public static class CiNative { [DllImport("kernel32.dll", CharSet=CharSet.Unicode)] public static extern uint QueryDosDevice(string name, StringBuilder target, int size); } }'
            }
            foreach ($drive in [IO.DriveInfo]::GetDrives()) {
                if ($drive.DriveType -eq [IO.DriveType]::Network) { continue }
                $letter = $drive.Name.Substring(0,2)
                $buffer = New-Object Text.StringBuilder 4096
                if ([SmartphonExpress.CiNative]::QueryDosDevice($letter,$buffer,$buffer.Capacity)) {
                    $prefix = $buffer.ToString().Split([char]0)[0]
                    if ($p.StartsWith($prefix + '\', [StringComparison]::OrdinalIgnoreCase)) {
                        return $letter + $p.Substring($prefix.Length)
                    }
                }
            }
        } catch { } # Keep the original path if native mapping is unavailable.
    }
    return $p
}
function Get-CiFields([xml]$Xml) {
    $fields = [ordered]@{}
    $i = 0
    foreach ($node in $Xml.SelectNodes('//*[local-name()="EventData"]/*[local-name()="Data"]')) {
        $name = $node.GetAttribute('Name')
        if (!$name) { $name = 'Data' + $i }
        $fields[$name] = $node.InnerText
        $i++
    }
    return $fields
}
function Write-MemoryIntegrityReport {
    '=== INTEGRITA MEMORIA / COMPATIBILITA DRIVER - V6.10.8 ==='
    'Acquisizione: ' + (Get-Date).ToString('o') + ' | PC: ' + $env:COMPUTERNAME
    'Diagnostica sola lettura. Nessuna modifica a protezioni, policy o driver.'
    try {
        $os = Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10
        'Sistema: ' + $os.Caption + ' | Build: ' + $os.BuildNumber
    } catch { 'Sistema: non disponibile - ' + $_.Exception.Message }
    try {
        $dg = Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard -OperationTimeoutSec 10
        if (!$dg) { throw 'Win32_DeviceGuard non restituisce dati.' }
        $vbs = switch ([int]$dg.VirtualizationBasedSecurityStatus) { 0 {'Non abilitato'} 1 {'Abilitato ma non in esecuzione'} 2 {'In esecuzione'} default {'Sconosciuto'} }
        'VBS: ' + $vbs
        'HVCI configurato: ' + (@($dg.SecurityServicesConfigured) -contains 2)
        'HVCI in esecuzione: ' + (@($dg.SecurityServicesRunning) -contains 2)
        'Servizi configurati/running (valori originali): ' + ($dg.SecurityServicesConfigured -join ',') + ' / ' + ($dg.SecurityServicesRunning -join ',')
    } catch { 'Stato VBS/HVCI: NON DETERMINABILE - ' + $_.Exception.Message }
    ''
    '=== EVIDENZE CODE INTEGRITY ==='
    $logName = 'Microsoft-Windows-CodeIntegrity/Operational'
    $since = (Get-Date).AddDays(-30)
    'Finestra: ultimi 30 giorni, massimo 500 eventi pertinenti (piu recenti).'
    'Lo stato attuale HVCI non descrive necessariamente lo stato alla data di un evento.'
    try {
        $config = Get-WinEvent -ListLog $logName
        'Log abilitato: ' + $config.IsEnabled + ' | Record conservati: ' + $config.RecordCount
        if (!$config.IsEnabled) { 'ATTENZIONE: log disabilitato, evidenze incomplete. Non viene abilitato automaticamente.' }
        $events = @()
        try {
            $events = @(Get-WinEvent -FilterHashtable @{LogName=$logName; Id=3087,3077,3076,3033,3034,3004; StartTime=$since} -MaxEvents 501)
        } catch {
            if ($_.FullyQualifiedErrorId -notlike 'NoMatchingEventsFound*') { throw }
        }
        if ($events.Count -gt 500) { 'ATTENZIONE: risultati troncati ai 500 eventi piu recenti.' }
        if (!$events.Count) { 'Nessun evento pertinente nella finestra disponibile. NON certifica la compatibilita di tutti i driver.' }
        foreach ($event in ($events | Select-Object -First 500)) {
            try {
                [xml]$xml = $event.ToXml()
                $fields = Get-CiFields $xml
                ''
                'Evento ' + $event.Id + ' | Data: ' + $event.TimeCreated.ToString('o') + ' | Record: ' + $event.RecordId
                Get-CiClassification $event.Id
                'ActivityID: ' + [string]$xml.Event.System.Correlation.ActivityID
                $paths = @($fields.GetEnumerator() | Where-Object { $_.Key -notmatch 'Process' -and ($_.Key -match '^(FileName|FilePath|ImageName|DriverName)(Buffer)?$' -or $_.Value -match '(?i)\.sys$') } | ForEach-Object { [string]$_.Value } | Select-Object -Unique)
                if (!$paths.Count) { 'Nome/percorso driver: non disponibile nei campi strutturati; consultare messaggio e dati.' }
                foreach ($raw in $paths) {
                    $path = Resolve-CiPath $raw
                    'File segnalato: ' + $raw
                    'Nome: ' + ($path -split '\\')[-1] + ' | Percorso: ' + $path
                    if ($path -notmatch '(?i)\.sys$') { 'Il file non ha estensione .sys: non classificato automaticamente come driver kernel.' }
                    if ($path -match '(?i)usbdk|adb|usb|octoplus') { 'Riferimento USB/ADB/laboratorio nel nome: indizio descrittivo, non diagnosi causale.' }
                    # Read only explicit local drive paths; never access a remote path from an event.
                    if ($path -match '^[A-Za-z]:\\' -and (Test-Path -LiteralPath $path -PathType Leaf)) {
                        try {
                            $vi = [Diagnostics.FileVersionInfo]::GetVersionInfo($path)
                            'Produttore (metadati file attuale): ' + $(if ($vi.CompanyName) {$vi.CompanyName} else {'non disponibile'})
                            'Versione (file attuale): ' + $(if ($vi.FileVersion) {$vi.FileVersion} else {'non disponibile'})
                            'Il file attuale potrebbe essere diverso da quello presente alla data dell evento.'
                        } catch { 'Metadati file non disponibili: ' + $_.Exception.Message }
                    } else { 'Produttore/versione: non disponibili (file assente o percorso non risolto/localmente accessibile).' }
                }
                'Dati evento originali:'
                foreach ($entry in $fields.GetEnumerator()) { '  ' + $entry.Key + ': ' + $entry.Value }
                try { 'Messaggio: ' + $event.FormatDescription() } catch { 'Messaggio non disponibile; usare i dati originali sopra.' }
            } catch { 'Evento non interpretabile, record ' + $event.RecordId + ': ' + $_.Exception.Message }
        }
    } catch { 'LETTURA LOG NON RIUSCITA: ' + $_.Exception.Message; 'Evidenze non disponibili. Verificare permessi e presenza del canale; non equivale ad assenza di problemi.' }
    ''
    '=== PASSI CONSIGLIATI ==='
    '1. Confrontare data, percorso e dettagli evento con il momento del guasto e con la diagnostica periferiche.'
    '2. Cercare prima un driver compatibile aggiornato da Windows Update o dal produttore del dispositivo/tool.'
    '3. Se non disponibile, valutare la rimozione mirata del driver o software incompatibile tramite il relativo programma di disinstallazione/Gestione dispositivi, verificando le periferiche dipendenti.'
    '4. Dopo aggiornamento o rimozione, riavviare se richiesto e ripetere la diagnosi; gli eventi storici rimangono nel report.'
    'USB, ADB, UsbDk, Bluetooth e tool di assistenza possono avere altre cause di errore. Nessuna attribuzione automatica a HVCI.'
    'Non eliminare manualmente file .sys. Non disattivare indiscriminatamente Integrita memoria o altre protezioni.'
    'Salvare il report prima e dopo gli interventi per confrontare gli stati; nessuno storico precedente viene inventato.'
}
Write-MemoryIntegrityReport



