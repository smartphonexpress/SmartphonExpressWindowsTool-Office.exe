$ErrorActionPreference='Stop'
$scriptPath=Join-Path $PSScriptRoot '..\MemoryIntegrityDiagnostics.ps1'
$code=Get-Content $scriptPath -Raw
. ([scriptblock]::Create(($code -replace 'Write-MemoryIntegrityReport\s*$','')))
function Assert($condition,$message) { if(!$condition){throw $message}; 'PASS: '+$message }
Assert ((Get-CiClassification 3076) -match 'NON applicato') '3076 audit non trattato come blocco'
Assert ((Get-CiClassification 3077) -match 'NON attribuibile') '3077 non attribuito a HVCI'
Assert ((Get-CiClassification 3087) -match 'non prova') '3087 non prova blocco attuale'
Assert ((Resolve-CiPath '\SystemRoot\System32\drivers\test.sys') -eq "$env:SystemRoot\System32\drivers\test.sys") 'Risoluzione SystemRoot'
Assert ((Resolve-CiPath '\??\C:\drivers\test.sys') -eq 'C:\drivers\test.sys') 'Risoluzione prefisso NT'
[xml]$fixture='<Event xmlns="http://schemas.microsoft.com/win/2004/08/events/event"><EventData><Data Name="ProcessName">C:\app.exe</Data><Data Name="FileNameLength">63</Data><Data Name="FileNameBuffer">\SystemRoot\System32\drivers\missing-usbdk.sys</Data><Data Name="Version">1.2.3</Data></EventData></Event>'
$f=Get-CiFields $fixture
Assert ($f['FileNameBuffer'] -like '*missing-usbdk.sys') 'Estrazione XML indipendente dalla lingua'
function Get-CimInstance { param($ClassName,$Namespace,$OperationTimeoutSec) if($ClassName -eq 'Win32_DeviceGuard'){[pscustomobject]@{VirtualizationBasedSecurityStatus=2;SecurityServicesConfigured=@(1,2);SecurityServicesRunning=@(1,2)}}else{[pscustomobject]@{Caption='Windows 11 fixture';BuildNumber='26100'}} }
$script:mode='events'
function Get-WinEvent { param($ListLog,$FilterHashtable,$MaxEvents)
 if($script:mode -eq 'denied'){throw 'Access denied fixture'}
 if($ListLog){return [pscustomobject]@{IsEnabled=($script:mode -ne 'disabled');RecordCount=3}}
 if($script:mode -in @('empty','disabled')){return}
 foreach($id in @(3087,3076,3077)){
 $e=[pscustomobject]@{Id=$id;TimeCreated=(Get-Date);RecordId=$id}
 $e | Add-Member ScriptMethod ToXml {$fixture.OuterXml}.GetNewClosure()
 $e | Add-Member ScriptMethod FormatDescription {'Synthetic event'}
 $e
 }
}
$r=Write-MemoryIntegrityReport | Out-String
Assert ($r -match 'HVCI in esecuzione: True') 'HVCI runtime distinto da configurazione'
Assert ($r -match 'missing-usbdk.sys' -and $r -match 'non disponibili \(file assente') 'Driver assente conserva identificazione e limiti metadati'
Assert ($r -notmatch 'Nome: app.exe') 'Processo chiamante non confuso con driver'
Assert ($r -notmatch 'Nome: 63') 'Campo lunghezza non scambiato per file'
$script:mode='empty'; $r=Write-MemoryIntegrityReport | Out-String
Assert ($r -match 'NON certifica') 'Nessun evento non certifica compatibilita'
$script:mode='denied'; $r=Write-MemoryIntegrityReport | Out-String
Assert ($r -match 'LETTURA LOG NON RIUSCITA' -and $r -notmatch 'Nessun evento pertinente') 'Accesso negato non confuso con log vuoto'
$script:mode='disabled'; $r=Write-MemoryIntegrityReport | Out-String
Assert ($r -match 'log disabilitato') 'Log disabilitato esplicito'

'ALL TESTS PASSED'




