param([string]$Source=(Join-Path $PSScriptRoot '..\MissingDrivers.ps1'))
$ErrorActionPreference='Stop'
$tokens=$null; $errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile($Source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw ($errors | Out-String)}
foreach($f in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)) { . ([scriptblock]::Create($f.Extent.Text)) }
$script:count=0
function Assert($ok,$text){if(!$ok){throw $text}; $script:count++; 'PASS: '+$text}
Assert ((Get-DriverCategory 28 'Error' '') -match 'Driver mancante') 'Codice 28 driver mancante'
Assert ((Get-DriverCategory 22 'Error' 'USB') -match 'disabilitato') 'Disabilitato distinto da driver mancante'
Assert ((Get-DriverCategory 10 'Error' 'USB') -match 'non prova') 'Codice 10 non prova driver mancante'
Assert ((Get-DriverCategory 43 'Error' 'USB') -match 'Errore segnalato') 'Codice 43 distinto'
Assert ((Get-DriverCategory $null 'Unknown' '') -match 'da verificare') 'Unknown non trattato come driver mancante certo'
function Get-PnpDevice {param([switch]$PresentOnly) if(!$PresentOnly){throw 'Scansione include periferiche assenti'}
 [pscustomobject]@{InstanceId='PCI\VEN_1234&DEV_5678\TEST';FriendlyName='Unknown PCI';Status='Error';Class='';ConfigManagerErrorCode=28}
 [pscustomobject]@{InstanceId='USB\VID_ABCD&PID_0123\TEST';FriendlyName='USB disabilitato';Status='Error';Class='USB';ConfigManagerErrorCode=22}
 [pscustomobject]@{InstanceId='GOOD';FriendlyName='Funzionante';Status='OK';Class='System';ConfigManagerErrorCode=0}
}
function Get-PnpDeviceProperty {param($InstanceId,$KeyName)
 if(!$KeyName) {
  foreach($k in @('DEVPKEY_Device_HardwareIds','DEVPKEY_Device_Manufacturer','DEVPKEY_Device_DriverInfPath','DEVPKEY_Device_DriverVersion')) {
   $v=Get-PnpDeviceProperty -InstanceId $InstanceId -KeyName $k
   [pscustomobject]@{KeyName=$k;Data=$v.Data}
  }
  return
 }
 $value=switch($KeyName){
 'DEVPKEY_Device_HardwareIds' {if($InstanceId -like 'PCI*'){@('PCI\VEN_1234&DEV_5678','PCI\VEN_1234')}else{@('USB\VID_ABCD&PID_0123')}}
 'DEVPKEY_Device_Manufacturer' {'Produttore Test'}
 'DEVPKEY_Device_DriverInfPath' {if($InstanceId -like 'USB*'){'oem42.inf'}}
 'DEVPKEY_Device_DriverVersion' {'1.2.3'}
 default {$null}
 }; [pscustomobject]@{Data=$value}
}
$s=Get-DriverSnapshot
Assert ($s.PresentCount -eq 3 -and $s.Devices.Count -eq 2) 'Solo dispositivi problematici nella lista'
Assert ($s.PresentIds -contains 'GOOD') 'Presenza dei dispositivi sani conservata per confronto'
Assert ($s.Devices[0].Identifiers -eq 'VEN_1234 / DEV_5678') 'Estrazione PCI VEN DEV'
Assert ($s.Devices[1].Identifiers -eq 'VID_ABCD / PID_0123') 'Estrazione USB VID PID'
Assert ($s.Devices[1].Inf -eq 'oem42.inf') 'INF attuale recuperato'
$j=$s | ConvertTo-Json -Depth 7 -Compress | ConvertFrom-Json
Assert ($j.Success -and $j.Devices[0].HardwareIds.Count -eq 2) 'JSON conserva array Hardware ID'
function Get-PnpDeviceProperty {param($InstanceId,$KeyName) throw 'Proprieta non disponibile'}
$s=Get-DriverSnapshot
Assert ($s.Warnings.Count -eq 2 -and $s.Devices.Count -eq 2) 'Proprieta mancanti segnalate senza perdere dispositivi'
function Get-PnpDevice {param([switch]$PresentOnly) throw 'Access denied fixture'}
$result=& $Source -Mode Scan | ConvertFrom-Json
Assert (!$result.Success -and $result.Error -match 'Access denied') 'Errore scansione non scambiato per nessun problema'
function Get-PnpDevice {param([switch]$PresentOnly) return}
$result=& $Source -Mode Scan | ConvertFrom-Json
Assert ($result.Success -and $result.Devices.Count -eq 0) 'Scansione vuota valida distinta da errore'
"ALL $script:count TESTS PASSED"


