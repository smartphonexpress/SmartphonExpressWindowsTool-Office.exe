using SmartphonExpressWindowsTool;
using System;
namespace SmartphonExpressWindowsTool {
 public sealed partial class MainForm : System.Windows.Forms.Form {
  static (int ExitCode,string Output,bool TimedOut) RunCaptureWithTimeout(string file,string args,int timeout) => throw new Exception("I test non eseguono comandi di sistema");
 }
}
class Tests {
 static int count;
 static void Assert(bool v,string name) {if(!v)throw new Exception(name);count++;Console.WriteLine("PASS: "+name);}
 static void Main(string[] args) {
 if(args.Length > 0) {
  var asm=System.Reflection.Assembly.LoadFrom(args[0]);
  var method=asm.GetType("SmartphonExpressWindowsTool.MainForm")!.GetMethod("ScanMissingDrivers",System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.NonPublic)!;
  var clock=System.Diagnostics.Stopwatch.StartNew();
  var result=method.Invoke(null,null)!;
  Console.WriteLine("Production scan OK in "+clock.Elapsed.TotalSeconds.ToString("F1")+"s");
  Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(result));
  return;
 }
 var old=new MainForm.DriverSnapshot{Success=true,Time="prima",Devices=[new(){InstanceId="USB\\1",Name="Test",Category="mancante"}]};
 var after=new MainForm.DriverSnapshot{Success=true,Time="dopo",PresentIds=["usb\\1"]};
 Assert(MainForm.CompareDriverSnapshots(old,after).Contains("nessun problema rilevato"),"Presente e senza problema");
 after.PresentIds=[];
 Assert(MainForm.CompareDriverSnapshots(old,after).Contains("NON classificato come riparato"),"Scollegato non riparato");
 after.Devices=[new(){InstanceId="usb\\1",Name="Test",Category="errore",Inf="oem1.inf",Version="2.0"}];
 Assert(MainForm.CompareDriverSnapshots(old,after).Contains("Ancora da verificare"),"Errore persistente");
 Assert(!MainForm.CompareDriverSnapshots(old,after).Contains("Nuova segnalazione"),"Confronto ID case insensitive");
 after.Devices=[new(){InstanceId="NEW",Name="Nuovo",Category="errore"}];
 Assert(MainForm.CompareDriverSnapshots(old,after).Contains("Nuova segnalazione"),"Nuovo problema riportato");
 after.Success=false;
 Assert(MainForm.CompareDriverSnapshots(old,after).Contains("scansione incompleta"),"Scansione fallita non dichiarata riparazione");
 Console.WriteLine($"ALL {count} TESTS PASSED");
 }
}

