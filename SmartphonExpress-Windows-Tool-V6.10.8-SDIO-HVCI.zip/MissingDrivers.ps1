param([ValidateSet('Scan','Candidates','Backup')][string]$Mode='Scan', [string]$DeviceId='', [string]$Destination='')
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding $false
function Read-DeviceValue($Device, [string]$Key) {
    if (!$script:driverPropertyCache.ContainsKey($Device.InstanceId)) {
        $values = @{}
        try {
            foreach ($p in @(Get-PnpDeviceProperty -InstanceId $Device.InstanceId -ErrorAction Stop)) { $values[$p.KeyName] = $p.Data }
        } catch { } # Missing properties stay unknown, not a proof of a missing driver.
        $script:driverPropertyCache[$Device.InstanceId] = $values
    }
    return $script:driverPropertyCache[$Device.InstanceId][$Key]
}
function Get-DriverCategory($Code, [string]$Status, [string]$Class) {
    if ($null -ne $Code -and [int]$Code -eq 28) { return 'Driver mancante (codice 28)' }
    if ($null -ne $Code -and [int]$Code -eq 22) { return 'Dispositivo disabilitato (non driver mancante)' }
    if ($null -ne $Code -and [int]$Code -eq 10) { return 'Avvio non riuscito (non prova driver mancante)' }
    if ($null -ne $Code -and [int]$Code -eq 43) { return 'Errore segnalato dal dispositivo' }
    if ($Code -eq 0 -and $Status -eq 'OK' -and !$Class) { return 'Classe non specificata (stato OK, non prova driver mancante)' }
    if ($Status -eq 'Unknown' -or !$Class -or $Class -eq 'Unknown') { return 'Dispositivo/stato sconosciuto: da verificare' }
    return 'Dispositivo problematico: da verificare'
}
function Get-DriverSnapshot {
    $script:driverPropertyCache = @{}
    $devices = @(Get-PnpDevice -PresentOnly -ErrorAction Stop)
    $warnings = [Collections.Generic.List[string]]::new()
    $rows = [Collections.Generic.List[object]]::new()
    foreach ($d in $devices) {
        $code = $d.ConfigManagerErrorCode
        if ($null -eq $code) { $code = Read-DeviceValue $d 'DEVPKEY_Device_ProblemCode' }
        if ($null -eq $code -and $d.Status -eq 'OK' -and $d.Class) { continue }
        if (($null -ne $code -and [int]$code -ne 0) -or $d.Status -ne 'OK' -or !$d.Class -or $d.Class -eq 'Unknown') {
            $hwids = @(Read-DeviceValue $d 'DEVPKEY_Device_HardwareIds' | Where-Object { $_ })
            $compat = @(Read-DeviceValue $d 'DEVPKEY_Device_CompatibleIds' | Where-Object { $_ })
            $identifiers = @([regex]::Matches(($hwids -join ' '),'(?i)(?:VEN|DEV|VID|PID)_[0-9A-F]{4}') | ForEach-Object {$_.Value} | Select-Object -Unique)
            $inf = Read-DeviceValue $d 'DEVPKEY_Device_DriverInfPath'
            if ($null -eq $code -or !$hwids.Count) { $warnings.Add('Proprieta incomplete per ' + $d.InstanceId) }
            $rows.Add([pscustomobject]@{
                InstanceId=[string]$d.InstanceId; Name=$(if($d.FriendlyName){[string]$d.FriendlyName}else{[string]$d.InstanceId})
                Status=[string]$d.Status; Code=$(if($null -ne $code){[int]$code}else{$null})
                Category=(Get-DriverCategory $code $d.Status $d.Class); Class=[string]$d.Class
                Manufacturer=[string](Read-DeviceValue $d 'DEVPKEY_Device_Manufacturer')
                HardwareIds=[string[]]$hwids; CompatibleIds=[string[]]$compat; Identifiers=($identifiers -join ' / ')
                Inf=[string]$inf; Provider=[string](Read-DeviceValue $d 'DEVPKEY_Device_DriverProvider')
                Version=[string](Read-DeviceValue $d 'DEVPKEY_Device_DriverVersion')
            })
        }
    }
    [pscustomobject]@{ Success=$true; Time=(Get-Date).ToString('o'); PresentCount=$devices.Count; PresentIds=[string[]]@($devices | ForEach-Object {$_.InstanceId}); Devices=@($rows.ToArray()); Warnings=@($warnings.ToArray()); Error='' }
}
try {
    switch ($Mode) {
        'Scan' { Get-DriverSnapshot | ConvertTo-Json -Depth 7 -Compress }
        'Candidates' {
            if (!$DeviceId) { throw 'Selezionare un dispositivo.' }
            & "$env:SystemRoot\System32\pnputil.exe" /enum-devices /instanceid $DeviceId /drivers
            if ($LASTEXITCODE -ne 0) { throw ('PnPUtil: codice ' + $LASTEXITCODE + '. Elenco candidati non disponibile su questa versione/configurazione.') }
        }
        'Backup' {
            if (!$Destination -or !(Test-Path -LiteralPath $Destination -PathType Container)) { throw 'Cartella backup non disponibile.' }
            $notes = [Collections.Generic.List[string]]::new()
            $restore = $false
            try {
                $before = @(Get-ComputerRestorePoint -ErrorAction Stop | Select-Object -ExpandProperty SequenceNumber)
                Checkpoint-Computer -Description 'SmartphonExpress 6.10.8 - prima dei driver' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop -WarningAction Stop
                $after = @(Get-ComputerRestorePoint -ErrorAction Stop | Where-Object { $_.SequenceNumber -notin $before })
                $restore = $after.Count -gt 0
                $notes.Add('Nuovo punto di ripristino verificato: ' + $restore)
            } catch { $notes.Add('Punto di ripristino non creato: ' + $_.Exception.Message) }
            $export = $false
            try {
                $dir = Join-Path $Destination 'DriverStore'
                New-Item -ItemType Directory -Path $dir -ErrorAction Stop | Out-Null
                $output = & "$env:SystemRoot\System32\pnputil.exe" /export-driver '*' $dir 2>&1
                $exit = $LASTEXITCODE
                $notes.Add(($output | Out-String))
                $count = @(Get-ChildItem -LiteralPath $dir -Filter '*.inf' -Recurse -File).Count
                $export = $exit -eq 0 -and $count -gt 0
                $notes.Add('Esportazione driver terze parti: codice ' + $exit + '; INF esportati: ' + $count)
            } catch { $notes.Add('Esportazione driver non riuscita: ' + $_.Exception.Message) }
            $notes.Add('Il backup dei driver non e una immagine del sistema. Driver inbox e software accessorio non sono inclusi.')
            [pscustomobject]@{ Success=($restore -or $export); RestorePoint=$restore; Exported=$export; Notes=($notes -join "`r`n"); Folder=$Destination } | ConvertTo-Json -Compress
        }
    }
} catch {
    if ($Mode -eq 'Scan') {
        [pscustomobject]@{Success=$false;Time=(Get-Date).ToString('o');PresentCount=0;Devices=@();Warnings=@();Error=$_.Exception.Message} | ConvertTo-Json -Compress
    } elseif ($Mode -eq 'Backup') {
        [pscustomobject]@{Success=$false;RestorePoint=$false;Exported=$false;Notes=$_.Exception.Message;Folder=$Destination} | ConvertTo-Json -Compress
    } else { Write-Error $_; exit 1 }
}
