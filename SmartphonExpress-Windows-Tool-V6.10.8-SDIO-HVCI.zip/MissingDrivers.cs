using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace SmartphonExpressWindowsTool;

public sealed partial class MainForm
{
    internal sealed class MissingDevice
    {
        public string InstanceId { get; set; } = "";
        public string Name { get; set; } = "";
        public string Status { get; set; } = "";
        public int? Code { get; set; }
        public string Category { get; set; } = "";
        public string Class { get; set; } = "";
        public string Manufacturer { get; set; } = "";
        public string[] HardwareIds { get; set; } = [];
        public string[] CompatibleIds { get; set; } = [];
        public string Identifiers { get; set; } = "";
        public string Inf { get; set; } = "";
        public string Provider { get; set; } = "";
        public string Version { get; set; } = "";
        public override string ToString() => $"{Name}\r\n{Category} | Stato: {Status} | Codice: {Code?.ToString() ?? "non disponibile"}\r\nID istanza: {InstanceId}\r\nClasse: {Class} | Produttore: {Manufacturer}\r\n{Identifiers}\r\nHardware ID:\r\n{string.Join("\r\n", HardwareIds)}\r\nID compatibili:\r\n{string.Join("\r\n", CompatibleIds)}\r\nDriver attuale: {Inf} | Fornitore: {Provider} | Versione: {Version}\r\n";
    }
    internal sealed class DriverSnapshot
    {
        public bool Success { get; set; }
        public string Time { get; set; } = "";
        public int PresentCount { get; set; }
        public string[] PresentIds { get; set; } = [];
        public MissingDevice[] Devices { get; set; } = [];
        public string[] Warnings { get; set; } = [];
        public string Error { get; set; } = "";
    }
    sealed class DriverBackup
    {
        public bool Success { get; set; }
        public bool RestorePoint { get; set; }
        public bool Exported { get; set; }
        public string Notes { get; set; } = "";
        public string Folder { get; set; } = "";
    }

    static (int ExitCode, string Output, bool TimedOut, string Diagnostics) RunMissingDriverScript(string mode, string id = "", string destination = "", int timeout = 90000)
    {
        using var stream = typeof(MainForm).Assembly.GetManifestResourceStream("SmartphonExpress.MissingDrivers.ps1")
            ?? throw new InvalidOperationException("Modulo driver non disponibile.");
        using var reader = new StreamReader(stream, Encoding.UTF8);
        static string Literal(string value) => "'" + value.Replace("'", "''") + "'";
        string ps = "& {\n" + reader.ReadToEnd() + "\n} -Mode " + Literal(mode) + " -DeviceId " + Literal(id) + " -Destination " + Literal(destination);
        string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(ps));
        // JSON and diagnostic streams must remain separate: PowerShell can write module
        // loading messages to stderr even when the diagnostic operation succeeds.
        using var process = new Process { StartInfo = new ProcessStartInfo("powershell.exe", "-NoProfile -NonInteractive -OutputFormat Text -EncodedCommand " + encoded)
            { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
              StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 } };
        process.Start();
        var stdout = process.StandardOutput.ReadToEndAsync();
        var stderr = process.StandardError.ReadToEndAsync();
        bool finished = process.WaitForExit(timeout);
        if (!finished) { try { process.Kill(true); } catch { } process.WaitForExit(5000); }
        Task.WhenAll(stdout, stderr).Wait(5000);
        return (finished ? process.ExitCode : -2, stdout.IsCompletedSuccessfully ? stdout.Result : "", !finished,
            stderr.IsCompletedSuccessfully ? stderr.Result : "Lettura diagnostica del processo incompleta.");
    }
    static DriverSnapshot ScanMissingDrivers()
    {
        var r = RunMissingDriverScript("Scan");
        if (r.TimedOut || r.ExitCode != 0) throw new InvalidOperationException("Scansione non completata: " + r.Output + "\r\n" + r.Diagnostics);
        var result = JsonSerializer.Deserialize<DriverSnapshot>(r.Output) ?? throw new InvalidOperationException("Nessun risultato diagnostico.");
        if (!result.Success) throw new InvalidOperationException("Impossibile leggere le periferiche: " + result.Error);
        if (!string.IsNullOrWhiteSpace(r.Diagnostics)) result.Warnings = [.. result.Warnings, "Messaggi PowerShell: " + r.Diagnostics];
        return result;
    }
    internal static string CompareDriverSnapshots(DriverSnapshot before, DriverSnapshot after)
    {
        if (!before.Success || !after.Success) return "Confronto non disponibile: scansione incompleta.";
        var sb = new StringBuilder($"=== CONFRONTO PRIMA / DOPO ===\r\nPrima: {before.Time}\r\nDopo: {after.Time}\r\n");
        foreach (var old in before.Devices)
        {
            var current = after.Devices.FirstOrDefault(x => x.InstanceId.Equals(old.InstanceId, StringComparison.OrdinalIgnoreCase));
            string state = current != null ? $"Ancora da verificare: {current.Category}; driver {current.Inf} {current.Version}"
                : after.PresentIds.Contains(old.InstanceId, StringComparer.OrdinalIgnoreCase) ? "Presente, nessun problema rilevato dalla nuova scansione"
                : "Non più presente: NON classificato come riparato (potrebbe essere scollegato)";
            sb.AppendLine($"{old.Name} [{old.InstanceId}]\r\nPrima: {old.Category}; driver {old.Inf} {old.Version}\r\nDopo: {state}\r\n");
        }
        foreach (var added in after.Devices.Where(x => !before.Devices.Any(y => y.InstanceId.Equals(x.InstanceId, StringComparison.OrdinalIgnoreCase))))
            sb.AppendLine($"Nuova segnalazione: {added.Name} [{added.InstanceId}] — {added.Category}");
        sb.AppendLine("Il confronto rileva cambiamenti di stato, non dimostra da solo la causa o l'efficacia di un'installazione.");
        return sb.ToString();
    }

    void RunMissingDriversModule()
    {
        if (InvokeRequired) { Invoke(RunMissingDriversModule); return; }
        using var form = new Form { Text = "SmartphonExpress — Driver mancanti / dispositivi sconosciuti", StartPosition = FormStartPosition.CenterParent,
            Size = new Size(1120, 780), MinimumSize = new Size(850, 620), Font = new Font("Segoe UI", 9.5f), BackColor = Color.White };
        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(12) };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 76));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 43));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 57));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 112));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
        var intro = new Label { Dock = DockStyle.Fill, Text = "1. Seleziona il dispositivo e controlla i candidati nel Driver Store.\r\n2. Prova il rilevamento Windows; se il problema resta, usa il produttore/Windows Update o SDIO.\r\nSDIO è esterno: seleziona solo i dispositivi problematici. Nessun aggiornamento globale automatico; HVCI resta invariato." };
        var list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, MultiSelect = false, HideSelection = false };
        list.Columns.Add("Dispositivo", 280); list.Columns.Add("Diagnosi", 330); list.Columns.Add("Classe", 110); list.Columns.Add("VEN/DEV · VID/PID", 220);
        var details = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = false, Font = new Font("Consolas", 9) };
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoScroll = true, WrapContents = true };
        var status = new Label { Dock = DockStyle.Fill, Text = "Avvio scansione…", AutoEllipsis = true };
        layout.Controls.Add(intro); layout.Controls.Add(list); layout.Controls.Add(details); layout.Controls.Add(buttons); layout.Controls.Add(status); form.Controls.Add(layout);
        Button Add(string text) { var b = new Button { Text = text, AutoSize = true, Height = 34, Padding = new Padding(8, 3, 8, 3) }; buttons.Controls.Add(b); return b; }
        var refresh = Add("Aggiorna / confronta"); var candidates = Add("Candidati Driver Store"); var native = Add("Tenta associazione Windows");
        var online = Add("Cerca Hardware ID online"); var copyId = Add("Copia Hardware ID"); var wu = Add("Windows Update");
        var download = Add("Scarica SDIO (sito ufficiale)"); var sdio = Add("Avvia SDIO locale…"); var save = Add("Salva report prima/dopo"); var close = Add("Chiudi");
        DriverSnapshot? baseline = null, latest = null;
        string? lastBackupFolder = null;
        var journal = new StringBuilder();
        bool busy = false;
        MissingDevice? Selected() => list.SelectedItems.Count == 1 ? list.SelectedItems[0].Tag as MissingDevice : null;
        string Report() => "SMARTPHONEXPRESS V6.10.8 — DRIVER MANCANTI / SDIO\r\nSolo dispositivi presenti. Unknown/Error non significa sempre driver mancante.\r\n"
            + (baseline == null || latest == null ? "Scansione non disponibile.\r\n" : CompareDriverSnapshots(baseline, latest))
            + "\r\n=== ULTIMA SCANSIONE ===\r\n" + latest?.Time + "\r\n" + string.Join("\r\n", latest?.Warnings ?? []) + "\r\n"
            + string.Join("\r\n", latest?.Devices.Select(x => x.ToString()) ?? []) + "\r\n=== OPERAZIONI ===\r\n" + journal;
        void UpdateButtons()
        {
            foreach (Control b in buttons.Controls) b.Enabled = !busy;
            list.Enabled = !busy;
            candidates.Enabled = native.Enabled = sdio.Enabled = !busy && Selected() != null;
            online.Enabled = copyId.Enabled = !busy && (Selected()?.HardwareIds.Length ?? 0) > 0;
            save.Enabled = !busy && latest != null;
        }
        async Task Run(Func<Task> action)
        {
            if (busy) return;
            busy = true; UpdateButtons(); form.UseWaitCursor = true;
            try { await action(); }
            catch (Exception ex) { journal.AppendLine($"{DateTimeOffset.Now:o} — OPERAZIONE INCOMPLETA: {ex.Message}"); details.Text = Report(); status.Text = "Operazione non completata: consulta il report."; MessageBox.Show(form, ex.Message, "Driver", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            finally { busy = false; form.UseWaitCursor = false; UpdateButtons(); }
        }
        async Task Scan()
        {
            status.Text = "Scansione dei dispositivi presenti…";
            string? selectedId = Selected()?.InstanceId;
            var snapshot = await Task.Run(ScanMissingDrivers);
            baseline ??= snapshot; latest = snapshot;
            list.Items.Clear();
            foreach (var d in snapshot.Devices)
            {
                var item = new ListViewItem([d.Name, d.Category, d.Class, d.Identifiers]) { Tag = d };
                list.Items.Add(item); if (d.InstanceId == selectedId) item.Selected = true;
            }
            if (list.Items.Count > 0 && list.SelectedItems.Count == 0) list.Items[0].Selected = true;
            details.Text = Report();
            status.Text = $"{snapshot.Devices.Length} dispositivi da verificare su {snapshot.PresentCount} presenti. {snapshot.Warnings.Length} avvisi. Ultima scansione: {snapshot.Time}";
        }
        async Task<bool> Protect()
        {
            lastBackupFolder = null;
            using var folder = new FolderBrowserDialog { Description = "Scegli dove salvare il report e il backup prima dell'intervento sui driver", UseDescriptionForTitle = true };
            if (folder.ShowDialog(form) != DialogResult.OK) return false;
            string path = Path.Combine(folder.SelectedPath, "SmartphonExpress-Driver-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..6]);
            Directory.CreateDirectory(path);
            File.WriteAllText(Path.Combine(path, "PRIMA.txt"), Report(), Encoding.UTF8);
            status.Text = "Preparazione punto di ripristino ed esportazione driver terze parti…";
            var r = await Task.Run(() => RunMissingDriverScript("Backup", destination: path, timeout: 10 * 60 * 1000));
            if (r.TimedOut || r.ExitCode != 0) throw new InvalidOperationException("Backup incompleto: intervento non avviato. " + r.Output + "\r\n" + r.Diagnostics);
            var result = JsonSerializer.Deserialize<DriverBackup>(r.Output) ?? throw new InvalidOperationException("Risposta backup non valida.");
            if (!string.IsNullOrWhiteSpace(r.Diagnostics)) result.Notes += "\r\nMessaggi PowerShell: " + r.Diagnostics;
            journal.AppendLine($"{DateTimeOffset.Now:o} — Backup: {path}\r\n{result.Notes}");
            File.WriteAllText(Path.Combine(path, "BACKUP.txt"), result.Notes, Encoding.UTF8);
            details.Text = Report();
            if (!result.Success)
            {
                MessageBox.Show(form, "Non è stato possibile verificare un nuovo punto di ripristino né un'esportazione dei driver. L'intervento non è stato avviato. Consulta il report e prepara il ripristino del sistema.", "Backup non disponibile", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            MessageBox.Show(form, $"Preparazione completata.\nNuovo punto di ripristino: {result.RestorePoint}\nBackup driver terze parti: {result.Exported}\n\n{path}\n\nIl backup dei driver non comprende Windows, i driver inbox o tutto il software del dispositivo.", "Ripristino / backup", MessageBoxButtons.OK, MessageBoxIcon.Information);
            lastBackupFolder = path;
            return true;
        }
        void SaveAfter()
        {
            if (lastBackupFolder != null) File.WriteAllText(Path.Combine(lastBackupFolder, "DOPO.txt"), Report(), Encoding.UTF8);
        }
        async Task InspectCandidates(MissingDevice d)
        {
            var r = await Task.Run(() => RunMissingDriverScript("Candidates", d.InstanceId));
            journal.AppendLine($"CANDIDATI PRIMA DELL'INTERVENTO [{d.InstanceId}]: exit={r.ExitCode}; timeout={r.TimedOut}\r\n{r.Output}\r\n{r.Diagnostics}");
            if (r.TimedOut || r.ExitCode != 0) journal.AppendLine("Candidati non determinabili: non è dimostrata l'assenza di un driver nel Driver Store.");
        }
        list.SelectedIndexChanged += (_, _) => { if (!busy) { details.Text = Selected()?.ToString() ?? Report(); UpdateButtons(); } };
        refresh.Click += async (_, _) => await Run(Scan);
        candidates.Click += async (_, _) =>
        {
            var d = Selected(); if (d == null) return;
            await Run(async () => {
                status.Text = "Lettura candidati Windows…";
                var r = await Task.Run(() => RunMissingDriverScript("Candidates", d.InstanceId));
                journal.AppendLine($"CANDIDATI [{d.InstanceId}]\r\n{r.Output}\r\n{r.Diagnostics}");
                details.Text = d + "\r\n=== CANDIDATI DRIVER STORE ===\r\n" + r.Output + "\r\n" + r.Diagnostics + "\r\nL'elenco è quello restituito da Windows; nessun driver è stato installato.";
                status.Text = r.TimedOut || r.ExitCode != 0 ? "Lettura candidati incompleta: non equivale ad assenza di driver." : "Candidati letti. Verifica l'elenco prima dell'intervento.";
            });
        };
        native.Click += async (_, _) =>
        {
            var d = Selected(); if (d == null) return;
            if (MessageBox.Show(form, "Windows eseguirà una nuova scansione hardware e potrà associare driver già disponibili. La scansione riguarda l'intero PC; non scarica pacchetti e non forza driver di ranking inferiore.\n\nPrima saranno preparati report e ripristino/backup. Continuare?", "Associazione driver Windows", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            await Run(async () => {
                await InspectCandidates(d);
                if (!await Protect()) return;
                status.Text = "Nuovo rilevamento hardware Windows…";
                var r = await Task.Run(() => RunCaptureWithTimeout("pnputil.exe", "/scan-devices", 90000));
                journal.AppendLine($"RILEVAMENTO WINDOWS: exit={r.ExitCode}, timeout={r.TimedOut}\r\n{r.Output}");
                await Scan();
                SaveAfter();
                if (r.TimedOut || r.ExitCode != 0) throw new InvalidOperationException("Rilevamento Windows non completato. Consulta il report.");
            });
        };
        copyId.Click += (_, _) => { if (Selected() is { HardwareIds.Length: > 0 } d) Clipboard.SetText(string.Join(Environment.NewLine, d.HardwareIds)); };
        void Open(string url) { try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); } catch (Exception ex) { MessageBox.Show(form, ex.Message); } }
        online.Click += (_, _) => { if (Selected() is { HardwareIds.Length: > 0 } d) Open("https://www.google.com/search?q=" + Uri.EscapeDataString("\"" + d.HardwareIds[0] + "\" driver produttore")); };
        wu.Click += (_, _) => Open("ms-settings:windowsupdate");
        download.Click += (_, _) => Open("https://www.glenn.delahoy.com/snappy-driver-installer-origin/");
        sdio.Click += async (_, _) =>
        {
            var d = Selected(); if (d == null) return;
            using var picker = new OpenFileDialog { Title = "Seleziona l'eseguibile SDIO Origin dalla cartella ufficiale estratta (anche su USB)", Filter = "SDIO Origin (*.exe)|*.exe", CheckFileExists = true };
            if (picker.ShowDialog(form) != DialogResult.OK) return;
            string exe = picker.FileName;
            if (!Path.GetFileName(exe).StartsWith("SDIO", StringComparison.OrdinalIgnoreCase)) { MessageBox.Show(form, "Seleziona un eseguibile SDIO Origin (nome SDIO…). Non vengono avviati SDI o altri installer."); return; }
            if (MessageBox.Show(form, $"Avvio interattivo di:\n{exe}\n\nDispositivo scelto: {d.Name}\nHWID: {d.HardwareIds.FirstOrDefault() ?? "non disponibile"}\n\nUsa una copia estratta dal sito ufficiale. In SDIO seleziona solo il dispositivo da riparare: il Tool non impone filtri all'app esterna. Non usare Seleziona tutto o installazione automatica.\n\nPer uso online scarica prima solo gli indici; offline servono anche i DriverPack. Il download ZIP non include i pacchetti.\n\nPrima dell'avvio sarà preparato il backup. Continuare?", "SDIO — scelta manuale del tecnico", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            await Run(async () => {
                await InspectCandidates(d);
                if (!await Protect()) return;
                journal.AppendLine($"{DateTimeOffset.Now:o} — SDIO interattivo: {exe}\r\nDispositivo di riferimento: {d.InstanceId}; HWID: {string.Join("; ", d.HardwareIds)}");
                if (d.HardwareIds.Length > 0) Clipboard.SetText(string.Join(Environment.NewLine, d.HardwareIds));
                status.Text = "SDIO aperto: scegli i driver necessari. Chiudi SDIO per acquisire il confronto finale.";
                using var process = Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(exe)! }) ?? throw new InvalidOperationException("Avvio SDIO non riuscito.");
                await process.WaitForExitAsync();
                journal.AppendLine($"SDIO terminato (codice {process.ExitCode}). Il codice non certifica l'installazione di driver.");
                await Scan();
                SaveAfter();
            });
        };
        save.Click += (_, _) =>
        {
            using var dlg = new SaveFileDialog { Filter = "Report testo (*.txt)|*.txt", FileName = "SmartphonExpress-Driver-Prima-Dopo.txt" };
            if (dlg.ShowDialog(form) == DialogResult.OK) { try { File.WriteAllText(dlg.FileName, Report(), Encoding.UTF8); } catch (Exception ex) { MessageBox.Show(form, ex.Message); } }
        };
        close.Click += (_, _) => form.Close();
        form.FormClosing += (_, e) => { if (busy) { e.Cancel = true; MessageBox.Show(form, "Attendi la fine dell'operazione; se SDIO è aperto, chiudilo per completare il confronto."); } };
        form.Shown += async (_, _) => await Run(Scan);
        UpdateButtons();
        form.ShowDialog(this);
    }
}
