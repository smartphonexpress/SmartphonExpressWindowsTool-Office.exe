SMARTPHONEXPRESS WINDOWS TOOL V6.10.7 - INTEGRITA MEMORIA

Base: allegato originale V6.10.6 AUDIO-COMPILE-FIX(1).zip.
I metadati del progetto originale erano ancora 6.10.5; ora sono allineati a 6.10.7.

Nuova voce: Diagnostica & Ripristino > Hardware, rete e driver >
Diagnostica: Integrita memoria / compatibilita driver.
Report copiabile e salvabile come TXT; funzione esclusa dai preset.

Legge Win32_DeviceGuard per distinguere VBS, HVCI configurato e HVCI
realmente in esecuzione. Analizza CodeIntegrity/Operational negli ultimi
30 giorni, massimo 500 eventi recenti: 3087, 3077, 3076, 3033, 3034, 3004.
Distingue compatibilita, blocchi App Control e audit; nessun automatismo
attribuisce a HVCI problemi USB/ADB/UsbDk/Bluetooth o dei tool di assistenza.
Mostra data, record, ActivityID, campi originali e messaggio; nome e percorso
del file, produttore e versione quando recuperabili dal file attuale.
Risolve SystemRoot, prefissi NT e percorsi Device tramite QueryDosDevice.
I metadati del file attuale possono differire da quelli all'epoca dell'evento.
Non tutti i file segnalati sono driver kernel: DLL/EXE sono distinti.
Log inaccessibile/disabilitato, timeout, dati assenti e troncamento sono espliciti.
Nessun evento NON significa compatibilita certificata.

Consiglia prima aggiornamento ufficiale, poi eventuale rimozione mirata
tramite strumenti standard. Non modifica HVCI, VBS, policy o driver.
Le altre funzioni della base sono mantenute; non sono state rieseguite
le operazioni preesistenti che modificano il sistema.

BUILD E TEST (03/11/2026)
- Publish Release win-x64, self-contained, file singolo: riuscito.
- SDK .NET 8.0.427; compilazione finale senza errori o avvisi.
- 13 controlli automatici PowerShell riusciti, incluse fixture XML,
  audit/blocco/3087, driver assente, log vuoto/negato/disabilitato.
- Prova locale Windows 11: stato VBS/HVCI e log letti correttamente;
  risoluzione percorso Device e metadati di un file reale verificati.
- Prova con accessi limitati: messaggi di stato non determinabile corretti.
- Nessuna installazione di driver incompatibili effettuata: resta da provare
  il caso end-to-end di un vero driver kernel bloccato da HVCI su PC/VM test.
- Nessun collaudo interattivo completo della GUI o regressione di tutte
  le funzioni preesistenti.

Eseguibile: PORTABLE-EXE\SmartphonExpressWindowsTool.exe
Ricompilazione: BUILD-EXE.cmd (SDK .NET 8, accesso NuGet).
Test: powershell -NoProfile -ExecutionPolicy Bypass -File tests\Test-MemoryIntegrity.ps1
Il report del PC di sviluppo non e incluso nel pacchetto.

FONTI MICROSOFT
https://learn.microsoft.com/en-us/windows-hardware/design/device-experiences/oem-hvci-enablement
https://learn.microsoft.com/en-us/windows/security/hardware-security/enable-virtualization-based-protection-of-code-integrity
https://learn.microsoft.com/en-us/windows/security/application-security/application-control/app-control-for-business/operations/event-id-explanations
