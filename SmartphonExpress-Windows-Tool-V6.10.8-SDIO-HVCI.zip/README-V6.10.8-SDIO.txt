SMARTPHONEXPRESS WINDOWS TOOL V6.10.8 - DRIVER MANCANTI / SDIO

Base: V6.10.7 con diagnostica HVCI, derivata dall'allegato V6.10.6.
Eseguibile portatile Windows x64: PORTABLE-EXE\SmartphonExpressWindowsTool.exe

DOVE SI TROVA
Diagnostica & Ripristino > Hardware, rete e driver >
Driver mancanti / dispositivi sconosciuti (SDIO).
Selezionare solo questa voce e premere ESEGUI SELEZIONATI.
Il modulo e escluso dai preset Consigliato/Prestazioni.

FUNZIONI
- Scansione Get-PnpDevice dei soli dispositivi presenti; elenco Unknown,
  Error, Degraded, codici problema e classe non specificata.
- Codice 28 distinto da dispositivi disabilitati (22), avvio fallito (10),
  errore del dispositivo (43) e semplici stati/classi sconosciuti.
- Hardware ID, ID compatibili, VEN/DEV, VID/PID, classe, produttore,
  INF, fornitore e versione quando disponibili.
- Candidati dal Driver Store: pnputil /enum-devices /instanceid /drivers.
  Eventuali errori non vengono interpretati come assenza di driver.
- Tenta associazione Windows: pnputil /scan-devices; scansione globale del
  PC esplicitata nella conferma, senza forzare ranking o scaricare driver.
- Copia HWID, ricerca online dell'Hardware ID e apertura Windows Update.
- Supporto SDIO Origin locale, anche da chiavetta/offline. Link diretto
  alla pagina ufficiale di download, scelta dell'EXE SDIO nella cartella
  estratta e avvio interattivo senza parametri di installazione automatica.
- Prima degli interventi: salvataggio PRIMA.txt, tentativo di nuovo punto
  di ripristino verificato ed esportazione dei driver di terze parti.
  Se entrambe le protezioni falliscono, l'intervento non viene avviato.
- Dopo il rilevamento Windows o la chiusura SDIO: nuova scansione,
  confronto per ID istanza e salvataggio DOPO.txt accanto al backup.
  Esportazione manuale del report completa di operazioni ed errori.
  Un dispositivo scollegato non viene mai dichiarato riparato.

USO SDIO
1. Controllare prima i candidati del Driver Store e provare Windows.
2. Preferire driver OEM del modello corretto o Windows Update.
3. Se necessario, Scarica SDIO (sito ufficiale), estrai lo ZIP e usa
   Avvia SDIO locale per scegliere il relativo eseguibile SDIO*.exe.
4. Scegliere la cartella backup e attendere la preparazione.
5. In SDIO selezionare manualmente SOLO i dispositivi problematici.
   L'HWID scelto viene copiato negli appunti. Il Tool non filtra o blocca
   le selezioni nell'applicazione esterna e non verifica il binario
   soltanto dal suo nome: usare una copia della distribuzione ufficiale.
6. Per uso online scaricare inizialmente solo gli indici; per lavorare
   offline servono anche i DriverPack. Il Tool non include SDIO o i pack.
7. Chiudere SDIO per ottenere il report finale. Se SDIO si riavvia o
   lascia un altro processo aperto, ripetere Aggiorna/confronta dopo aver
   realmente terminato. Un exit code SDIO non prova un'installazione.

LIMITI E RIPRISTINO
Il backup Driver Store comprende pacchetti di terze parti, non l'intero
sistema, i driver inbox o tutto il software accessorio. Consultare
BACKUP.txt per sapere se e riuscito il punto di ripristino, il backup o
entrambi. Per il rollback usare gli strumenti Windows (Ripristino
configurazione sistema/Gestione dispositivi) con verifica del tecnico.
Nessuna modifica automatica a HVCI/VBS, firma driver o protezioni.
Nessun riavvio, rimozione driver o aggiornamento globale automatico.
Gli ID di istanza e i report possono contenere identificativi hardware:
la ricerca online invia solo il primo Hardware ID, su clic del tecnico.

COMPILAZIONE E TEST
Release .NET 8, win-x64, self-contained, file singolo.
BUILD-EXE.cmd ricrea l'eseguibile (SDK .NET 8 e accesso NuGet).
33 controlli automatici: 14 raccolta/classificazione driver, 6 confronto
prima/dopo, 13 regressione HVCI. Tutti superati.
Test PowerShell: powershell -NoProfile -ExecutionPolicy Bypass -File tests\Test-MissingDrivers.ps1
Test HVCI: powershell -NoProfile -ExecutionPolicy Bypass -File tests\Test-MemoryIntegrity.ps1
Test confronto: dotnet run --project tests\DriverTests\DriverTests.csproj
I test non installano driver e non creano punti di ripristino.
Test della scansione dal codice compilato riuscito in 10,8 secondi.
La scansione locale ha letto 402 dispositivi presenti. I dati del PC
non sono inclusi nel pacchetto.
Nessuna installazione SDIO/driver, esportazione reale o creazione reale
punti di ripristino eseguita per il collaudo. Questi flussi richiedono
ancora prova end-to-end su PC/VM dedicato. Collaudo visivo GUI non concluso:
l'avvio tramite automazione e scaduto in attesa dell'autorizzazione app.
Le precedenti funzioni (HVCI, MTP, audio/AC-3, Search ecc.) sono mantenute;
non sono state rieseguite tutte le operazioni che modificano Windows.

FONTI
https://www.glenn.delahoy.com/snappy-driver-installer-origin/
https://learn.microsoft.com/en-us/windows-hardware/drivers/devtest/pnputil-command-syntax
https://learn.microsoft.com/en-us/powershell/module/pnpdevice/get-pnpdevice

