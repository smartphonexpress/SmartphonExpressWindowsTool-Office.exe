SMARTPHONEXPRESS WINDOWS TOOL - INTERFACCIA V4

- Interfaccia ridisegnata in stile dashboard blu/nero.
- Logo incorporato reso chiaro automaticamente sul tema scuro.
- Funzioni originali mantenute.
- Categorie: Sistema, Privacy/Ottimizzazione, App, Microsoft 365, Licenze.
- Build portable single-EXE invariata: usare BUILD-PORTABLE-FINAL.cmd.
