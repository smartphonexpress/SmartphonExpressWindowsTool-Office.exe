V4.4 - START DIAGNOSTIC FIX
La funzione START è stata riscritta:
- rileva build Windows;
- cerca realmente i collegamenti Office nel menu Start comune e utente;
- crea LayoutModification.json;
- scrive HKCU\Software\Policies\Microsoft\Windows\Explorer\ConfigureStartPins
  come REG_SZ con il percorso del JSON;
- elimina il vecchio valore ConfigureStartPinsJSON errato;
- verifica e mostra nel log il valore scritto.
Dopo l'esecuzione: disconnettere l'utente e accedere nuovamente.
La GPO richiede Windows 11 24H2 + KB5062660 o successivo.
