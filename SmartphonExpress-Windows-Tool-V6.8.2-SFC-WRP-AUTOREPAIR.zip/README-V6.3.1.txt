SmartphonExpress Windows Tool v6.3.1

NUOVO: DNS Google / Cloudflare

Google:
- IPv4 primario:   8.8.8.8
- IPv4 secondario: 8.8.4.4
- IPv6 primario:   2001:4860:4860::8888
- IPv6 secondario: 2001:4860:4860::8844

Cloudflare:
- IPv4 primario:   1.1.1.1
- IPv4 secondario: 1.0.0.1
- IPv6 primario:   2606:4700:4700::1111
- IPv6 secondario: 2606:4700:4700::1001

Comportamento:
- applica i DNS alle schede fisiche ATTIVE;
- se non trova schede fisiche attive, usa le interfacce di rete attive non-loopback;
- Google e Cloudflare sono mutuamente esclusivi;
- entrambe le opzioni sono escluse da "Seleziona tutti" per evitare una scelta arbitraria;
- Ripristina riporta i DNS ad automatico/DHCP;
- svuota la cache DNS dopo modifica/ripristino.
