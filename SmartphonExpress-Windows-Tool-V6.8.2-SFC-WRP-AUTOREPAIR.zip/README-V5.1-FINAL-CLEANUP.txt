SmartphonExpress Windows Tool V5.1 - PULIZIA FINALE

Nuova voce, ultima della lista:
PULIZIA FINALE — al prossimo riavvio, una sola volta

Funzionamento:
- crea un task ONSTART eseguito come SYSTEM;
- al riavvio pulisce:
  * C:\Windows\Temp
  * TEMP dei profili locali
  * cache Windows Error Reporting
  * Delivery Optimization Cache (se il cmdlet è disponibile)
- NON tocca Cestino, Download, Documenti o file personali;
- al termine elimina automaticamente il task;
- lo script temporaneo si auto-elimina;
- scrive un log in:
  C:\ProgramData\SmartphonExpress\FinalCleanup\FinalCleanup.log

Essendo l'ultima voce dell'elenco, se selezionata viene preparata dopo le altre operazioni.
