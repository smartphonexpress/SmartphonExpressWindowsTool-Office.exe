SmartphonExpress Windows Tool V5.2 - START FIX

Correzioni:
- legge la build completa Windows (Build + UBR);
- se >= 26100.4770 usa ConfigureStartPins GPO con JSON applyOnce;
- mantiene StartPinAppsWhenInstalled come fallback per PC appena preparati;
- per AllowPinnedFolderSettings via WMI, se l'istanza Start non esiste la crea
  con ParentID=./Vendor/MSFT/Policy/Config e InstanceID=Start;
- gpupdate /target:user /force dopo la scrittura della GPO.

Nota:
KB5062660 = OS build 26100.4770. Da tale build Microsoft supporta ConfigureStartPins via GPO.
