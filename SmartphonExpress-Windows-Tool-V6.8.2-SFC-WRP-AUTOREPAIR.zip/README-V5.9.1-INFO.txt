SmartphonExpress Windows Tool v5.9.1

Unica modifica rispetto alla v5.9:
- aggiunta la versione Release nella finestra Info;
- versione applicazione impostata nel progetto a 5.9.1;
- aggiornato anche il piccolo riferimento versione nella sidebar.

Nessuna modifica al layout responsive o alle funzioni operative.
