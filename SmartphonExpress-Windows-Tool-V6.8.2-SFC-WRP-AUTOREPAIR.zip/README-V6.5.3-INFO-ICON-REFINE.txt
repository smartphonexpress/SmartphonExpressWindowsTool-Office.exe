SmartphonExpress Windows Tool v6.5.3

Rifinitura icone informazioni:
- rimosso il cursore "Help" con punto interrogativo accanto al mouse;
- ora il cursore è una mano normale;
- eliminato il carattere "i" del font, che risultava visivamente decentrato;
- cerchio e simbolo informativo vengono disegnati manualmente con GDI+;
- puntino e stelo sono centrati geometricamente;
- hover con colore accent invariato;
- tooltip e click con descrizione restano invariati.

Nessuna modifica alla logica dei tweak.
