SmartphonExpress Windows Tool v6.5.0 — PERFORMANCE EDITION

NUOVA SEZIONE PRESTAZIONI
- Riduci animazioni e trasparenze (incluso in Seleziona tutti)
- Piano energia Prestazioni elevate (manuale)
- Disattiva avvio automatico OneDrive (manuale)
- Ottimizza unità di sistema con defrag /O, media-aware (manuale)
- Verifica TRIM SSD (diagnostica manuale)
- Analisi programmi in avvio automatico (sola lettura)
- Check hardware/software rapido:
  CPU, carico CPU, RAM totale/libera, dischi, salute dischi,
  spazio volumi e batteria

NUOVO AIUTO CONTESTUALE
- Ogni tweak/fix/ottimizzazione ha un simbolo ? cerchiato.
- Passando il mouse appare una descrizione breve.
- Facendo clic sul ? si apre una spiegazione più leggibile.
- I ? sono presenti anche sulle card principali.

SCELTE DI SICUREZZA
- Prestazioni elevate resta manuale: sui notebook aumenta consumi e temperature.
- OneDrive autostart resta manuale.
- Optimize/TRIM/check prestazioni restano manuali.
- Non vengono disabilitati SysMain, Windows Search, pagefile, Defender o Memory Integrity come tweak prestazionali automatici.
