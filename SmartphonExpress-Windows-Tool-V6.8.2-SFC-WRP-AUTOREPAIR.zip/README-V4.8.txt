SmartphonExpress Windows Tool V4.8

Aggiunta voce:
Windows Defender: disattiva Accesso controllato alle cartelle

Comando usato:
Set-MpPreference -EnableControlledFolderAccess Disabled

Il programma verifica poi lo stato con Get-MpPreference e scrive il risultato nel log.
Il comando Ripristino base riattiva la funzione con:
Set-MpPreference -EnableControlledFolderAccess Enabled

Nota:
Accesso controllato alle cartelle è una protezione anti-ransomware di Microsoft Defender.
