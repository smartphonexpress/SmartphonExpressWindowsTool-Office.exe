SmartphonExpress Windows Tool v6.4.1

FIX BLOCCO SMART APP CONTROL
- individuato il punto del blocco: CiTool.exe -r poteva restare in attesa indefinitamente
- CiTool ora ha timeout di 15 secondi
- se non risponde, il processo viene terminato e il tool CONTINUA con le operazioni successive
- la modifica VerifiedAndReputablePolicyState=0 resta comunque scritta
- in caso di timeout viene indicato nel log che il riavvio completerà l'applicazione
- aggiunti log intermedi per distinguere SmartScreen, Smart App Control e refresh CiTool

Questo fix permette quindi di arrivare anche alle operazioni successive, inclusi i DNS Google/Cloudflare.
