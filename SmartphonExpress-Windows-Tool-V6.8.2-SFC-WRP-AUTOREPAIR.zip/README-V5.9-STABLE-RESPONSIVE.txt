SmartphonExpress Windows Tool V5.9 - STABLE RESPONSIVE UI

La V5.8 usava troppi FlowLayoutPanel AutoSize annidati e poteva generare
layout enormi o scrollbar orizzontali su display con DPI/risoluzioni diverse.

La V5.9 usa un layout più deterministico:
- contenuto massimo 1500 px, centrato sui monitor larghi;
- sidebar 185/220 px in base alla finestra;
- card principali: 2 colonne o 1 colonna;
- gruppi opzioni: 3, 2 o 1 colonna;
- nessuna espansione infinita dei FlowLayout;
- nessuna scrollbar orizzontale prevista;
- una sola scrollbar verticale del contenuto, se necessaria;
- AutoScaleMode.Dpi mantenuto;
- header, bottoni e log conservano dimensioni leggibili;
- tutte le funzioni della V5.8 rimangono invariate.
