SmartphonExpress Windows Tool V5.4 - CLEAN UI

Modifica solo grafica. Funzioni della V5.3 invariate.

Interfaccia alleggerita:
- palette antracite/grigio al posto del blu acceso;
- header più basso e titolo più piccolo;
- logo ridotto;
- niente simboli/emoji nei titoli delle sezioni;
- card meno contrastate;
- pulsanti più piccoli e sobri;
- un solo colore accent per il pulsante principale;
- log neutro, senza verde acceso;
- testi secondari meno invadenti.

Le funzioni START, Defender, licenze, Notepad e pulizia finale restano quelle della V5.3.
