SmartphonExpress Windows Tool v6.4.3

FIX ATTIVAZIONI
- Ripristinato il popup riepilogativo attivazioni.
- Compare una sola volta alla fine del batch, quindi non interrompe le altre operazioni.
- Timeout Windows aumentato da 30 a 90 secondi.
- Timeout Office resta 30 secondi.
- Corretto un falso positivo Office:
  OneNoteFree LICENSED non fa più risultare tutta Office ATTIVATA.
- Se i prodotti principali Office/Microsoft 365/Project/Visio sono in
  NOTIFICATIONS / UNLICENSED / OOB_GRACE, il risultato è:
  NON ATTIVATO / SCADUTO / IN GRACE — DA VERIFICARE

Il log ricevuto dalla v6.4.2 mostrava infatti OneNote Free LICENSED,
ma Microsoft 365 era in NOTIFICATIONS con grace scaduta.
