FIX INSTALLAZIONE APP
Chrome, Firefox, 7-Zip e VLC non dipendono più da winget.
Il tool scarica gli installer dai siti ufficiali e li avvia in modalità silenziosa.
La compilazione PORTABLE FINAL è rimasta invariata.
