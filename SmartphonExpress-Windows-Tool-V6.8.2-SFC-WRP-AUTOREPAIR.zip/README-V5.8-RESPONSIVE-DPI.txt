SmartphonExpress Windows Tool V5.8 - RESPONSIVE / DPI

Questa versione corregge il problema di scaling visto su monitor e notebook.

Modifiche:
- AutoScaleMode = Dpi;
- nessuna apertura forzata a schermo intero;
- dimensione minima 900x650;
- sidebar ridimensionata automaticamente;
- header e testi con AutoSize / AutoEllipsis;
- le card principali passano automaticamente da 2 colonne a 1;
- i gruppi Sistema/Ottimizzazione/Utility passano da 3 a 2 o 1 colonna;
- pulsanti con AutoSize e wrap;
- unica scrollbar verticale dell'area principale quando serve;
- eliminate dipendenze critiche da larghezze fisse;
- layout ricalcolato dopo lo scaling DPI di Windows e a ogni resize.

Le funzioni rimangono quelle della V5.7.
