SmartphonExpress Windows Tool v6.4.2

RIFINITURA / ROBUSTEZZA

1. Stato attivazione Windows
- timeout 30 secondi
- nessuna finestra modale che blocca il flusso
- risultato solo nel log

2. Stato attivazione Office
- timeout 30 secondi
- nessuna finestra modale che blocca il flusso
- risultato solo nel log

3. Smart App Control
- log stato prima/dopo:
  0 = Off
  1 = On / Enforce
  2 = Evaluation
- timeout CiTool resta 15 secondi
- i timeout vengono contati nel riepilogo finale

4. Storage Sense sicuro
- abilitato via policy ufficiale Windows
- pulizia file temporanei consentita
- cadenza settimanale
- Download: MAI eliminati automaticamente
- Cestino: MAI eliminato automaticamente
- incluso in "Seleziona tutti"
- Ripristina rimuove le policy

5. Diagnostica rete
- manuale, esclusa da "Seleziona tutti"
- mostra scheda, descrizione, link speed, DHCP IPv4/IPv6,
  IPv4, IPv6, gateway, DNS IPv4 e DNS IPv6
- sola lettura, non modifica la rete
- timeout 20 secondi

6. Riepilogo finale
- numero operazioni selezionate
- riuscite
- errori
- timeout
- elenco delle operazioni che hanno generato errori

Servizi avanzati:
"CscService Disabled / StorSvc Manual" resta MANUALE.
CscService = Offline Files / file disponibili offline.
StorSvc = Storage Service di Windows.
Non è incluso in "Seleziona tutti" perché può avere effetti collaterali
su funzionalità che alcuni PC utilizzano.
