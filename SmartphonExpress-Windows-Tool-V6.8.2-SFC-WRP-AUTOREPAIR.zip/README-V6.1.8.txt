SmartphonExpress Windows Tool v6.1.8

Fix "Seleziona tutti":
- Download temporaneo (URL manuale): NON viene toccato dal pulsante Seleziona tutti.
- Crea AppFolder sul Desktop: NON viene toccato dal pulsante Seleziona tutti.
- Se una di queste due voci è stata spuntata manualmente, resta spuntata.
- Se è non spuntata, resta non spuntata.
- Download SmartphonExpress preconfigurato continua invece a essere incluso.

In pratica il pulsante Seleziona tutti agisce solo sulle voci normali.
