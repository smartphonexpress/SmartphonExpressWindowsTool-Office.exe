V5.1 COMPILE FIX

Correzione degli errori CS9006 / CS1073 / CS1056.
La causa erano due raw string C# interpolate che contenevano codice PowerShell
con parentesi graffe e variabili $.

Ora gli script PowerShell sono normali raw string C# non interpolate e i valori
dinamici vengono inseriti successivamente con placeholder .Replace().

Corrette entrambe le sezioni:
- Pulizia finale al prossimo riavvio
- Script WMI/SYSTEM per il pin Impostazioni
