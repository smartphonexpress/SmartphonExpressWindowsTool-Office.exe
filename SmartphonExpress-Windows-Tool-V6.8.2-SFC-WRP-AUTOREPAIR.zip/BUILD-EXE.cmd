@echo off
setlocal
cd /d "%~dp0"
if exist ".\PORTABLE-EXE" rmdir /s /q ".\PORTABLE-EXE"
dotnet publish "%~dp0SmartphonExpressWindowsTool.csproj" -c Release -r win-x64 --self-contained true ^
 -p:PublishSingleFile=true ^
 -p:IncludeNativeLibrariesForSelfExtract=true ^
 -p:EnableCompressionInSingleFile=true ^
 -p:PublishReadyToRun=false ^
 -p:DebugType=None ^
 -p:DebugSymbols=false ^
 -o "%~dp0PORTABLE-EXE"
if errorlevel 1 (
 echo COMPILAZIONE FALLITA
 pause
 exit /b 1
)
echo.
echo EXE PORTATILE CREATO:
echo %~dp0PORTABLE-EXE\SmartphonExpressWindowsTool.exe
pause
