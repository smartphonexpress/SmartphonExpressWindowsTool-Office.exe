SmartphonExpress Windows Tool V4.3
- Rimossa la terza riga dell'header (tagline) per eliminare definitivamente il testo tagliato.
- Header compatto: logo + SmartphonExpress / Windows Tool + Service Edition.
- Finestra iniziale grande della V4.2 mantenuta.
- Funzioni e build portable single-EXE mantenute.
