V4.5 - START: OFFICE + CHROME + FIREFOX + IMPOSTAZIONI

La lista desiderata dei pin Start comprende:
1. Impostazioni
2. Word
3. Excel
4. PowerPoint
5. Outlook (classic)
6. OneNote
7. Access
8. Publisher (se presente)
9. Google Chrome (se presente)
10. Mozilla Firefox (se presente)

La funzione continua a rilevare i collegamenti realmente presenti e li registra nel log.
Nota: ConfigureStartPins sostituisce la pinnedList corrente quando la policy viene applicata.
