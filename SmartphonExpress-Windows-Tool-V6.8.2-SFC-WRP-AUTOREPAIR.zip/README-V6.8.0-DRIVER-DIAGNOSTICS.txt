SmartphonExpress Windows Tool V6.8.0

- Nuova diagnostica Periferiche / Driver con codici problema, PNP ID e driver candidati.
- Nuovo rilevamento hardware con PnPUtil /scan-devices.
- Installazione sicura driver INF da cartella con /subdirs /install.
- Report esterno + log completo.
- Avviso contestuale per il problema USB Audio Code 10 di settembre 2026 sulle build/KB interessate.
- Versione piattaforma Defender nel report e avviso per versioni precedenti alla correzione 4.18.26080.4.
- Nessun bypass firma driver, Tamper Protection o forzatura di driver con ranking peggiore.
