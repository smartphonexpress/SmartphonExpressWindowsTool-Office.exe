SmartphonExpress Windows Tool v6.7.6

- Le diagnostiche mantengono tutte le informazioni nel log inferiore.
- I risultati vengono anche mostrati in una finestra esterna leggibile.
- Se vengono eseguite più diagnostiche nella stessa selezione, viene mostrato un unico report finale con sezioni separate.
- Report copiabile e salvabile in TXT.
- Diagnostica rete inclusa nel sistema di report.
