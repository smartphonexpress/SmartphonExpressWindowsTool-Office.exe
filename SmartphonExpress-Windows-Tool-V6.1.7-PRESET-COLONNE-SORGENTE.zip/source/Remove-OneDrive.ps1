<#
.SYNOPSIS
    Completely removes OneDrive from Windows 11 and restores local folder control.

.DESCRIPTION
    This script will:
    - Uninstall OneDrive application (personal and business)
    - Fix folder redirection for Documents, Desktop, and Pictures
    - Remove OneDrive from File Explorer
    - Block OneDrive from reinstalling
    - Optionally backup OneDrive files before removal

.NOTES
    Version:        2.0
    Author:         OneDrive Removal Script
    Creation Date:  2025
    Requires:       PowerShell 5.1+, Windows 11, Administrator privileges

.PARAMETER BackupPath
    Custom path for OneDrive backup. Default is user profile with timestamp.

.PARAMETER NoBackup
    Skip the backup prompt and do not create a backup.

.PARAMETER NoReboot
    Skip the reboot prompt at the end.

.PARAMETER Silent
    Run in silent mode with minimal output (shows only errors and warnings).
    Safety prompts still appear unless -Force is also specified.

.PARAMETER Force
    Skip the confirmation prompt. Required for fully unattended operation.

.EXAMPLE
    .\Remove-OneDrive.ps1

    Runs the script interactively with prompts for backup and confirmation.

.EXAMPLE
    .\Remove-OneDrive.ps1 -NoBackup -NoReboot

    Runs the script without backup or reboot prompts.

.EXAMPLE
    .\Remove-OneDrive.ps1 -BackupPath "D:\Backups" -Silent -Force

    Creates backup in D:\Backups and runs silently without confirmation prompt.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$BackupPath,

    [Parameter(Mandatory=$false)]
    [switch]$NoBackup,

    [Parameter(Mandatory=$false)]
    [switch]$NoReboot,

    [Parameter(Mandatory=$false)]
    [switch]$Silent,

    [Parameter(Mandatory=$false)]
    [switch]$Force
)

# Note: Admin elevation is handled programmatically in the script
# Do not use -RunAsAdministrator as it prevents custom elevation logic

# ---------------------------------------------
# Configuration
# ---------------------------------------------
$ErrorActionPreference = "Continue"
$script:SilentMode = $Silent.IsPresent
$script:LogFile = "$env:TEMP\Remove-OneDrive_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

# Cloud-only file attribute flags
$FILE_ATTRIBUTE_OFFLINE = 0x1000
$FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x400000

# ---------------------------------------------
# Helper Functions
# ---------------------------------------------

function Write-Log {
    param([string]$Message)

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] $Message"

    try {
        Add-Content -Path $script:LogFile -Value $logMessage -ErrorAction SilentlyContinue
    }
    catch {
        # Silently fail if logging doesn't work
    }
}

function Write-Status {
    param(
        [string]$Message,
        [string]$Type = "Info"
    )

    # Log all messages
    Write-Log "$Type : $Message"

    # In silent mode, only show warnings and errors
    if ($script:SilentMode -and $Type -in @("Info", "Success")) {
        return
    }

    switch ($Type) {
        "Info"    { Write-Host "[*] $Message" -ForegroundColor Cyan }
        "Success" { Write-Host "[+] $Message" -ForegroundColor Green }
        "Warning" { Write-Host "[!] $Message" -ForegroundColor Yellow }
        "Error"   { Write-Host "[-] $Message" -ForegroundColor Red }
    }
}

function Test-AdminPrivileges {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Request-AdminElevation {
    Write-Status "This script requires administrator privileges." "Warning"
    Write-Status "Attempting to restart with elevated permissions..." "Info"

    try {
        $argList = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
        foreach ($key in $PSBoundParameters.Keys) {
            $val = $PSBoundParameters[$key]
            if ($val -is [switch]) {
                if ($val) { $argList += " -$key" }
            } else {
                $argList += " -$key `"$val`""
            }
        }
        Start-Process powershell.exe $argList -Verb RunAs
        exit
    }
    catch {
        Write-Status "Failed to elevate privileges. Please run PowerShell as Administrator manually." "Error"
        exit 1
    }
}

function Test-CloudOnlyFile {
    param([System.IO.FileInfo]$File)

    $attrs = [int]$File.Attributes
    return (($attrs -band $FILE_ATTRIBUTE_OFFLINE) -ne 0) -or (($attrs -band $FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS) -ne 0)
}

function Find-OneDrivePaths {
    Write-Status "Scanning for OneDrive folders..." "Info"

    $paths = @()
    $candidates = Get-ChildItem -Path $env:USERPROFILE -Directory -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq "OneDrive" -or $_.Name -like "OneDrive - *" } |
        Where-Object { $_.Name -notlike "OneDrive_Backup_*" -and $_.Name -notlike "OneDrive_Conflicts*" }

    foreach ($dir in $candidates) {
        $paths += $dir.FullName
        Write-Status "Found OneDrive folder: $($dir.FullName)" "Info"
    }

    if ($paths.Count -eq 0) {
        Write-Status "No OneDrive folders found." "Info"
    }

    return $paths
}

function Backup-OneDriveFolders {
    param(
        [string]$CustomBackupPath,
        [string[]]$OneDrivePaths
    )

    Write-Status "Backing up OneDrive folders..." "Info"

    if ($CustomBackupPath) {
        $backupRoot = Join-Path $CustomBackupPath "OneDrive_Backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    } else {
        $backupRoot = "$env:USERPROFILE\OneDrive_Backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
    }

    $backedUp = $false

    foreach ($oneDrivePath in $OneDrivePaths) {
        if (Test-Path $oneDrivePath) {
            try {
                # Check available disk space
                $oneDriveSize = (Get-ChildItem -Path $oneDrivePath -Recurse -Force -ErrorAction SilentlyContinue |
                                Measure-Object -Property Length -Sum).Sum
                $targetDrive = Get-Item $backupRoot -ErrorAction SilentlyContinue
                if (-not $targetDrive) {
                    $targetDrive = Get-Item (Split-Path $backupRoot -Parent) -ErrorAction SilentlyContinue
                }
                if ($targetDrive) {
                    $drive = Get-PSDrive -Name $targetDrive.PSDrive.Name -ErrorAction SilentlyContinue
                    if ($drive -and $drive.Free -lt ($oneDriveSize * 1.1)) {
                        Write-Status "Insufficient disk space for backup of $oneDrivePath. Need $([math]::Round($oneDriveSize/1GB, 2))GB" "Error"
                        continue
                    }
                }

                $folderName = Split-Path $oneDrivePath -Leaf
                $backupPath = Join-Path $backupRoot $folderName
                Write-Status "Creating backup at: $backupPath" "Info"
                Copy-Item -Path $oneDrivePath -Destination $backupPath -Recurse -Force -ErrorAction Stop
                Write-Status "Backup of $folderName completed." "Success"
                $backedUp = $true
            }
            catch {
                Write-Status "Backup failed for $oneDrivePath : $_" "Error"
            }
        }
    }

    if ($backedUp) {
        Write-Status "Backup completed successfully!" "Success"
        return $backupRoot
    }
    return $null
}

function Stop-OneDriveProcesses {
    Write-Status "Stopping OneDrive processes..." "Info"

    $processes = Get-Process -Name "OneDrive" -ErrorAction SilentlyContinue

    if ($processes) {
        $processes | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2

        # Verify they stopped
        $remaining = Get-Process -Name "OneDrive" -ErrorAction SilentlyContinue
        if ($remaining) {
            Write-Status "Some OneDrive processes could not be stopped." "Warning"
            return $false
        }
        Write-Status "OneDrive processes stopped." "Success"
    }
    else {
        Write-Status "No OneDrive processes running." "Info"
    }
    return $true
}

function Uninstall-OneDrive {
    Write-Status "Uninstalling OneDrive..." "Info"

    # Try winget first (modern method)
    try {
        $wingetResult = winget uninstall "Microsoft OneDrive" --silent --accept-source-agreements 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Status "OneDrive uninstalled via winget." "Success"
            Write-Log "Winget output: $wingetResult"
            return $true
        }
        Write-Log "Winget output: $wingetResult"
    }
    catch {
        Write-Status "Winget uninstall failed, trying alternative method..." "Warning"
    }

    # Fallback to OneDriveSetup.exe
    $setupPaths = @(
        "$env:SystemRoot\System32\OneDriveSetup.exe",
        "$env:SystemRoot\SysWOW64\OneDriveSetup.exe"
    )

    foreach ($setupPath in $setupPaths) {
        if (Test-Path $setupPath) {
            try {
                Write-Status "Running uninstaller: $setupPath" "Info"
                $process = Start-Process -FilePath $setupPath -ArgumentList "/uninstall" -Wait -NoNewWindow -PassThru
                if ($process.ExitCode -eq 0) {
                    Write-Status "OneDrive uninstalled successfully." "Success"
                    return $true
                }
                Write-Status "Uninstaller exited with code $($process.ExitCode)." "Error"
            }
            catch {
                Write-Status "Failed to run uninstaller: $_" "Error"
            }
        }
    }

    Write-Status "Could not find OneDrive uninstaller. It may already be uninstalled." "Warning"
    return $false
}

function Move-OneDriveFilesToLocal {
    param(
        [string[]]$OneDrivePaths
    )

    Write-Status "Moving files from OneDrive folders to local folders..." "Info"

    $counts = @{ Moved = 0; Conflicted = 0; CloudOnly = 0; Failed = 0 }
    $conflictsPath = "$env:USERPROFILE\OneDrive_Conflicts"

    foreach ($oneDrivePath in $OneDrivePaths) {
        $oneDriveRootName = Split-Path $oneDrivePath -Leaf
        $subFolders = @(
            @{OneDrive = "$oneDrivePath\Documents"; Local = "$env:USERPROFILE\Documents"},
            @{OneDrive = "$oneDrivePath\Desktop"; Local = "$env:USERPROFILE\Desktop"},
            @{OneDrive = "$oneDrivePath\Pictures"; Local = "$env:USERPROFILE\Pictures"}
        )

        foreach ($folder in $subFolders) {
            # Ensure local folder exists
            if (-not (Test-Path $folder.Local)) {
                New-Item -ItemType Directory -Path $folder.Local -Force | Out-Null
                Write-Status "Created local folder: $($folder.Local)" "Info"
            }

            # Move files if OneDrive folder exists
            if (Test-Path $folder.OneDrive) {
                try {
                    $items = Get-ChildItem -Path $folder.OneDrive -Force -ErrorAction SilentlyContinue

                    if ($items) {
                        foreach ($item in $items) {
                            # Check for cloud-only placeholder files
                            if (-not $item.PSIsContainer -and (Test-CloudOnlyFile $item)) {
                                Write-Status "Skipping cloud-only file: $($item.Name) (download from OneDrive web first)" "Warning"
                                $counts.CloudOnly++
                                continue
                            }

                            $destination = Join-Path $folder.Local $item.Name

                            if (Test-Path $destination) {
                                if (-not $item.PSIsContainer) {
                                    $sourceFile = Get-Item $item.FullName
                                    $destFile = Get-Item $destination

                                    if ($sourceFile.LastWriteTime -gt $destFile.LastWriteTime) {
                                        # Source is newer — update destination, remove source
                                        Write-Status "Updating newer file: $($item.Name)" "Info"
                                        Copy-Item -Path $item.FullName -Destination $folder.Local -Force -ErrorAction Stop
                                        Remove-Item -Path $item.FullName -Force
                                        $counts.Moved++
                                    } else {
                                        # Destination is newer — save source to conflicts folder
                                        Write-Status "Conflict (destination newer): $($item.Name)" "Warning"
                                        $conflictDest = Join-Path (Join-Path $conflictsPath $oneDriveRootName) (Split-Path $folder.OneDrive -Leaf)
                                        if (-not (Test-Path $conflictDest)) {
                                            New-Item -ItemType Directory -Path $conflictDest -Force | Out-Null
                                        }
                                        Move-Item -Path $item.FullName -Destination $conflictDest -Force
                                        $counts.Conflicted++
                                    }
                                } else {
                                    # Directory — merge contents then remove source
                                    Write-Status "Merging directory: $($item.Name)" "Info"
                                    Copy-Item -Path $item.FullName -Destination $folder.Local -Recurse -Force -ErrorAction Stop
                                    Remove-Item -Path $item.FullName -Recurse -Force
                                    $counts.Moved++
                                }
                            }
                            else {
                                Write-Status "Moving: $($item.Name)" "Info"
                                Move-Item -Path $item.FullName -Destination $folder.Local -Force
                                $counts.Moved++
                            }
                        }
                    }
                }
                catch {
                    Write-Status "Error moving files from $($folder.OneDrive): $_" "Error"
                    $counts.Failed++
                }
            }
        }
    }

    # Summary
    Write-Status "File migration summary: $($counts.Moved) moved, $($counts.Conflicted) conflicted, $($counts.CloudOnly) cloud-only skipped, $($counts.Failed) failed" "Info"

    if ($counts.Conflicted -gt 0) {
        Write-Status "Conflicting files saved to: $conflictsPath" "Warning"
    }
    if ($counts.CloudOnly -gt 0) {
        Write-Status "Cloud-only files were skipped. Download them from onedrive.live.com before deleting OneDrive folders." "Warning"
    }

    return $counts
}

function Fix-FolderRedirection {
    Write-Status "Fixing folder redirection in registry..." "Info"

    $userShellFoldersPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
    $shellFoldersPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"

    $redirections = @(
        @{Name = "Personal"; ExpandPath = "%USERPROFILE%\Documents"; ResolvedPath = "$env:USERPROFILE\Documents"; Description = "Documents"},
        @{Name = "Desktop"; ExpandPath = "%USERPROFILE%\Desktop"; ResolvedPath = "$env:USERPROFILE\Desktop"; Description = "Desktop"},
        @{Name = "My Pictures"; ExpandPath = "%USERPROFILE%\Pictures"; ResolvedPath = "$env:USERPROFILE\Pictures"; Description = "Pictures"}
    )

    $success = $true

    foreach ($redirect in $redirections) {
        try {
            # User Shell Folders uses expandable strings with %USERPROFILE%
            Set-ItemProperty -Path $userShellFoldersPath -Name $redirect.Name -Value $redirect.ExpandPath -Type ExpandString -Force
            # Shell Folders uses resolved paths
            Set-ItemProperty -Path $shellFoldersPath -Name $redirect.Name -Value $redirect.ResolvedPath -Type String -Force
            Write-Status "Fixed redirection for $($redirect.Description)" "Success"
        }
        catch {
            Write-Status "Failed to fix redirection for $($redirect.Description): $_" "Error"
            $success = $false
        }
    }

    # Clean up OneDrive-related registry keys
    Write-Status "Cleaning up OneDrive registry entries..." "Info"

    $oneDriveRegPaths = @(
        "HKCU:\Software\Microsoft\OneDrive",
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{018D5C66-4533-4307-9B53-224DE2ED1FE6}"
    )

    foreach ($regPath in $oneDriveRegPaths) {
        if (Test-Path $regPath) {
            try {
                Remove-Item -Path $regPath -Recurse -Force -ErrorAction SilentlyContinue
                Write-Status "Removed registry key: $regPath" "Success"
            }
            catch {
                Write-Status "Could not remove registry key: $regPath" "Warning"
            }
        }
    }

    return $success
}

function Block-OneDriveReinstallation {
    Write-Status "Blocking OneDrive from reinstalling..." "Info"

    $policyPath = "HKLM:\Software\Policies\Microsoft\Windows\OneDrive"

    try {
        # Create policy key if it doesn't exist
        if (-not (Test-Path $policyPath)) {
            New-Item -Path $policyPath -Force | Out-Null
        }

        # Disable OneDrive file sync
        Set-ItemProperty -Path $policyPath -Name "DisableFileSync" -Value 1 -Type DWord -Force
        Set-ItemProperty -Path $policyPath -Name "DisableFileSyncNGSC" -Value 1 -Type DWord -Force

        Write-Status "OneDrive reinstallation blocked via registry policy." "Success"
        return $true
    }
    catch {
        Write-Status "Failed to set registry policy: $_" "Error"
        return $false
    }
}

function Remove-OneDriveFromExplorer {
    Write-Status "Removing OneDrive from File Explorer..." "Info"

    $clsids = @(
        "Registry::HKEY_CLASSES_ROOT\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}",
        "Registry::HKEY_CLASSES_ROOT\WOW6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}"
    )

    foreach ($clsid in $clsids) {
        if (Test-Path $clsid) {
            try {
                Remove-Item -Path $clsid -Recurse -Force -ErrorAction SilentlyContinue
                Write-Status "Removed OneDrive CLSID from registry." "Success"
            }
            catch {
                Write-Status "Could not remove CLSID (may require ownership change): $_" "Warning"
            }
        }
    }
    return $true
}

function Restart-Explorer {
    Write-Status "Restarting Windows Explorer to apply changes..." "Info"

    try {
        Stop-Process -Name explorer -Force -ErrorAction Stop
        Start-Sleep -Seconds 2
        Start-Process explorer.exe
        Write-Status "Explorer restarted successfully." "Success"
        return $true
    }
    catch {
        Write-Status "Failed to restart Explorer: $_" "Error"
        return $false
    }
}

function Remove-OneDriveStartupEntry {
    Write-Status "Removing OneDrive from startup..." "Info"

    $startupPaths = @(
        "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run",
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run"
    )

    foreach ($path in $startupPaths) {
        try {
            $oneDriveRun = Get-ItemProperty -Path $path -Name "OneDrive" -ErrorAction SilentlyContinue
            if ($oneDriveRun) {
                Remove-ItemProperty -Path $path -Name "OneDrive" -Force
                Write-Status "Removed OneDrive from startup registry." "Success"
            }
        }
        catch {
            # Silently continue if entry doesn't exist
        }
    }
    return $true
}

function Remove-OneDriveFolder {
    param(
        [string[]]$OneDrivePaths
    )

    Write-Status "Checking for empty OneDrive folders..." "Info"

    foreach ($oneDrivePath in $OneDrivePaths) {
        if (Test-Path $oneDrivePath) {
            $items = Get-ChildItem -Path $oneDrivePath -Force -ErrorAction SilentlyContinue

            if (-not $items -or $items.Count -eq 0) {
                try {
                    Remove-Item -Path $oneDrivePath -Force -Recurse -ErrorAction Stop
                    Write-Status "Removed empty OneDrive folder: $oneDrivePath" "Success"
                }
                catch {
                    Write-Status "Could not remove OneDrive folder $oneDrivePath : $_" "Warning"
                }
            }
            else {
                Write-Status "OneDrive folder is not empty, skipping: $oneDrivePath" "Warning"
                Write-Status "You can manually delete it later: $oneDrivePath" "Info"
            }
        }
    }
    return $true
}

# ---------------------------------------------
# Main Script
# ---------------------------------------------

function Main {
    Clear-Host

    Write-Host @"
+============================================================+
|                                                            |
|        OneDrive Complete Removal Script for Windows 11     |
|                                                            |
+============================================================+
"@ -ForegroundColor Magenta

    Write-Host ""
    Write-Status "This script will completely remove OneDrive from your system." "Info"
    Write-Status "It will:" "Info"
    Write-Host "  * Uninstall OneDrive application"
    Write-Host "  * Move files from OneDrive folders to local folders"
    Write-Host "  * Fix folder redirection (Documents, Desktop, Pictures)"
    Write-Host "  * Remove OneDrive from File Explorer"
    Write-Host "  * Block OneDrive from reinstalling"
    Write-Host ""

    # Check for admin privileges
    if (-not (Test-AdminPrivileges)) {
        Request-AdminElevation
    }

    # Detect OneDrive folders
    $oneDrivePaths = Find-OneDrivePaths

    if ($oneDrivePaths.Count -gt 0) {
        Write-Host ""
        Write-Status "The following OneDrive folders will be processed:" "Info"
        foreach ($p in $oneDrivePaths) {
            Write-Host "  * $p"
        }
        Write-Host ""
    }

    # Confirmation (skipped with -Force)
    if (-not $Force) {
        $confirm = Read-Host "Do you want to proceed? (Y/N)"
        if ($confirm -ne "Y" -and $confirm -ne "y") {
            Write-Status "Operation cancelled by user." "Warning"
            exit 0
        }
    }

    Write-Host ""

    # Ask about backup (skipped with -NoBackup)
    if (-not $NoBackup -and $oneDrivePaths.Count -gt 0) {
        if ($Force) {
            # Force mode with no -NoBackup: create backup automatically
            $backupResult = Backup-OneDriveFolders -CustomBackupPath $BackupPath -OneDrivePaths $oneDrivePaths
            if ($backupResult) {
                Write-Status "Backup saved to: $backupResult" "Success"
            }
        } else {
            $backup = Read-Host "Do you want to backup your OneDrive folder first? (Y/N - Recommended)"
            if ($backup -eq "Y" -or $backup -eq "y") {
                $backupResult = Backup-OneDriveFolders -CustomBackupPath $BackupPath -OneDrivePaths $oneDrivePaths
                if ($backupResult) {
                    Write-Status "Backup saved to: $backupResult" "Success"
                }
            }
        }
    }

    Write-Host ""
    Write-Status "Starting OneDrive removal process..." "Info"
    Write-Log "Starting OneDrive removal process"
    Write-Host ""

    # Execute removal steps and track results
    $stepResults = @{}

    # 1. Stop processes
    $stepResults["StopProcesses"] = Stop-OneDriveProcesses

    # 2. Remove startup entry
    $stepResults["RemoveStartup"] = Remove-OneDriveStartupEntry

    # 3. Uninstall BEFORE moving files (so OneDrive can't sync/lock during migration)
    $stepResults["Uninstall"] = Uninstall-OneDrive

    # 4. Move files to local folders (after uninstall)
    $migrationCounts = Move-OneDriveFilesToLocal -OneDrivePaths $oneDrivePaths
    $stepResults["MoveFiles"] = ($migrationCounts.Failed -eq 0)

    # 5. Fix folder redirection
    $stepResults["FixRedirection"] = Fix-FolderRedirection

    # 6. Block reinstallation
    $stepResults["BlockReinstall"] = Block-OneDriveReinstallation

    # 7. Remove from Explorer
    $stepResults["RemoveFromExplorer"] = Remove-OneDriveFromExplorer

    # 8. Clean up empty folders
    $stepResults["RemoveFolder"] = Remove-OneDriveFolder -OneDrivePaths $oneDrivePaths

    # 9. Restart Explorer
    $stepResults["RestartExplorer"] = Restart-Explorer

    # Determine overall result
    $failedSteps = $stepResults.GetEnumerator() | Where-Object { $_.Value -eq $false } | ForEach-Object { $_.Key }
    $criticalFailures = $failedSteps | Where-Object { $_ -in @("Uninstall", "MoveFiles", "FixRedirection") }

    # Summary
    Write-Host ""

    if ($criticalFailures) {
        Write-Host @"
+============================================================+
|                   REMOVAL PARTIALLY FAILED                  |
+============================================================+
"@ -ForegroundColor Red

        Write-Host ""
        Write-Status "OneDrive removal encountered critical failures:" "Error"
        foreach ($step in $failedSteps) {
            Write-Status "  Failed: $step" "Error"
        }
        Write-Host ""
        Write-Status "Your system may be in an intermediate state." "Warning"
        Write-Status "Check the log file for details: $script:LogFile" "Warning"
        Write-Status "See the README for rollback instructions if needed." "Warning"
    }
    elseif ($failedSteps) {
        Write-Host @"
+============================================================+
|                REMOVAL COMPLETED WITH WARNINGS              |
+============================================================+
"@ -ForegroundColor Yellow

        Write-Host ""
        Write-Status "OneDrive was removed but some non-critical steps had issues:" "Warning"
        foreach ($step in $failedSteps) {
            Write-Status "  Warning: $step" "Warning"
        }
    }
    else {
        Write-Host @"
+============================================================+
|                      REMOVAL COMPLETE                       |
+============================================================+
"@ -ForegroundColor Green

        Write-Host ""
        Write-Status "OneDrive has been completely removed!" "Success"
    }

    Write-Host ""
    Write-Status "Your files are now in local folders:" "Info"
    Write-Host "  * Documents: $env:USERPROFILE\Documents"
    Write-Host "  * Desktop:   $env:USERPROFILE\Desktop"
    Write-Host "  * Pictures:  $env:USERPROFILE\Pictures"

    if ($migrationCounts.CloudOnly -gt 0) {
        Write-Host ""
        Write-Status "$($migrationCounts.CloudOnly) cloud-only files were skipped. Download them from onedrive.live.com" "Warning"
    }
    if ($migrationCounts.Conflicted -gt 0) {
        Write-Host ""
        Write-Status "$($migrationCounts.Conflicted) conflicting files saved to: $env:USERPROFILE\OneDrive_Conflicts" "Warning"
    }

    Write-Host ""
    Write-Status "Next steps:" "Info"
    Write-Host "  1. Restart your computer to ensure all changes take effect"
    Write-Host "  2. Verify your files are in the correct locations"
    Write-Host ""
    Write-Status "Log file saved to: $script:LogFile" "Info"
    Write-Host ""

    if (-not $NoReboot) {
        if ($Force) {
            Write-Status "Restarting computer in 10 seconds..." "Info"
            Write-Log "Auto-restart initiated (Force mode)"
            Start-Sleep -Seconds 10
            Restart-Computer -Force
        } else {
            $reboot = Read-Host "Would you like to restart now? (Y/N)"
            if ($reboot -eq "Y" -or $reboot -eq "y") {
                Write-Status "Restarting computer in 10 seconds..." "Info"
                Write-Log "User initiated system restart"
                Start-Sleep -Seconds 10
                Restart-Computer -Force
            }
            else {
                Write-Status "Please restart your computer when convenient." "Info"
            }
        }
    }
    else {
        Write-Status "Please restart your computer when convenient." "Info"
    }

    Write-Log "OneDrive removal completed"
}

# Execute main function
Main
