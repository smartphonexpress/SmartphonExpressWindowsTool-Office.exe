using System.Diagnostics;
using System.Text;
namespace SmartphonExpressWindowsTool;
public sealed partial class MainForm
{
    void RunPerformanceCheck()
    {
        string ps = """
$ErrorActionPreference='SilentlyContinue'

$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$cs  = Get-CimInstance Win32_ComputerSystem
$os  = Get-CimInstance Win32_OperatingSystem
$batt = Get-CimInstance Win32_Battery | Select-Object -First 1

'CPU=' + $cpu.Name
'CPU_LOAD=' + $cpu.LoadPercentage + '%'
'RAM_TOTAL_GB=' + [math]::Round($cs.TotalPhysicalMemory/1GB,1)
'RAM_FREE_GB=' + [math]::Round(($os.FreePhysicalMemory*1KB)/1GB,1)

if ($batt) {
    'BATTERY_CARICA=' + $batt.EstimatedChargeRemaining + '%'
} else {
    'BATTERY=non presente'
}

Get-PhysicalDisk | ForEach-Object {
    'DISK=' + $_.FriendlyName + ' | Media=' + $_.MediaType + ' | Health=' + $_.HealthStatus + ' | SizeGB=' + [math]::Round($_.Size/1GB,0)
}

Get-Volume | Where-Object DriveLetter | ForEach-Object {
    'VOLUME=' + $_.DriveLetter + ': | FreeGB=' + [math]::Round($_.SizeRemaining/1GB,1) + ' | SizeGB=' + [math]::Round($_.Size/1GB,1)
}
""";

        var r = RunCaptureWithTimeout(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"",
            25000);

        if (r.TimedOut)
        {

            Log("CHECK PRESTAZIONI: timeout dopo 25 secondi.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(r.Output))
            ShowDiagnosticReport("Prestazioni — hardware e software", r.Output);

        if (r.ExitCode != 0)
            throw new Exception($"Check prestazioni terminato con codice {r.ExitCode}.");
    }

    void ShowDiagnosticReportWindow(string title, string report)
    {
        if (InvokeRequired)
        {
            Invoke(() => ShowDiagnosticReportWindow(title, report));
            return;
        }
        using var form = new Form
        {
            Text = title,
            StartPosition = FormStartPosition.CenterParent,
            AutoScaleMode = AutoScaleMode.Dpi,
            AutoScaleDimensions = new SizeF(96, 96),
            Size = new Size(800, 600),
            MinimumSize = new Size(620, 440),
            BackColor = Color.White,
            Font = new Font("Segoe UI", 9.5f)
        };
        var box = new TextBox
        {
            Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both,
            WordWrap = false, Dock = DockStyle.Fill, Font = new Font("Consolas", 9.5f),
            Text = report.Replace("\r\n", "\n").Replace("\n", Environment.NewLine)
        };
        var bar = new FlowLayoutPanel { Dock = DockStyle.Bottom, AutoSize = true, Padding = new Padding(8) };
        var copy = new Button { Text = "Copia", Width = 100, Height = 32 };
        var save = new Button { Text = "Salva TXT", Width = 100, Height = 32 };
        var close = new Button { Text = "Chiudi", Width = 100, Height = 32 };
        copy.Click += (_,__) => { if (!string.IsNullOrEmpty(box.Text)) Clipboard.SetText(box.Text); };
        save.Click += (_,__) =>
        {
            using var dlg = new SaveFileDialog { Filter = "File di testo (*.txt)|*.txt", FileName = "SmartphonExpress-Diagnostica.txt" };
            if (dlg.ShowDialog(form) == DialogResult.OK) File.WriteAllText(dlg.FileName, box.Text, Encoding.UTF8);
        };
        close.Click += (_,__) => form.Close();
        bar.Controls.Add(copy); bar.Controls.Add(save); bar.Controls.Add(close);
        form.Controls.Add(box); form.Controls.Add(bar);
        form.ShowDialog(this);
    }

    void RunSfcScan()
    {
        Log("SFC: avvio /scannow. L'operazione può richiedere diversi minuti...");
        var first = RunCaptureWithTimeout("sfc.exe", "/scannow", 45 * 60 * 1000);
        var report = new StringBuilder();
        report.AppendLine("SFC /SCANNOW");
        report.AppendLine($"Exit code: {first.ExitCode}");
        report.AppendLine($"Timeout: {(first.TimedOut ? "SI" : "NO")}");
        report.AppendLine();
        report.AppendLine(string.IsNullOrWhiteSpace(first.Output) ? "Nessun output restituito da SFC." : first.Output);

        if (first.TimedOut)
        {
            ShowDiagnosticReport("SFC — Controllo file di sistema", report.ToString());
            throw new Exception("SFC ha superato il timeout di 45 minuti.");
        }
        if (first.ExitCode < 0)
        {
            ShowDiagnosticReport("SFC — Controllo file di sistema", report.ToString());
            throw new Exception("Impossibile avviare SFC. Consulta il report.");
        }

        // Autoriparazione mirata solo per gli errori Windows Resource Protection noti.
        // Non disabilita WRP e non modifica altre protezioni di Windows.
        if (!IsWrpRepairError(first.Output))
        {
            ShowDiagnosticReport("SFC — Controllo file di sistema", report.ToString());
            Log($"SFC: terminato (exit code {first.ExitCode}). Consulta il report per l'esito dettagliato.");
            return;
        }

        Log("SFC: rilevato errore Windows Resource Protection. Avvio autoriparazione supportata...");
        report.AppendLine();
        report.AppendLine("=== AUTORIPARAZIONE WINDOWS RESOURCE PROTECTION ===");
        report.AppendLine("Rilevato: Windows Resource Protection non riesce a completare SFC.");
        report.AppendLine("La protezione NON viene disabilitata.");

        // Microsoft indica di verificare l'esistenza di queste due cartelle quando WRP
        // restituisce 'could not perform the requested operation'.
        string temp = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "WinSxS", "Temp");
        foreach (var folderName in new[] { "PendingDeletes", "PendingRenames" })
        {
            string folder = Path.Combine(temp, folderName);
            try
            {
                bool existed = Directory.Exists(folder);
                if (!existed) Directory.CreateDirectory(folder);
                report.AppendLine($"{folderName}: {(existed ? "presente" : "mancante - creata")}");
                Log($"SFC/WRP: {folderName} {(existed ? "presente" : "creata")}.");
            }
            catch (Exception ex)
            {
                report.AppendLine($"{folderName}: ERRORE - {ex.Message}");
                Log($"SFC/WRP: impossibile verificare/creare {folderName}: {ex.Message}");
            }
        }

        // Se il servizio di riparazione non parte, proviamo ad avviare TrustedInstaller.
        // Se era già attivo, l'eventuale codice non-zero di SC non è considerato un guasto.
        var tiQuery = RunCaptureWithTimeout("sc.exe", "query TrustedInstaller", 15000);
        report.AppendLine();
        report.AppendLine("Windows Modules Installer / TrustedInstaller:");
        report.AppendLine(string.IsNullOrWhiteSpace(tiQuery.Output) ? $"query exit code {tiQuery.ExitCode}" : tiQuery.Output);
        if (IsWrpRepairServiceError(first.Output) || !tiQuery.Output.Contains("RUNNING", StringComparison.OrdinalIgnoreCase))
        {
            Log("SFC/WRP: tentativo avvio Windows Modules Installer (TrustedInstaller)...");
            var tiStart = RunCaptureWithTimeout("sc.exe", "start TrustedInstaller", 20000);
            report.AppendLine("Tentativo avvio TrustedInstaller:");
            report.AppendLine(string.IsNullOrWhiteSpace(tiStart.Output) ? $"exit code {tiStart.ExitCode}" : tiStart.Output);
        }

        // Ripariamo il Component Store prima di rilanciare SFC.
        var dismSteps = new[]
        {
            (Name: "CheckHealth", Args: "/Online /Cleanup-Image /CheckHealth", Timeout: 10 * 60 * 1000),
            (Name: "ScanHealth", Args: "/Online /Cleanup-Image /ScanHealth", Timeout: 30 * 60 * 1000),
            (Name: "RestoreHealth", Args: "/Online /Cleanup-Image /RestoreHealth", Timeout: 60 * 60 * 1000)
        };

        bool dismFailed = false;
        foreach (var step in dismSteps)
        {
            Log($"SFC/WRP: DISM {step.Name}...");
            var d = RunCaptureWithTimeout("dism.exe", step.Args, step.Timeout);
            report.AppendLine();
            report.AppendLine($"=== DISM {step.Name.ToUpperInvariant()} ===");
            report.AppendLine($"Exit code: {d.ExitCode} | Timeout: {(d.TimedOut ? "SI" : "NO")}");
            report.AppendLine(string.IsNullOrWhiteSpace(d.Output) ? "Nessun output." : d.Output);
            if (d.TimedOut || d.ExitCode != 0)
            {
                dismFailed = true;
                Log($"SFC/WRP: DISM {step.Name} non riuscito (exit {d.ExitCode}, timeout={d.TimedOut}).");
                if (LooksLikeRpc1726(d.Output, d.ExitCode))
                {
                    Log("SFC/WRP: rilevato RPC 1726; aggiungo diagnostica conflitti servizi al report.");
                    report.AppendLine(BuildRpc1726DiagnosticReport());
                }
                // Se DISM non riesce, non ha senso proseguire con gli step successivi o ripetere SFC alla cieca.
                break;
            }
        }

        if (!dismFailed)
        {
            Log("SFC/WRP: DISM completato. Nuovo tentativo SFC /scannow...");
            var retry = RunCaptureWithTimeout("sfc.exe", "/scannow", 45 * 60 * 1000);
            report.AppendLine();
            report.AppendLine("=== SECONDO TENTATIVO SFC /SCANNOW ===");
            report.AppendLine($"Exit code: {retry.ExitCode} | Timeout: {(retry.TimedOut ? "SI" : "NO")}");
            report.AppendLine(string.IsNullOrWhiteSpace(retry.Output) ? "Nessun output." : retry.Output);

            if (retry.TimedOut)
                report.AppendLine("ESITO: SFC ha superato il timeout anche dopo l'autoriparazione.");
            else if (IsWrpRepairError(retry.Output))
            {
                report.AppendLine();
                report.AppendLine("ESITO: l'errore Windows Resource Protection persiste.");
                report.AppendLine("Passo successivo consigliato: eseguire SFC in Modalità provvisoria.");
                report.AppendLine("Il Tool non disabilita Windows Resource Protection e non applica forzature distruttive.");
            }
            else
                report.AppendLine("ESITO: secondo tentativo SFC completato. Verificare il messaggio SFC sopra per sapere se sono stati trovati/riparati file corrotti.");
        }
        else
        {
            report.AppendLine();
            report.AppendLine("ESITO: DISM non è riuscito a riparare/verificare il Component Store.");
            report.AppendLine("SFC non è stato rilanciato automaticamente per evitare tentativi inutili.");
            report.AppendLine("Consultare l'errore DISM sopra; può essere necessaria una sorgente di riparazione Windows compatibile.");
        }

        ShowDiagnosticReport("SFC — Controllo e autoriparazione WRP", report.ToString());
        Log("SFC/WRP: procedura terminata. Consulta il report per il risultato completo.");
    }

    static bool IsWrpRepairError(string? output)
    {
        if (string.IsNullOrWhiteSpace(output)) return false;
        string s = output.ToLowerInvariant();
        return s.Contains("windows resource protection could not perform the requested operation") ||
               s.Contains("protezione risorse di windows: impossibile eseguire l'operazione richiesta") ||
               s.Contains("protezione risorse di windows non è riuscita a eseguire l'operazione richiesta") ||
               IsWrpRepairServiceError(output);
    }

    static bool IsWrpRepairServiceError(string? output)
    {
        if (string.IsNullOrWhiteSpace(output)) return false;
        string s = output.ToLowerInvariant();
        return s.Contains("windows resource protection could not start the repair service") ||
               s.Contains("protezione risorse di windows: impossibile avviare il servizio di ripristino") ||
               s.Contains("protezione risorse di windows non è riuscita ad avviare il servizio di ripristino");
    }


    static bool LooksLikeRpc1726(string? output, int exitCode)
    {
        string t = (output ?? string.Empty).ToLowerInvariant();
        return exitCode == 1726 || t.Contains("1726") ||
               t.Contains("remote procedure call failed") ||
               t.Contains("procedura di chiamata remota non è riuscita") ||
               t.Contains("procedura di chiamata remota non e riuscita");
    }

    string BuildRpc1726DiagnosticReport()
    {
        var sb = new StringBuilder();
        sb.AppendLine("RPC / DISM — DIAGNOSTICA ERRORE 1726");
        sb.AppendLine(new string('-', 72));
        sb.AppendLine("I servizi RPC core vengono solo verificati: SmartphonExpress NON ne cambia configurazione o tipo di avvio.");
        sb.AppendLine();

        foreach (var name in new[] { "RpcSs", "DcomLaunch", "RpcEptMapper", "TrustedInstaller" })
        {
            var q = RunCaptureWithTimeout("sc.exe", "query " + name, 15000);
            sb.AppendLine("=== " + name + " ===");
            sb.AppendLine(q.Output.Trim());
            sb.AppendLine();
        }

        string ps = """
$ErrorActionPreference='SilentlyContinue'
function Get-ExeFromPathName([string]$p) {
  if([string]::IsNullOrWhiteSpace($p)){ return $null }
  $p=$p.Trim()
  if($p.StartsWith('"')) { $i=$p.IndexOf('"',1); if($i -gt 1){ return $p.Substring(1,$i-1) } }
  $m=[regex]::Match($p,'^(.+?\.exe)(?:\s|$)','IgnoreCase'); if($m.Success){ return $m.Groups[1].Value }
  return ($p -split ' ')[0]
}
'=== SERVIZI NON MICROSOFT ATTIVI / CANDIDATI AL CONFLITTO ==='
$items=@()
Get-CimInstance Win32_Service | Where-Object { $_.State -eq 'Running' } | ForEach-Object {
  $exe=Get-ExeFromPathName $_.PathName
  if(-not $exe -or -not (Test-Path $exe)){ return }
  $sig=Get-AuthenticodeSignature -FilePath $exe
  $sub=''; if($sig.SignerCertificate){ $sub=$sig.SignerCertificate.Subject }
  $isMs=($sig.Status -eq 'Valid' -and $sub -match 'Microsoft')
  if(-not $isMs){
    $items += [pscustomobject]@{Name=$_.Name; Display=$_.DisplayName; StartMode=$_.StartMode; Path=$exe; Signature=$sig.Status; Signer=$sub}
  }
}
if($items.Count -eq 0){ 'Nessun servizio di terze parti attivo identificato con questo criterio.' }
else { $items | Sort-Object Display | Format-Table -AutoSize | Out-String -Width 220 }
""";
        string enc = Convert.ToBase64String(Encoding.Unicode.GetBytes(ps));
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + enc, 120000);
        sb.AppendLine(r.Output.Trim());
        sb.AppendLine();
        sb.AppendLine("Interpretazione:");
        sb.AppendLine("• Se SFC/DISM funzionano in Modalità provvisoria ma falliscono nell'avvio normale, un servizio/driver/componente caricato solo nell'avvio normale è un candidato concreto.");
        sb.AppendLine("• L'elenco sopra è diagnostico: non dimostra da solo quale sia il colpevole.");


        return sb.ToString();
    }

    void RunRpcServiceConflictDiagnostics()
    {
        Log("RPC 1726: raccolta diagnostica servizi e possibili conflitti...");
        ShowDiagnosticReport("RPC / DISM — Diagnostica conflitti servizi", BuildRpc1726DiagnosticReport());
    }

    void RunDismRestoreHealth()
    {
        Log("DISM: avvio /Online /Cleanup-Image /RestoreHealth. L'operazione può richiedere diversi minuti...");
        var r = RunCaptureWithTimeout("dism.exe", "/Online /Cleanup-Image /RestoreHealth", 60 * 60 * 1000);
        string report = "DISM /ONLINE /CLEANUP-IMAGE /RESTOREHEALTH\r\n" +
                        $"Exit code: {r.ExitCode}\r\n" +
                        $"Timeout: {(r.TimedOut ? "SI" : "NO")}\r\n\r\n" +
                        (string.IsNullOrWhiteSpace(r.Output) ? "Nessun output restituito da DISM." : r.Output);
        if (LooksLikeRpc1726(r.Output, r.ExitCode))
        {
            report += "\r\n\r\n" + BuildRpc1726DiagnosticReport();
            Log("DISM: rilevato errore RPC 1726. I servizi RPC core vengono solo verificati, non modificati.");
        }
        ShowDiagnosticReport("DISM — Riparazione immagine Windows", report);
        if (r.TimedOut) throw new Exception("DISM ha superato il timeout di 60 minuti.");
        if (r.ExitCode != 0)
        {
            if (LooksLikeRpc1726(r.Output, r.ExitCode))
                throw new Exception("DISM: errore RPC 1726. Consulta il report e prova l'isolamento servizi non Microsoft se in Modalità provvisoria funziona.");
            throw new Exception($"DISM terminato con codice {r.ExitCode}. Consulta il report.");
        }
        Log("DISM: RestoreHealth completato correttamente.");
    }

    void ResetWindowsUpdateComponents()
    {
        string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        string ps = $@"
$ErrorActionPreference='Stop'
$services='bits','wuauserv','cryptsvc','msiserver'
foreach($s in $services) {{ Stop-Service $s -Force -ErrorAction SilentlyContinue }}
$sd=Join-Path $env:windir 'SoftwareDistribution'
$cr=Join-Path $env:windir 'System32\\catroot2'
if(Test-Path $sd) {{ Rename-Item $sd ('SoftwareDistribution.old-{stamp}') -ErrorAction Stop }}
if(Test-Path $cr) {{ Rename-Item $cr ('catroot2.old-{stamp}') -ErrorAction Stop }}
foreach($s in $services) {{ Start-Service $s -ErrorAction SilentlyContinue }}
'Windows Update ripristinato. Cache ricreata; le cartelle precedenti sono state conservate con suffisso .old.'";
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"", 120000);
        ShowDiagnosticReport("Windows Update — Ripristino componenti", r.Output);
        if (r.TimedOut) throw new Exception("Reset Windows Update: timeout.");
        if (r.ExitCode != 0) throw new Exception($"Reset Windows Update terminato con codice {r.ExitCode}.");
    }

    void CheckWinReStatus()
    {
        var r = RunCaptureWithTimeout("reagentc.exe", "/info", 30000);
        ShowDiagnosticReport("WinRE — Stato ambiente di ripristino", r.Output);
        if (r.TimedOut) throw new Exception("Controllo WinRE: timeout.");
        if (r.ExitCode != 0) throw new Exception($"REAgentC terminato con codice {r.ExitCode}.");
    }

    void RunBatteryHealthCheck()
    {
        // Legge i dati esposti dal driver batteria tramite le classi WMI native di Windows.
        // Nessuna dipendenza da software esterno e nessuna modifica alla configurazione del PC.
        string ps = @"
$ErrorActionPreference='SilentlyContinue'

function FmtMWh($v) {
  if($null -eq $v -or [double]$v -le 0) { return 'Non disponibile' }
  return ('{0:N0} mWh' -f [double]$v)
}
function FmtMv($v) {
  if($null -eq $v -or [double]$v -le 0) { return 'Non disponibile' }
  return ('{0:N0} mV' -f [double]$v)
}
function Prop($o,$name) {
  if($null -eq $o) { return $null }
  $p=$o.PSObject.Properties[$name]
  if($null -ne $p) { return $p.Value }
  return $null
}

$b = Get-CimInstance Win32_Battery | Select-Object -First 1
$static = Get-CimInstance -Namespace root/wmi -ClassName BatteryStaticData | Select-Object -First 1
$fullObj = Get-CimInstance -Namespace root/wmi -ClassName BatteryFullChargedCapacity | Select-Object -First 1
$statusObj = Get-CimInstance -Namespace root/wmi -ClassName BatteryStatus | Select-Object -First 1
$cycleObj = Get-CimInstance -Namespace root/wmi -ClassName BatteryCycleCount | Select-Object -First 1

if(-not $b -and -not $static -and -not $statusObj) {
  'BATTERIA: non presente o dati non esposti dal driver'
  exit 0
}

$design = Prop $static 'DesignedCapacity'
# Alcuni driver espongono DesignedCapacity via il vecchio provider WMI ma non tramite CIM.
# BatteryInfoView interroga direttamente il battery miniport; questo fallback copre molti di quei casi.
if($null -eq $design -or [double]$design -le 0) {
  try {
    $staticWmi = Get-WmiObject -Namespace root\wmi -Class BatteryStaticData -ErrorAction SilentlyContinue | Select-Object -First 1
    $designWmi = Prop $staticWmi 'DesignedCapacity'
    if($null -ne $designWmi -and [double]$designWmi -gt 0) { $design = $designWmi }
  } catch {}
}
$full = Prop $fullObj 'FullChargedCapacity'

# Ultimo fallback: il report batteria di Windows usa lo stesso stack batteria e spesso
# contiene la Design Capacity anche quando root/wmi la restituisce a zero.
if($null -eq $design -or [double]$design -le 0) {
  try {
    $br = Join-Path $env:TEMP ('spex-battery-' + [guid]::NewGuid().ToString('N') + '.html')
    & powercfg.exe /batteryreport /output $br | Out-Null
    if(Test-Path $br) {
      $html = Get-Content -LiteralPath $br -Raw -ErrorAction SilentlyContinue
      # Cerca la riga/cella che contiene DESIGN CAPACITY / capacità di progetto e il primo valore mWh successivo.
      $m = [regex]::Match($html, '(?is)(DESIGN\s*CAPACITY|CAPACIT.{0,8}(DI\s*)?(PROGETTO|FABBRICA)).{0,800}?([0-9][0-9\.\,\s]*)\s*mWh')
      if($m.Success) {
        $raw = $m.Groups[4].Value -replace '[^0-9]',''
        if($raw) { $design = [double]$raw }
      }
      Remove-Item -LiteralPath $br -Force -ErrorAction SilentlyContinue
    }
  } catch {}
}
$remaining = Prop $statusObj 'RemainingCapacity'
$voltage = Prop $statusObj 'Voltage'
$rate = Prop $statusObj 'Rate'
$chargeRate = Prop $statusObj 'ChargeRate'
$dischargeRate = Prop $statusObj 'DischargeRate'
$cycles = Prop $cycleObj 'CycleCount'

$name = Prop $static 'DeviceName'
if([string]::IsNullOrWhiteSpace([string]$name)) { $name = Prop $b 'Name' }
$maker = Prop $static 'ManufactureName'
if([string]::IsNullOrWhiteSpace([string]$maker)) { $maker = Prop $b 'Manufacturer' }
$serial = Prop $static 'SerialNumber'

$chemRaw = Prop $static 'Chemistry'
if([string]::IsNullOrWhiteSpace([string]$chemRaw)) { $chemRaw = Prop $b 'Chemistry' }
$chem = switch([int]$chemRaw) {
  3 {'Piombo-acido'} 4 {'NiCd'} 5 {'NiMH'} 6 {'Litio'} 7 {'Zinco-aria'} 8 {'Litio-polimero'} default { if($chemRaw){[string]$chemRaw}else{'Non disponibile'} }
}

$chargePct = Prop $b 'EstimatedChargeRemaining'
if(($null -eq $chargePct -or [double]$chargePct -lt 0) -and $remaining -and $full) {
  $chargePct=[math]::Round(([double]$remaining/[double]$full)*100,1)
}

'=== BATTERIA ==='
if($name)   { 'Modello: ' + $name }
if($maker)  { 'Produttore: ' + $maker }
if($serial) { 'Seriale: ' + $serial }
'Chimica: ' + $chem
''
'=== CAPACITA E SALUTE ==='
if($null -ne $chargePct) { 'Carica attuale: ' + $chargePct + '%' }
'Capacita attuale: ' + (FmtMWh $remaining)
'Capacita di fabbrica: ' + (FmtMWh $design)
'Capacita massima attuale: ' + (FmtMWh $full)

if($design -and $full -and [double]$design -gt 0) {
  $health=[math]::Round(([double]$full/[double]$design)*100,1)
  if($health -gt 100) { $health=100 }
  $wear=[math]::Round(100-$health,1)
  'SALUTE BATTERIA: ' + $health + '%'
  'Usura stimata: ' + $wear + '%'
  if($health -ge 90){$rating='Ottima'} elseif($health -ge 80){$rating='Buona'} elseif($health -ge 65){$rating='Usurata'} else {$rating='Molto usurata / da valutare'}
  'Valutazione: ' + $rating
} else {
  'SALUTE BATTERIA: non calcolabile (capacita non esposte dal firmware/driver)'
}

''
'=== UTILIZZO ==='
if($null -ne $cycles) { 'Cicli di carica/scarica: ' + $cycles } else { 'Cicli di carica/scarica: Non disponibile' }
'Voltaggio: ' + (FmtMv $voltage)

$online = Prop $statusObj 'PowerOnline'
$charging = Prop $statusObj 'Charging'
$discharging = Prop $statusObj 'Discharging'
if($charging -eq $true) {$powerState='In carica'} elseif($discharging -eq $true) {$powerState='In uso / scarica'} elseif($online -eq $true) {$powerState='Alimentazione AC'} else {$powerState='Non determinato'}
'Stato alimentazione: ' + $powerState

if($null -ne $rate) {
  if([double]$rate -gt 0) {
    'Potenza istantanea: +' + ('{0:N0} mW' -f [math]::Abs([double]$rate)) + ' (carica)'
  } elseif([double]$rate -lt 0) {
    'Potenza istantanea: -' + ('{0:N0} mW' -f [math]::Abs([double]$rate)) + ' (scarica)'
  } else {
    'Potenza istantanea: 0 mW'
  }
} elseif($charging -eq $true -and $chargeRate) {
  'Potenza di carica: ' + ('{0:N0} mW' -f [double]$chargeRate)
} elseif($discharging -eq $true -and $dischargeRate) {
  'Potenza di scarica: ' + ('{0:N0} mW' -f [double]$dischargeRate)
} else {
  'Potenza istantanea: Non disponibile'
}

''
'Nota: alcuni valori dipendono da cio che firmware e driver della batteria espongono a Windows.'
";
        var r = RunCaptureWithTimeout("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"", 30000);
        ShowDiagnosticReport("Batteria — Diagnostica avanzata", r.Output);
        if (r.TimedOut) throw new Exception("Diagnostica batteria: timeout.");
        if (r.ExitCode != 0) throw new Exception($"Diagnostica batteria terminata con codice {r.ExitCode}.");
    }

    void RunNetworkDiagnostics()
    {
        Log("RETE: diagnostica in corso...");

        string ps = """
$ErrorActionPreference='SilentlyContinue'
$all = @(Get-NetAdapter | Where-Object { $_.Name -notmatch 'Loopback' })
$physical = @($all | Where-Object { $_.HardwareInterface -eq $true })
$virtual = @($all | Where-Object { $_.HardwareInterface -ne $true })

if ($all.Count -eq 0) {
    Write-Output 'NESSUNA_SCHEDA_TROVATA'
    exit 2
}

function Write-AdapterInfo($a, $kind) {
    $ipcfg = Get-NetIPConfiguration -InterfaceIndex $a.ifIndex
    $v4if = Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv4
    $v6if = Get-NetIPInterface -InterfaceIndex $a.ifIndex -AddressFamily IPv6
    $dns4 = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv4).ServerAddresses
    $dns6 = (Get-DnsClientServerAddress -InterfaceIndex $a.ifIndex -AddressFamily IPv6).ServerAddresses
    $gw4 = @(($ipcfg.IPv4DefaultGateway.NextHop))
    $isInternet = ($a.Status -eq 'Up' -and $gw4.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace(($gw4 -join '')))

    Write-Output ('TIPO=' + $kind)
    Write-Output ('ADAPTER=' + $a.Name)
    Write-Output ('DESC=' + $a.InterfaceDescription)
    Write-Output ('STATO=' + $a.Status)
    Write-Output ('CONNESSIONE_INTERNET=' + $(if($isInternet){'SI'}else{'NO'}))
    Write-Output ('LINK=' + $(if($a.Status -eq 'Up'){$a.LinkSpeed}else{'Non connessa'}))
    Write-Output ('DHCP4=' + $v4if.Dhcp)
    Write-Output ('DHCP6=' + $v6if.Dhcp)
    Write-Output ('IPV4=' + (($ipcfg.IPv4Address.IPAddress) -join ', '))
    Write-Output ('IPV6=' + (($ipcfg.IPv6Address.IPAddress) -join ', '))
    Write-Output ('GATEWAY=' + ($gw4 -join ', '))
    Write-Output ('DNS4=' + ($dns4 -join ', '))
    Write-Output ('DNS6=' + ($dns6 -join ', '))
    Write-Output '---'
}

Write-Output '=== SCHEDE FISICHE ==='
foreach ($a in $physical) { Write-AdapterInfo $a 'FISICA' }

if ($virtual.Count -gt 0) {
    Write-Output '=== SCHEDE VIRTUALI / SECONDARIE ==='
    foreach ($a in $virtual) { Write-AdapterInfo $a 'VIRTUALE' }
}
""";

        var result = RunCaptureWithTimeout(
            "powershell.exe",
            "-NoProfile -ExecutionPolicy Bypass -Command \"" + ps.Replace("\"", "\\\"") + "\"",
            20000);

        if (result.TimedOut)
        {

            Log("RETE: diagnostica interrotta per timeout dopo 20 secondi.");
            return;
        }

        if (!string.IsNullOrWhiteSpace(result.Output))
        {
            foreach (var line in result.Output.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries))
                Log("RETE: " + line.Trim());
        }

        if (result.ExitCode != 0)
            throw new Exception($"Diagnostica rete terminata con codice {result.ExitCode}.");

        Log("RETE: diagnostica completata. Mostrate anche le schede fisiche non connesse e separate le interfacce virtuali.");
        ShowDiagnosticReport("Rete — Diagnostica completa", result.Output);
    }

    void RunDriverQueryDiagnostics()
    {
        Log("DRIVERQUERY: raccolta elenco dettagliato e informazioni firma...");
        var verbose = RunCaptureWithTimeout("driverquery.exe", "/v", 60000);
        var signed = RunCaptureWithTimeout("driverquery.exe", "/si", 60000);

        var report = new StringBuilder();
        report.AppendLine("DRIVER DI SISTEMA — DRIVERQUERY");
        report.AppendLine(new string('-', 72));
        report.AppendLine("Comando: driverquery /v");
        report.AppendLine($"Exit code: {verbose.ExitCode} | Timeout: {(verbose.TimedOut ? "SI" : "NO")}");
        report.AppendLine();
        report.AppendLine(string.IsNullOrWhiteSpace(verbose.Output) ? "Nessun output restituito." : verbose.Output.TrimEnd());
        report.AppendLine();
        report.AppendLine();
        report.AppendLine("DRIVER FIRMATI — DRIVERQUERY /SI");
        report.AppendLine(new string('-', 72));
        report.AppendLine($"Exit code: {signed.ExitCode} | Timeout: {(signed.TimedOut ? "SI" : "NO")}");
        report.AppendLine();
        report.AppendLine(string.IsNullOrWhiteSpace(signed.Output) ? "Nessun output restituito." : signed.Output.TrimEnd());

        ShowDiagnosticReport("Driver di sistema / firme — driverquery", report.ToString());

        if (verbose.TimedOut || signed.TimedOut)
            throw new Exception("Driverquery ha superato il timeout. Consulta il report.");
        if (verbose.ExitCode != 0 || signed.ExitCode != 0)
            throw new Exception($"Driverquery terminato con errore (/v={verbose.ExitCode}, /si={signed.ExitCode}). Consulta il report.");
    }

    static (int ExitCode, string Output, bool TimedOut) RunCaptureWithTimeout(
        string file,
        string args,
        int timeoutMs)
    {
        using var p = new Process();
        p.StartInfo = new ProcessStartInfo(file, args)
        {
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };

        var stdout = new StringBuilder();
        var stderr = new StringBuilder();
        object syncOut = new();
        object syncErr = new();

        p.OutputDataReceived += (_, e) =>
        {
            if (e.Data is null) return;
            lock (syncOut) stdout.AppendLine(e.Data);
        };
        p.ErrorDataReceived += (_, e) =>
        {
            if (e.Data is null) return;
            lock (syncErr) stderr.AppendLine(e.Data);
        };

        try
        {
            if (!p.Start()) return (-1, "Impossibile avviare il processo.", false);
        }
        catch (Exception ex)
        {
            return (-1, "Impossibile avviare il processo: " + ex.Message, false);
        }

        p.BeginOutputReadLine();
        p.BeginErrorReadLine();

        bool exited = timeoutMs == Timeout.Infinite ? p.WaitForExit(int.MaxValue) : p.WaitForExit(timeoutMs);
        if (!exited)
        {
            try { p.Kill(true); } catch { }
            try { p.WaitForExit(5000); } catch { }
            string partial;
            lock (syncOut) lock (syncErr)
                partial = (stdout.ToString() + Environment.NewLine + stderr.ToString()).Trim();
            if (string.IsNullOrWhiteSpace(partial)) partial = $"Timeout dopo {timeoutMs / 1000} secondi.";
            return (-2, partial, true);
        }

        // Necessario dopo la lettura asincrona per attendere gli ultimi eventi OutputDataReceived/ErrorDataReceived.
        p.WaitForExit();
        string output;
        lock (syncOut) lock (syncErr)
            output = (stdout.ToString() + Environment.NewLine + stderr.ToString()).Trim();
        return (p.ExitCode, output, false);
    }


}

