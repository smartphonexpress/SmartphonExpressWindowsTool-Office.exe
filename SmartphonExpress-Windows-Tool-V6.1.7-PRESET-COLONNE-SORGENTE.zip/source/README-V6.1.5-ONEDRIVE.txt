SMARTPHONEXPRESS WINDOWS TOOL V6.1.5 - ONEDRIVE OPTIONAL UTILITY

- Aggiunta utility autonoma "Rimuovi OneDrive".
- NON inclusa in "Esegui selezionati", "Seleziona tutti", "Consigliata" o "Prestazioni".
- Conferma esplicita prima dell'avvio.
- Remove-OneDrive.ps1 incorporato come EmbeddedResource nell'EXE.
- All'avvio viene estratto in %ProgramData%\SmartphonExpress\OneDriveRemoval\Remove-OneDrive.ps1.
- Percorso stabile necessario perché lo script può auto-rilanciarsi con privilegi amministrativi.
- La procedura dello script resta interattiva e mantiene backup, ripristino cartelle locali, disinstallazione e blocco reinstallazione.

Nota: il sorgente e la struttura sono stati verificati, ma in questo ambiente non è disponibile il comando dotnet per una build reale.
