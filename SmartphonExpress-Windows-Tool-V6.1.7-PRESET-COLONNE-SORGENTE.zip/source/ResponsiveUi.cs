using System.Diagnostics;

namespace SmartphonExpressWindowsTool;

public sealed partial class MainForm
{
    readonly ToolTip utilityTips = new();
    bool diagnosticBusy;

    void BuildModernUi()
    {
        SuspendLayout();
        MinimumSize = new Size(640, 480);
        var root = new TableLayoutPanel
        {
            Name = "MainLayout", Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4,
            Padding = new Padding(12), Margin = Padding.Empty
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));

        var heading = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = true };
        var logo = new PictureBox { Size = new Size(44, 44), SizeMode = PictureBoxSizeMode.Zoom };
        var sourceLogo = LoadEmbeddedLogo();
        if (sourceLogo != null) logo.Image = MakeLogoForLightTheme(sourceLogo);
        heading.Controls.Add(logo);
        heading.Controls.Add(new Label
        {
            Text = $"SmartphonExpress • Windows Tool v{Application.ProductVersion}",
            AutoSize = true, Font = new Font("Segoe UI Semibold", 14, FontStyle.Bold),
            Margin = new Padding(8, 8, 8, 8)
        });
        root.Controls.Add(heading, 0, 0);

        var tabs = new TabControl { Name = "MainTabs", Dock = DockStyle.Fill };
        var operations = MakePage(tabs, "Operazioni");
        var groups = new[]
        {
            MakeGroup("Configurazione e installazione", new[] {25, 24, 30, 26, 27, 33}),
            MakeGroup("Sistema", Enumerable.Range(0, 10)),
            MakeGroup("Ottimizzazione", Enumerable.Range(10, 14)),
            MakeGroup("Utility, rete e licenze", new[] {28, 29, 31, 32, 34, 35, 36, 37, 38})
        };
        var featured = groups[0];
        var featuredControls = featured.Controls.Cast<Control>().ToArray();
        featured.SuspendLayout();
        featured.Controls.Clear(); featured.ColumnStyles.Clear(); featured.RowStyles.Clear(); featured.ColumnCount = 2; featured.RowCount = 4;
        for (int row = 0; row < 4; row++) featured.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        featured.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        featured.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        featured.Controls.Add(featuredControls[0], 0, 0);
        featured.SetColumnSpan(featuredControls[0], 2);
        for (int i = 1; i < featuredControls.Length; i++)
            featured.Controls.Add(featuredControls[i], (i - 1) % 2, 1 + (i - 1) / 2);
        featured.ResumeLayout(true);
        operations.Name = "OperationColumns";
        int lastColumns = 0;
        bool arranging = false;
        void ArrangeGroups()
        {
            if (arranging) return;
            // Font-relative thresholds also follow DPI changes and larger text settings.
            float unit = TextRenderer.MeasureText("M", operations.Font).Height / 17f;
            int columns = operations.ClientSize.Width >= 1040 * unit ? 3 : 2;
            if (columns == lastColumns) return;
            arranging = true;
            operations.SuspendLayout();
            operations.Controls.Clear();
            operations.ColumnStyles.Clear(); operations.RowStyles.Clear();
            operations.ColumnCount = columns;
            operations.RowCount = 1 + (int)Math.Ceiling(3.0 / columns);
            for (int i = 0; i < columns; i++)
                operations.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));
            for (int row = 0; row < operations.RowCount; row++) operations.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            // Featured operations span the page; the other groups retain their columns.
            operations.Controls.Add(groups[0], 0, 0);
            operations.SetColumnSpan(groups[0], columns);
            for (int i = 1; i < groups.Length; i++)
                operations.Controls.Add(groups[i], (i - 1) % columns, 1 + (i - 1) / columns);
            lastColumns = columns;
            operations.ResumeLayout(true);
            arranging = false;
        }
        operations.SizeChanged += (_, _) => ArrangeGroups();
        operations.FontChanged += (_, _) => { lastColumns = 0; ArrangeGroups(); };
        ArrangeGroups();
        var diagnostics = MakePage(tabs, "Diagnostica e ripristino");
        AddHeading(diagnostics, "Controlli e report — avvio manuale");
        AddDiagnostic(diagnostics, "Check hardware / software rapido", RunPerformanceCheck);
        AddDiagnostic(diagnostics, "Batteria: salute, capacità e carica", RunBatteryHealthCheck);
        AddDiagnostic(diagnostics, "Rete: schede, DHCP, DNS, gateway e velocità", RunNetworkDiagnostics);
        AddDiagnostic(diagnostics, "Driver di sistema e firme (driverquery)", RunDriverQueryDiagnostics);
        AddDiagnostic(diagnostics, "Servizi / errore RPC 1726", RunRpcServiceConflictDiagnostics);
        AddDiagnostic(diagnostics, "WinRE: stato ambiente di ripristino", CheckWinReStatus);
        AddHeading(diagnostics, "Riparazione di Windows — conferma prima dell'avvio");
        AddDiagnostic(diagnostics, "SFC /Scannow e autoriparazione WRP", RunSfcScan, true);
        AddDiagnostic(diagnostics, "DISM /Online /Cleanup-Image /RestoreHealth", RunDismRestoreHealth, true);
        AddDiagnostic(diagnostics, "Reset componenti Windows Update", ResetWindowsUpdateComponents, true);

        var utilities = MakePage(tabs, "Utility facoltative");
        AddHeading(utilities, "OneDrive — escluso da selezioni ed esecuzioni collettive");
        var oneDrive = MakeAction("Rimuovi OneDrive");
        oneDrive.Name = "RemoveOneDrive";
        oneDrive.Click += (_, _) => RunOneDriveRemoval();
        utilityTips.SetToolTip(oneDrive, "Rimuove OneDrive dopo conferma esplicita. Lo script è incorporato nell'eseguibile.");
        utilities.Controls.Add(oneDrive);
        root.Controls.Add(tabs, 0, 1);

        var actions = new FlowLayoutPanel
        {
            Name = "Actions", Dock = DockStyle.Fill, AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink, WrapContents = true,
            Padding = new Padding(0, 6, 0, 0)
        };
        apply.Text = "Esegui selezionati"; all.Text = "Seleziona tutti";
        none.Text = "Deseleziona"; restore.Text = "Ripristino"; exit.Text = "Esci";
        var recommended = MakeAction("Consigliata"); recommended.Name = "RecommendedPreset";
        var performance = MakeAction("Prestazioni"); performance.Name = "PerformancePreset";
        recommended.Click += (_, _) => SelectPreset(false);
        performance.Click += (_, _) => SelectPreset(true);
        utilityTips.SetToolTip(recommended, "Seleziona configurazione, applicazioni e utility consigliate; non esegue operazioni.");
        utilityTips.SetToolTip(performance, "Seleziona le ottimizzazioni disponibili senza installazioni; non esegue operazioni.");
        var clear = MakeAction("Pulisci log"); clear.Click += (_, _) => log.Clear();
        var settings = MakeAction("Impostazioni");
        settings.Click += (_, _) => { try { Process.Start(new ProcessStartInfo("ms-settings:") { UseShellExecute = true }); } catch (Exception ex) { Log(ex.Message); } };
        var info = MakeAction("Info");
        info.Click += (_, _) => MessageBox.Show(this, $"SmartphonExpress Windows Tool\nService Edition\nRelease: v{Application.ProductVersion}", "Informazioni");
        foreach (var button in new[] {apply, recommended, performance, all, none, restore, clear, settings, info, exit})
        {
            ConfigureAction(button);
            actions.Controls.Add(button);
        }
        root.Controls.Add(actions, 0, 2);
        var logGroup = new GroupBox { Text = "Log operazioni", Dock = DockStyle.Fill, Padding = new Padding(8) };
        logGroup.Controls.Add(log);
        root.Controls.Add(logGroup, 0, 3);
        Controls.Add(root);
        FormClosed += (_, _) => { utilityTips.Dispose(); logo.Image?.Dispose(); };
        ResumeLayout(true);
    }

    void SelectPreset(bool performance)
    {
        // Explicit lists refer to the original 39 operations, not their position on screen.
        int[] indices = performance
            ? new[] {6, 7, 10, 11, 12, 14, 15, 16, 17, 20, 21, 23}
            : new[] {0, 1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17,
                     19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 37};
        var selected = indices.ToHashSet();
        foreach (var check in tweakChecks) check.Checked = selected.Contains((int)check.Tag!);
        Log($"PRESET {(performance ? "PRESTAZIONI" : "CONSIGLIATA")}: {selected.Count} operazioni selezionate. Premi Esegui selezionati per applicare.");
    }

    TableLayoutPanel MakeGroup(string title, IEnumerable<int> indices)
    {
        var group = new ContentTable
        {
            Name = "OperationGroup", Dock = DockStyle.Top, AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink, ColumnCount = 1,
            GrowStyle = TableLayoutPanelGrowStyle.AddRows, Margin = new Padding(6),
            Padding = new Padding(6), BackColor = Color.FromArgb(247, 249, 252)
        };
        group.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        AddGroup(group, title, indices);
        group.RowCount = group.Controls.Count;
        foreach (Control control in group.Controls) group.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        return group;
    }
    static TableLayoutPanel MakePage(TabControl tabs, string title)
    {
        var page = new TabPage(title) { AutoScroll = true, Padding = new Padding(10), BackColor = Color.White };
        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Top, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1, GrowStyle = TableLayoutPanelGrowStyle.AddRows,
            Padding = new Padding(4), Margin = Padding.Empty
        };
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        page.Controls.Add(table);
        tabs.TabPages.Add(page);
        return table;
    }

    static void AddHeading(TableLayoutPanel table, string title) => table.Controls.Add(new Label
    {
        Text = title, AutoSize = true, Dock = DockStyle.Top,
        Font = new Font("Segoe UI Semibold", 10, FontStyle.Bold), Margin = new Padding(3, 14, 3, 8)
    });

    void AddGroup(TableLayoutPanel table, string title, IEnumerable<int> indices)
    {
        AddHeading(table, title);
        foreach (int index in indices)
        {
            var check = new WrappingCheckBox
            {
                Text = tweaks[index].Name, Tag = index, Name = $"Tweak{index}",
                AutoSize = true, Dock = DockStyle.Top,
                Margin = new Padding(3, 4, 3, 4), Padding = new Padding(3),
                CheckAlign = ContentAlignment.MiddleLeft, TextAlign = ContentAlignment.MiddleLeft
            };
            tweakChecks.Add(check);
            table.Controls.Add(check);
        }
    }

    static Button MakeAction(string title)
    {
        var button = new Button { Text = title };
        ConfigureAction(button);
        return button;
    }

    static void ConfigureAction(Button button)
    {
        button.AutoSize = true;
        button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        button.MinimumSize = Size.Empty;
        button.Padding = new Padding(10, 6, 10, 6);
        button.Margin = new Padding(3);
    }

    void AddDiagnostic(TableLayoutPanel table, string caption, Action action, bool repairs = false)
    {
        var button = MakeAction(caption);
        button.Name = "DiagnosticAction";
        button.Dock = DockStyle.Top;
        button.Click += async (_, _) =>
        {
            if (diagnosticBusy || !apply.Enabled || !restore.Enabled) return;
            if (repairs && MessageBox.Show(this,
                $"Avviare {caption}?\n\nLa procedura modifica i componenti di Windows e può richiedere diversi minuti.",
                "Diagnostica e ripristino", MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            diagnosticBusy = true;
            apply.Enabled = restore.Enabled = false;
            var buttons = table.Controls.OfType<Button>().ToArray();
            foreach (var item in buttons) item.Enabled = false;
            try { await Task.Run(action); }
            catch (Exception ex) { Log("DIAGNOSTICA: " + ex.Message); }
            finally
            {
                diagnosticBusy = false;
                apply.Enabled = restore.Enabled = true;
                foreach (var item in buttons) item.Enabled = true;
            }
        };
        table.Controls.Add(button);
    }

    void ShowDiagnosticReport(string title, string report)
    {
        if (InvokeRequired) { Invoke(() => ShowDiagnosticReport(title, report)); return; }
        Log(title + Environment.NewLine + report);
        ShowDiagnosticReportWindow(title, report);
    }
}

// Measure wrapped text using the actual font and device DPI, including room for the glyph.
internal sealed class WrappingCheckBox : CheckBox
{
    public override Size GetPreferredSize(Size proposedSize)
    {
        int glyph = (int)Math.Ceiling(24 * DeviceDpi / 96.0);
        int width = proposedSize.Width > 0 && proposedSize.Width < 100000
            ? proposedSize.Width : Math.Max(100, Width);
        width = Math.Max((int)Math.Ceiling(150 * DeviceDpi / 96.0), width);
        var textSize = TextRenderer.MeasureText(Text, Font,
            new Size(Math.Max(1, width - glyph - Padding.Horizontal), int.MaxValue),
            TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl);
        return new Size(width, Math.Max(glyph, textSize.Height) + Padding.Vertical + (int)Math.Ceiling(6 * DeviceDpi / 96.0));
    }
}





// Nested AutoSize tables must derive height from wrapped content, not a previous
// allocated height (WinForms otherwise gives leftover space to the final row).
internal sealed class ContentTable : TableLayoutPanel
{
    public override Size GetPreferredSize(Size proposedSize)
    {
        int width = proposedSize.Width > 0 && proposedSize.Width < 100000 ? proposedSize.Width : Width;
        int inner = Math.Max(1, width - Padding.Horizontal);
        var heights = new Dictionary<int, int>();
        foreach (Control child in Controls)
        {
            var cell = GetPositionFromControl(child);
            int available = Math.Max(1, inner * GetColumnSpan(child) / Math.Max(1, ColumnCount) - child.Margin.Horizontal);
            int height = child.GetPreferredSize(new Size(available, 0)).Height + child.Margin.Vertical;
            heights[cell.Row] = Math.Max(heights.GetValueOrDefault(cell.Row), height);
        }
        return new Size(width, heights.Values.Sum() + Padding.Vertical);
    }
}
