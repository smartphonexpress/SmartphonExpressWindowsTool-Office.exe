using System.Drawing;
using System.Windows.Forms;
using SmartphonExpressWindowsTool;
class LayoutTests
{
    static IEnumerable<Control> Desc(Control p) => p.Controls.Cast<Control>().SelectMany(c => new[] {c}.Concat(Desc(c)));
    static void Check(bool pass, string message) { if (!pass) throw new Exception(message); }
    [STAThread] static void Main() { try { RunTests(); } catch(Exception ex) { Console.WriteLine(ex); Environment.Exit(1); } } static void RunTests()
    {
        Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
        Directory.CreateDirectory("tests/results");
        foreach (float scale in new[] {1f, 1.25f, 1.5f})
        foreach (int width in new[] {640, 900, 1280})
        {
            Console.WriteLine("Creating form"); using var form = new MainForm(); Console.WriteLine("Form created");
            // No Show/Close or action execution: FormClosing cleans temporary downloads.
            Console.WriteLine("Handle start"); _ = form.Handle; Console.WriteLine("Handle done");
            form.AutoScaleMode = AutoScaleMode.None;
            var controls = Desc(form).ToArray();
            foreach (var pair in controls.Append(form).Select(c => (Control: c, Font: c.Font)).ToArray())
                pair.Control.Font = new Font(pair.Font.FontFamily, pair.Font.Size * scale, pair.Font.Style);
            form.Scale(new SizeF(scale, scale));
            form.ClientSize = new Size((int)(width*scale), (int)(700*scale));
            form.StartPosition = FormStartPosition.Manual; form.Location = new Point(-20000,-20000); form.ShowInTaskbar = false; form.Show(); Console.WriteLine("Scale done"); var tabs = controls.OfType<TabControl>().Single();
            foreach (TabPage page in tabs.TabPages)
            {
                Console.WriteLine(page.Text); tabs.SelectedTab = page;
                _ = page.Handle;
                for (int repeat=0; repeat<1; repeat++) { form.PerformLayout(); page.PerformLayout();  }
                Console.WriteLine("Layout done"); var table = page.Controls.OfType<TableLayoutPanel>().Single();
                foreach(Control c in table.Controls)
                {
                    Check(c.Right <= table.ClientSize.Width, $"right clipped {scale}/{width}/{c.Text}");
                    Check(c.Bottom <= table.ClientSize.Height, $"bottom clipped {scale}/{width}/{c.Text}");
                    if(c is CheckBox) Check(c.Height >= c.GetPreferredSize(new Size(c.Width,0)).Height, $"text clipped {scale}/{width}/{c.Text}: {c.Height}/{c.GetPreferredSize(new Size(c.Width,0)).Height}");
                }
                var ordered=table.Controls.Cast<Control>().OrderBy(c=>c.Top).ToArray();
                for(int i=1;i<ordered.Length;i++) Check(ordered[i-1].Bottom<=ordered[i].Top,"overlap");
                if(page.Text=="Operazioni")
                {
                    var checks=Desc(page).OfType<CheckBox>().ToArray();
                    Check(checks.Length==39,"Expected 39 checkboxes");
                    Check(checks.Select(c=>(int)c.Tag!).Order().SequenceEqual(Enumerable.Range(0,39)),"Missing/duplicate tweak index");
                    Console.WriteLine("Scroll start"); page.ScrollControlIntoView(checks.Last()); Console.WriteLine("Scroll done");
                    Check(checks.Last().RectangleToScreen(checks.Last().ClientRectangle).Bottom <= page.RectangleToScreen(page.ClientRectangle).Bottom,"last checkbox unreachable");
                    page.AutoScrollPosition=Point.Empty;
                }
                if(width==900)
                {
                    using var bitmap=new Bitmap(form.Width, form.Height);
                    form.DrawToBitmap(bitmap,new Rectangle(Point.Empty,bitmap.Size));
                    bitmap.Save($"tests/results/{scale*100:0}-{tabs.SelectedIndex}.png");
                }
            }
            Check(controls.OfType<Button>().Count(b=>b.Name=="DiagnosticAction")==9,"Missing diagnostic actions");
            Check(controls.OfType<Button>().Count(b=>b.Name=="RemoveOneDrive")==1,"Missing OneDrive");
            var bar=controls.Single(c=>c.Name=="Actions");
            foreach(Control b in bar.Controls) Check(b.Bottom<=bar.ClientSize.Height && b.Right<=bar.ClientSize.Width,"Action clipped");
            Console.WriteLine($"PASS scale={scale*100:0}% width={width} logical px, 39 tweaks, 9 diagnostics, OneDrive separate");
        }
    }
}







